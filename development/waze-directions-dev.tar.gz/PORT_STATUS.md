# Waze HUD directions — unfinished development snapshot

This is not a Store package and must not be installed in a car. Port of
JustAnotherPU's PR #110 onto the waze-on-cluster 0.10.0 / app 0.6.8 baseline,
with experimental additions from JustAnotherPU/waze-hud for street names.
The bundled card recognition sample and source are from those projects.

Unresolved: no verified templates for the actual iPhone's SF Pro; no reliable
installation method for them within the requested Store-only workflow; no
validation of F44 center-screen geometry, warnings, native HUD arbitration,
SOME/IP street schema or turn accuracy on the vehicle. The integration can
change the CarPlay patch and must not be installed until those are resolved.
The UI attempts to switch the map from both displays to cluster-only when
arrows are enabled so the F44 native guidance slot is released. This requires
end-to-end tests with profile switches, installation, upgrades and rollback.

The public GitHub repository must not contain SF Pro fonts or derived templates.
The 0.6.0 F44 bridge launcher recognizes backend version 0.10.0 only; a
future newer backend needs an explicit compatible launcher update.
