/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 Robert Nisipeanu */
#include "server.h"

#include "curves.h"

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <grp.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#include "log.h"

namespace crs {

namespace {

/* Non-blocking and close-on-exec, the portable way (the host tests run on
 * macOS). */
void nonblocking(int fd)
{
    fcntl(fd, F_SETFD, FD_CLOEXEC);
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
}

#ifdef MSG_NOSIGNAL
const int kSendFlags = MSG_NOSIGNAL;
#else
const int kSendFlags = 0;   /* the process ignores SIGPIPE */
#endif

bool num(const cr::Json &j, const char *key, double lo, double hi, double *out, std::string *err)
{
    auto it = j.find(key);
    if (it == j.end())
        return true;
    char *end = nullptr;
    const double v = std::strtod(it->second.c_str(), &end);
    if (it->second.empty() || *end || !(v >= lo && v <= hi)) {
        *err = std::string(key) + " must be a number from " + std::to_string((long long)lo) + " to " +
               std::to_string((long long)hi);
        return false;
    }
    *out = v;
    return true;
}

std::string str(const cr::Json &j, const char *key, const std::string &def = "")
{
    auto it = j.find(key);
    return it == j.end() ? def : it->second;
}

bool fnum(const cr::Json &j, const char *key, double lo, double hi, float *out, std::string *err)
{
    double v = *out;
    if (!num(j, key, lo, hi, &v, err))
        return false;
    *out = (float)v;
    return true;
}

/* One of names (its index in *out), or the default when absent. */
bool choice(const cr::Json &j, const char *key, const std::vector<std::string> &names, int *out,
            std::string *err)
{
    auto it = j.find(key);
    if (it == j.end())
        return true;
    for (size_t i = 0; i < names.size(); i++)
        if (it->second == names[i]) {
            *out = (int)i;
            return true;
        }
    *err = std::string(key) + " must be ";
    for (size_t i = 0; i < names.size(); i++)
        *err += (i ? (i + 1 == names.size() ? " or " : ", ") : "") + names[i];
    return false;
}

/* The render state fields onto *look: a mesh part's, or an effect layer's
 * (quad: its depth and culling fields are ignored, as a field the service
 * does not know). A blend field over a preset makes the preset custom. */
bool look_fields(const cr::Json &j, bool quad, PartLook *look, std::string *err, bool stencil = false)
{
    /* in StencilFunc's order */
    static const std::vector<std::string> sfuncs = {"off",  "never",      "always",  "equal",        "not_equal",
                                                    "less", "less_equal", "greater", "greater_equal"};
    static const std::vector<std::string> sops = {"keep", "zero", "replace", "increment",
                                                  "increment_wrap", "decrement", "decrement_wrap", "invert"};
    static const char *const skeys[] = {"stencil_func", "stencil_ref", "stencil_mask",
                                        "stencil_fail", "stencil_depth_fail", "stencil_pass"};
    bool any = false;
    for (const char *k : skeys)
        any = any || j.count(k);
    if (any && !stencil) {
        *err = "stencil fields are for layers in a canvas with depth";
        return false;
    }
    if (any) {
        /* What is not sent is kept: stencil_func its current one (off
         * until one is sent). */
        StencilState &st = look->stencil;
        int func = (int)st.func;
        int fail = (int)st.fail, dfail = (int)st.depth_fail, pass = (int)st.pass;
        double ref = st.ref, mask = st.mask;
        if (!choice(j, "stencil_func", sfuncs, &func, err) || !num(j, "stencil_ref", 0, 255, &ref, err) ||
            !num(j, "stencil_mask", 0, 255, &mask, err) || !choice(j, "stencil_fail", sops, &fail, err) ||
            !choice(j, "stencil_depth_fail", sops, &dfail, err) || !choice(j, "stencil_pass", sops, &pass, err))
            return false;
        if (ref != (double)(int)ref || mask != (double)(int)mask) {
            *err = "stencil_ref and stencil_mask are whole numbers from 0 to 255";
            return false;
        }
        st.func = (StencilFunc)func;
        st.ref = (uint8_t)ref;
        st.mask = (uint8_t)mask;
        st.fail = (StencilOp)fail;
        st.depth_fail = (StencilOp)dfail;
        st.pass = (StencilOp)pass;
    }
    static const std::vector<std::string> presets = {"alpha", "add", "none", "premultiplied", "max", "min", "subtract"};
    static const std::vector<std::string> factors = {"zero",      "one",           "src_alpha",
                                                     "one_minus_src_alpha", "dst_alpha", "one_minus_dst_alpha"};
    static const std::vector<std::string> ops = {"add", "subtract", "reverse_subtract", "min", "max"};
    static const std::vector<std::string> funcs = {"less",    "less_equal",    "equal", "not_equal",
                                                   "greater", "greater_equal", "always", "never"};
    int blend = (int)look->blend;
    if (!choice(j, "blend", presets, &blend, err))
        return false;
    if (j.count("blend")) {
        look->blend = (Blend)blend;
        look->has_custom = false;
    }
    BlendState b = look->blending();
    int src = (int)b.src, dst = (int)b.dst, src_a = (int)b.src_alpha, dst_a = (int)b.dst_alpha;
    int op = (int)b.op, op_a = (int)b.op_alpha;
    if (!choice(j, "blend_src", factors, &src, err) || !choice(j, "blend_dst", factors, &dst, err) ||
        !choice(j, "blend_src_alpha", factors, &src_a, err) || !choice(j, "blend_dst_alpha", factors, &dst_a, err) ||
        !choice(j, "blend_op", ops, &op, err) || !choice(j, "blend_op_alpha", ops, &op_a, err))
        return false;
    if (j.count("blend_src") || j.count("blend_dst") || j.count("blend_src_alpha") || j.count("blend_dst_alpha") ||
        j.count("blend_op") || j.count("blend_op_alpha")) {
        if (!b.on) {
            *err = "blend none takes no blend factors or operations";
            return false;
        }
        b.src = (BlendFactor)src;
        b.dst = (BlendFactor)dst;
        b.src_alpha = (BlendFactor)src_a;
        b.dst_alpha = (BlendFactor)dst_a;
        b.op = (BlendOp)op;
        b.op_alpha = (BlendOp)op_a;
        look->custom = b;
        look->has_custom = true;
    }
    if (j.count("color_mask")) {
        const std::string m = str(j, "color_mask");
        uint8_t bits = 0;
        bool good = !m.empty() && m.size() <= 4;
        for (char ch : m == "none" ? std::string() : m) {
            const uint8_t bit = ch == 'r' ? kMaskR : ch == 'g' ? kMaskG : ch == 'b' ? kMaskB : ch == 'a' ? kMaskA : 0;
            good = good && bit && !(bits & bit);
            bits |= bit;
        }
        if (!good) {
            *err = "color_mask must be none or some of r, g, b and a, each once (rgba: all)";
            return false;
        }
        look->color_mask = bits;
    }
    if (quad)
        return true;
    double depth = look->depth ? 1 : 0, write = look->depth_write ? 1 : 0;
    int func = (int)look->depth_func - 1, cull = look->cull == Cull::Back ? 0 : look->cull == Cull::Front ? 1 : 2;
    if (!num(j, "depth", 0, 1, &depth, err) || !choice(j, "depth_func", funcs, &func, err) ||
        !num(j, "depth_write", 0, 1, &write, err) || !choice(j, "cull", {"back", "front", "none"}, &cull, err))
        return false;
    int draw = (int)look->draw;
    double instances = look->instances;
    if (!choice(j, "draw", {"triangles", "triangle_strip", "lines", "line_loop", "points"}, &draw, err) ||
        !num(j, "instances", 1, kMaxInstances, &instances, err))
        return false;
    if (instances != (double)(uint32_t)instances) {
        *err = "instances is a whole number from 1 to 256";
        return false;
    }
    look->draw = (Draw)draw;
    look->instances = (uint32_t)instances;
    look->depth = depth != 0;
    look->depth_func = (DepthFunc)(func + 1);
    look->depth_write = write != 0;
    look->cull = cull == 0 ? Cull::Back : cull == 1 ? Cull::Front : Cull::None;
    if (!look->depth && (j.count("depth_func") || j.count("depth_write"))) {
        *err = "depth 0 takes no depth_func or depth_write";
        return false;
    }
    return true;
}

/* An asset's sampling, wrap and anisotropy fields (PROTOCOL.md "Client to
 * service"). */
bool sampler_fields(const cr::Json &j, Sampler *s, std::string *err)
{
    int sampling = 0, wrap = 0;
    double aniso = 1;
    if (!choice(j, "sampling",
                {"nearest", "bilinear", "nearest_mips", "bilinear_mips", "trilinear", "min_linear_mag_nearest",
                 "min_nearest_mag_linear"},
                &sampling, err) ||
        !choice(j, "wrap", {"clamp", "repeat", "mirror"}, &wrap, err) || !num(j, "anisotropy", 1, 16, &aniso, err))
        return false;
    int u = wrap, v = wrap;
    if (!choice(j, "wrap_u", {"clamp", "repeat", "mirror"}, &u, err) ||
        !choice(j, "wrap_v", {"clamp", "repeat", "mirror"}, &v, err))
        return false;
    if (aniso != (double)(uint32_t)aniso) {
        *err = "anisotropy must be a whole number from 1 to 16";
        return false;
    }
    s->sampling = (Sampling)sampling;
    s->u = (Wrap)u;
    s->v = (Wrap)v;
    s->anisotropy = (uint32_t)aniso;
    return true;
}

/* A mesh layer's projection and camera fields present in j, over *mp. */
bool mesh_params(const cr::Json &j, MeshParams *mp, std::string *err)
{
    MeshParams m = *mp;
    int ortho = m.projection.ortho ? 1 : 0;
    if (!choice(j, "projection", {"perspective", "ortho"}, &ortho, err))
        return false;
    m.projection.ortho = ortho == 1;
    Projection &p = m.projection;
    if (!fnum(j, "fov", 1, 179, &p.fov, err) || !fnum(j, "ortho_h", 0, 1000000, &p.ortho_h, err) ||
        !fnum(j, "near", 0, 1000000, &p.near, err) || !fnum(j, "far", 0, 1000000, &p.far, err))
        return false;
    if (!(p.near > 0 && p.far > p.near && p.ortho_h > 0)) {
        *err = "near and ortho_h must be above 0, and far above near";
        return false;
    }
    const char *const pos[3] = {"cx", "cy", "cz"}, *const rot[3] = {"crx", "cry", "crz"};
    for (int i = 0; i < 3; i++)
        if (!fnum(j, pos[i], -1000000, 1000000, &m.camera.t[i], err) ||
            !fnum(j, rot[i], -36000, 36000, &m.camera.r[i], err))
            return false;
    *mp = m;
    return true;
}

/* A part's pose fields present in j, over *p. */
bool pose_fields(const cr::Json &j, Pose *p, std::string *err)
{
    Pose n = *p;
    const char *const t[3] = {"tx", "ty", "tz"}, *const r[3] = {"rx", "ry", "rz"}, *const sc[3] = {"sx", "sy", "sz"};
    for (int i = 0; i < 3; i++)
        if (!fnum(j, t[i], -1000000, 1000000, &n.t[i], err) || !fnum(j, r[i], -36000, 36000, &n.r[i], err) ||
            !fnum(j, sc[i], -1000000, 1000000, &n.s[i], err))
            return false;
    *p = n;
    return true;
}

/* Up to max finite numbers separated by spaces, the whole text. */
bool numbers(const std::string &text, size_t max, std::vector<float> *out)
{
    out->clear();
    const char *p = text.c_str();
    for (;;) {
        while (*p == ' ' || *p == '\t' || *p == ',')
            p++;
        if (!*p)
            return !out->empty();
        char *end = nullptr;
        const float f = std::strtof(p, &end);
        if (end == p || !std::isfinite(f) || out->size() >= max)
            return false;
        out->push_back(f);
        p = end;
    }
}

/* A text field's string (UTF-8) into *cps; false with *err when it is
 * too long or not UTF-8. */
bool text_string(const std::string &t, std::vector<uint32_t> *cps, std::string *err)
{
    if (t.size() > TextLayer::kMaxTextBytes) {
        *err = "text is at most " + std::to_string(TextLayer::kMaxTextBytes) + " bytes of UTF-8";
        return false;
    }
    if (!decode_utf8(t, cps)) {
        *err = "text is not UTF-8";
        return false;
    }
    return true;
}

/* A text layer's fields over *st and its string (UTF-8) into *cps when
 * text is there (*has); false with *err, nothing taken, for any out of
 * range. */
bool text_fields(const cr::Json &j, TextStyle *st, std::vector<uint32_t> *cps, bool *has, std::string *err)
{
    TextStyle s = *st;
    int align = (int)s.align;
    if (!fnum(j, "size", 0, 2048, &s.size, err) || !fnum(j, "spacing", -1024, 1024, &s.spacing, err) ||
        !choice(j, "align", {"left", "center", "right"}, &align, err))
        return false;
    s.align = (TextAlign)align;
    if (j.count("color")) {
        std::vector<float> c;
        if (!numbers(str(j, "color"), 4, &c) || c.size() != 4 ||
            std::any_of(c.begin(), c.end(), [](float v) { return v < 0 || v > 1; })) {
            *err = "color is 4 numbers from 0 to 1";
            return false;
        }
        std::copy(c.begin(), c.end(), s.color);
    }
    *has = j.count("text") != 0;
    if (*has && !text_string(str(j, "text"), cps, err))
        return false;
    *st = s;
    return true;
}

/* "t:v[,v,v] t:v ...": times in ms, ascending, every key the same number
 * of values (1 to 4). */
bool parse_keys(const std::string &text, Animation *a, std::string *err)
{
    static const size_t kMaxKeys = 256;
    *err = "keys are t:v[,v,v,v] separated by spaces, t in ms ascending, every key as many values";
    a->t.clear();
    a->v.clear();
    a->width = 0;
    const char *p = text.c_str();
    for (;;) {
        while (*p == ' ' || *p == '\t')
            p++;
        if (!*p)
            break;
        if (*p < '0' || *p > '9')
            return false;
        char *end = nullptr;
        const unsigned long long t = std::strtoull(p, &end, 10);
        if (*end != ':' || t > 0xffffffffull || (!a->t.empty() && t <= a->t.back()) || a->t.size() >= kMaxKeys)
            return false;
        p = end + 1;
        uint32_t n = 0;
        for (;;) {
            const float f = std::strtof(p, &end);
            if (end == p || !std::isfinite(f) || n >= 4)
                return false;
            a->v.push_back(f);
            n++;
            p = end;
            if (*p != ',')
                break;
            p++;
        }
        if (*p && *p != ' ' && *p != '\t')
            return false;
        if (a->width && n != a->width)
            return false;
        a->width = n;
        a->t.push_back((uint32_t)t);
    }
    if (a->t.empty())
        return false;
    err->clear();
    return true;
}

/* An animate message's anim, property (of a value: none, or value),
 * name, loop, interp and keys, its curve sampled; false with *err. */
bool animation_fields(const cr::Json &j, bool of_value, Animation *a, double *anim, std::string *err)
{
    double loop = 0;
    int property = 0, interp = 0;
    if (!num(j, "anim", 1, 4294967295.0, anim, err) || !*anim) {
        if (err->empty())
            *err = "anim (the animation's number, 1 or more) missing";
        return false;
    }
    if (!choice(j, "property", {"rotate", "translate", "scale", "uniform", "value"}, &property, err) ||
        !num(j, "loop", 0, 1, &loop, err) ||
        !choice(j, "interp", {"linear", "step", "ease_in", "ease_out", "ease_in_out", "smooth"}, &interp, err) ||
        !parse_keys(str(j, "keys"), a, err))
        return false;
    if (of_value ? j.count("property") && property != 4 : !j.count("property") || property == 4) {
        *err = of_value ? "a value's animation has no property, or value"
                        : "property must be rotate, translate, scale or uniform";
        return false;
    }
    static const Animated props[] = {Animated::Rotate, Animated::Translate, Animated::Scale, Animated::Uniform,
                                     Animated::Value};
    a->property = of_value ? Animated::Value : props[property];
    a->uniform = str(j, "name");
    a->loop = loop != 0;
    a->step = interp == 1;
    static const Curve curves[] = {Curve::Linear, Curve::Step, Curve::EaseIn, Curve::EaseOut, Curve::EaseInOut,
                                   Curve::Smooth};
    if (!sample_curve(curves[interp], a)) {
        *err = "the curve leaves the numbers a key holds: keys too far apart for " + str(j, "interp");
        return false;
    }
    if (a->property == Animated::Uniform && (a->uniform.empty() || a->uniform.size() > 64)) {
        *err = "a uniform's animation needs its name";
        return false;
    }
    return true;
}

/* The client-settable parameters present in j, over *p. */
bool layer_params(const cr::Json &j, LayerParams *p, std::string *err)
{
    LayerParams n = *p;
    if (j.count("class") && !klass_from_name(j.at("class"), &n.klass)) {
        *err = "class must be ambient, content, overlay or alert";
        return false;
    }
    double v;
    v = n.z;
    if (!num(j, "z", -1000, 1000, &v, err)) return false;
    n.z = (int)v;
    v = n.rect.x;
    if (!num(j, "x", -4096, 4096, &v, err)) return false;
    n.rect.x = (int32_t)v;
    v = n.rect.y;
    if (!num(j, "y", -4096, 4096, &v, err)) return false;
    n.rect.y = (int32_t)v;
    v = n.rect.w;
    if (!num(j, "w", 1, 4096, &v, err)) return false;
    n.rect.w = (uint32_t)v;
    v = n.rect.h;
    if (!num(j, "h", 1, 4096, &v, err)) return false;
    n.rect.h = (uint32_t)v;
    v = n.opacity;
    if (!num(j, "opacity", 0, 1, &v, err)) return false;
    n.opacity = (float)v;
    if (!fnum(j, "rotate", -36000, 36000, &n.rotate, err) || !fnum(j, "sx", -1000, 1000, &n.sx, err) ||
        !fnum(j, "sy", -1000, 1000, &n.sy, err) || !fnum(j, "px", -8192, 8192, &n.px, err) ||
        !fnum(j, "py", -8192, 8192, &n.py, err))
        return false;
    v = n.others_fps;
    if (!num(j, "others_fps", 0, 60, &v, err)) return false;
    n.others_fps = (uint32_t)v;
    if (j.count("hosted")) {
        if (j.at("hosted").size() > 32) {
            *err = "hosted must be a target's name";
            return false;
        }
        n.hosted = j.at("hosted");
    }
    n.pivot_x = n.pivot_x || j.count("px");
    n.pivot_y = n.pivot_y || j.count("py");
    struct Flag { const char *key; bool *field; } flags[] = {
        {"visible", &n.visible}, {"exclusive", &n.exclusive}, {"prewarm", &n.prewarm}, {"preload", &n.preload},
        {"contend", &n.contend}, {"guide_hold", &n.guide_hold}, {"yield", &n.yield}};
    for (const Flag &f : flags) {
        v = *f.field ? 1 : 0;
        if (!num(j, f.key, 0, 1, &v, err)) return false;
        *f.field = v != 0;
    }
    *p = n;
    return true;
}

std::string state_line(LayerState s, const std::string &reason)
{
    return std::string(layer_state_name(s)) + "\n" + reason;
}

}  // namespace

Server::Server(Compositor *comp, SlotManager *slots, const std::string &backend)
    : comp_(comp), slots_(slots), backend_(backend)
{
}

Server::~Server()
{
    for (Client &c : clients_)
        close(c.fd);
    if (listen_fd_ >= 0)
        close(listen_fd_);
    if (own_path_)
        unlink(path_.c_str());
}

bool Server::listen(const std::string &path, unsigned mode, const std::string &group, std::string *err)
{
    /* systemd socket activation: fd 3, LISTEN_PID = us. */
    const char *pid = getenv("LISTEN_PID");
    const char *fds = getenv("LISTEN_FDS");
    if (pid && fds && atoi(pid) == (int)getpid() && atoi(fds) >= 1) {
        listen_fd_ = 3;
        nonblocking(listen_fd_);
        log_info("socket from systemd");
        return true;
    }
    struct sockaddr_un addr;
    std::memset(&addr, 0, sizeof addr);
    addr.sun_family = AF_UNIX;
    if (path.size() >= sizeof addr.sun_path) {
        *err = "socket path too long";
        return false;
    }
    std::strcpy(addr.sun_path, path.c_str());
    const std::string dir = path.substr(0, path.rfind('/'));
    if (!dir.empty())
        mkdir(dir.c_str(), 0755);
    unlink(path.c_str());
    listen_fd_ = socket(AF_UNIX, SOCK_STREAM, 0);
    if (listen_fd_ >= 0)
        nonblocking(listen_fd_);
    if (listen_fd_ < 0 || bind(listen_fd_, (struct sockaddr *)&addr, sizeof addr) < 0 || ::listen(listen_fd_, 8) < 0) {
        *err = "socket " + path + ": " + strerror(errno);
        return false;
    }
    own_path_ = true;
    path_ = path;
    if (!group.empty()) {
        struct group *g = getgrnam(group.c_str());
        if (!g || chown(path.c_str(), (uid_t)-1, g->gr_gid) < 0)
            log_warn("cannot give %s to group %s", path.c_str(), group.c_str());
    }
    chmod(path.c_str(), mode);
    log_info("listening on %s", path.c_str());
    return true;
}

void Server::poll_fds(std::vector<pollfd> *fds) const
{
    fds->push_back(pollfd{listen_fd_, POLLIN, 0});
    for (const Client &c : clients_)
        fds->push_back(pollfd{c.fd, (short)(POLLIN | (c.out.empty() ? 0 : POLLOUT)), 0});
}

void Server::handle(const std::vector<pollfd> &fds, size_t first, int64_t now_ms)
{
    const size_t n = clients_.size();
    for (size_t i = 0; i < n && first + 1 + i < fds.size(); i++) {
        Client &c = clients_[i];
        const short re = fds[first + 1 + i].revents;
        if (re & POLLOUT)
            write_client(c);
        if (re & (POLLIN | POLLHUP | POLLERR))
            read_client(c, now_ms);
    }
    for (size_t i = clients_.size(); i-- > 0;)
        if (clients_[i].closing)
            drop_client(i);
    if (fds.size() > first && (fds[first].revents & POLLIN))
        accept_client(now_ms);
}

void Server::accept_client(int64_t)
{
    for (;;) {
        int fd = accept(listen_fd_, nullptr, nullptr);
        if (fd < 0)
            return;
        nonblocking(fd);
        if (clients_.size() >= kMaxClients) {
            log_warn("client refused: %zu connected", clients_.size());
            close(fd);
            continue;
        }
        /* Room for a whole video frame in flight (the kernel caps it). */
        int buf = 1 << 20;
        setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &buf, sizeof buf);
        Client c;
        c.fd = fd;
        c.id = next_client_++;
        clients_.push_back(std::move(c));
    }
}

void Server::drop_client(size_t i)
{
    Client &c = clients_[i];
    if (!c.app.empty() || !c.refs.empty())   /* not a status request */
        log_info("client %llu (%s) gone, %zu layers and %zu assets removed", (unsigned long long)c.id,
                 c.app.empty() ? "?" : c.app.c_str(), c.refs.size(), c.assets.size());
    comp_->remove_owner(c.id);
    for (auto &kv : c.shm)
        unmap(&kv.second);
    for (int fd : c.fds)
        close(fd);
    close(c.fd);
    clients_.erase(clients_.begin() + i);
}

void Server::read_client(Client &c, int64_t now_ms)
{
    /* At most a few messages' worth per pass, so one busy producer cannot
     * hold the render loop. */
    size_t budget = 4 << 20;
    for (;;) {
        ssize_t r = c.in.fill(c.fd, &c.fds);
        while (c.fds.size() > cr::kShmMaxSlots) {   /* more than an op takes at once: not kept */
            close(c.fds.front());
            c.fds.pop_front();
        }
        if (r == 0 || (r < 0 && errno != EAGAIN && errno != EINTR)) {
            c.closing = true;
            break;
        }
        if (r < 0)
            break;
        for (;;) {
            size_t body_len = 0;
            uint8_t type = 0;
            const char *body = nullptr;
            bool bad = false;
            if (!c.in.next(&type, &body, &body_len, &bad)) {
                if (bad) {
                    log_warn("client %llu: malformed message, disconnected", (unsigned long long)c.id);
                    c.closing = true;
                }
                break;
            }
            if (type == cr::kJson)
                on_json(c, std::string(body, body_len), now_ms);
            else if (type == cr::kFrame)
                on_frame(c, body, body_len, now_ms);
            else if (type == cr::kMesh)
                on_mesh(c, body, body_len, now_ms);
            if (c.closing)
                break;
        }
        c.in.settle();
        if (c.closing || (size_t)r >= budget)
            break;
        budget -= (size_t)r;
    }
}

void Server::write_client(Client &c)
{
    while (!c.out.empty()) {
        ssize_t w = ::send(c.fd, c.out.data(), c.out.size(), kSendFlags);
        if (w < 0) {
            if (errno != EAGAIN && errno != EINTR)
                c.closing = true;
            return;
        }
        c.out.erase(0, (size_t)w);
    }
}

void Server::send(Client &c, const std::string &json)
{
    if (c.closing)
        return;
    c.out += cr::encode(cr::kJson, json);
    if (c.out.size() > kMaxOutput) {
        log_warn("client %llu (%s) does not read its events, disconnected", (unsigned long long)c.id, c.app.c_str());
        c.closing = true;
        return;
    }
    write_client(c);
}

void Server::error(Client &c, const std::string &op, uint32_t ref, const std::string &why)
{
    send(c, cr::json_object({{"ev", cr::json_quote("error")},
                             {"op", cr::json_quote(op)},
                             {"ref", std::to_string(ref)},
                             {"reason", cr::json_quote(why)}}));
}

void Server::error(Client &c, const std::string &op, uint32_t ref, const std::string &why, const std::string &line)
{
    send(c, cr::json_object({{"ev", cr::json_quote("error")},
                             {"op", cr::json_quote(op)},
                             {"ref", std::to_string(ref)},
                             {"reason", cr::json_quote(why)},
                             {"line", cr::json_quote(line)}}));
}

std::string Server::scene_reason(const Client &c, uint32_t layer) const
{
    const Layer *l = comp_->layer(c.id, layer);
    const uint32_t scene = l ? comp_->scene_on(l->target()) : 0;
    const uint64_t owner = comp_->owner_of(scene);
    for (const Client &o : clients_) {
        if (!scene || o.id != owner)
            continue;
        for (const auto &kv : o.refs)
            if (&o == &c && kv.second == scene)
                return "scene " + std::to_string(kv.first);
        return "scene of " + (o.app.empty() ? std::string("?") : o.app);
    }
    return "scene";
}

bool Server::apply(Layer *l, const cr::Json &j, std::string *err)
{
    LayerParams p = l->params;
    if (!layer_params(j, &p, err))
        return false;
    /* An effect layer's render state; on other layers its fields are
     * ignored (a mesh part's is set by its part message). */
    EffectLayer *fx = std::string(l->kind()) == "effect" ? static_cast<EffectLayer *>(l) : nullptr;
    PartLook look = fx ? fx->look() : PartLook();
    if (fx && !look_fields(j, true, &look, err, stencil_ok(l->params)))
        return false;
    MeshLayer *m = std::string(l->kind()) == "mesh" ? static_cast<MeshLayer *>(l) : nullptr;
    MeshParams mp;
    if (m) {
        mp = m->mesh;
        if (j.count("projection") && (j.at("projection") == "ortho") != mp.projection.ortho) {
            *err = "a mesh layer's projection is set when it is made";
            return false;
        }
        if (!mesh_params(j, &mp, err))
            return false;
    }
    if (!comp_->check(l, p, err))
        return false;
    if (m)
        m->mesh = mp;
    if (fx && look != fx->look())
        fx->set_look(look);
    l->params = p;
    comp_->changed(l);
    return true;
}

void Server::op_layer(Client &c, const cr::Json &j, int64_t now_ms)
{
    double ref_d = 0;
    std::string err;
    if (!num(j, "ref", 1, 4294967295.0, &ref_d, &err) || ref_d == 0) {
        error(c, "layer", 0, err.empty() ? "ref missing" : err);
        return;
    }
    const uint32_t ref = (uint32_t)ref_d;
    if (c.refs.count(ref) || c.assets.count(ref)) {
        error(c, "layer", ref, "ref in use");
        return;
    }
    const int target = slots_->index(str(j, "target"));
    if (target < 0 || !slots_->targets()[target].follows.empty()) {
        error(c, "layer", ref, "unknown target " + str(j, "target"));
        return;
    }
    const TargetSpec &spec = slots_->targets()[target];
    LayerParams lp;
    lp.rect.w = spec.width;
    lp.rect.h = spec.height;
    const std::string kind = str(j, "kind");
    if (j.count("canvas")) {
        /* Drawn in the client's canvas, its rect in the canvas's pixels. */
        double cref = 0;
        num(j, "canvas", 0, 4294967295.0, &cref, &err);
        auto a = c.assets.find((uint32_t)cref);
        const Canvas *cv = a == c.assets.end() ? nullptr : comp_->canvas(a->second);
        if (!cv) {
            error(c, "layer", ref, "no such canvas");
            return;
        }
        if (kind != "effect" && kind != "mesh") {
            error(c, "layer", ref, "only effect and mesh layers draw in a canvas");
            return;
        }
        lp.canvas = cv->id();
        lp.rect.w = cv->spec().w;
        lp.rect.h = cv->spec().h;
    }
    if (!layer_params(j, &lp, &err)) {
        error(c, "layer", ref, err);
        return;
    }
    uint32_t id = 0;
    double v;
    if (kind == "video") {
        VideoParams vp;
        struct { const char *key; double lo, hi; double cur; } k[] = {
            {"vw", 64, 1920, (double)vp.w},           {"vh", 32, 720, (double)vp.h},
            {"fps", 0, 60, (double)vp.fps},           {"level_bits", 0, 3, (double)vp.level_bits},
            {"dirty_threshold", 0, 64, (double)vp.dirty_threshold},
            {"settle_ms", 0, 3600000, (double)vp.dirty_settle_ms},
            {"pan_blocks", 0, 1, vp.pan_blocks ? 1.0 : 0.0}, {"stall_ms", 1000, 600000, (double)vp.stall_ms},
            {"always_packed", 0, 1, vp.always_packed ? 1.0 : 0.0}};
        for (auto &e : k)
            if (!num(j, e.key, e.lo, e.hi, &e.cur, &err)) {
                error(c, "layer", ref, err);
                return;
            }
        vp.w = (uint32_t)k[0].cur;
        vp.h = (uint32_t)k[1].cur;
        vp.fps = (uint32_t)k[2].cur;
        vp.level_bits = (uint32_t)k[3].cur;
        vp.dirty_threshold = (uint32_t)k[4].cur;
        vp.dirty_settle_ms = (int)k[5].cur;
        vp.pan_blocks = k[6].cur != 0;
        vp.stall_ms = (int)k[7].cur;
        vp.always_packed = k[8].cur != 0;
        id = comp_->add_video(c.id, target, lp, vp, now_ms, &err);
    } else if (kind == "image") {
        double iw = lp.rect.w, ih = lp.rect.h, fps = 30;
        if (!num(j, "iw", 1, 1920, &iw, &err) || !num(j, "ih", 1, 720, &ih, &err) ||
            !num(j, "fps", 0, 60, &fps, &err)) {
            error(c, "layer", ref, err);
            return;
        }
        const std::string s = str(j, "sampling", "nearest");
        if (s != "nearest" && s != "bilinear") {
            error(c, "layer", ref, "sampling must be nearest or bilinear");
            return;
        }
        id = comp_->add_image(c.id, target, lp, (uint32_t)iw, (uint32_t)ih, (uint32_t)fps,
                              s == "nearest" ? Sampling::Nearest : Sampling::Bilinear, now_ms, &err);
    } else if (kind == "effect") {
        v = 0;
        double clock = 0;
        if (!num(j, "time_fps", 0, 60, &v, &err) || !num(j, "time", 0, 1, &clock, &err)) {
            error(c, "layer", ref, err);
            return;
        }
        if (v && clock) {
            error(c, "layer", ref, "time and time_fps exclude each other");
            return;
        }
        if (str(j, "fs").empty()) {
            error(c, "layer", ref, "fs (the fragment shader) missing");
            return;
        }
        PartLook look = quad_look();
        if (!look_fields(j, true, &look, &err, stencil_ok(lp))) {
            error(c, "layer", ref, err);
            return;
        }
        id = comp_->add_effect(c.id, target, lp, str(j, "vs"), str(j, "fs"), (uint32_t)v, now_ms, &err);
        if (id && clock)
            static_cast<EffectLayer *>(comp_->layer(c.id, id))->cluster_time();
        /* also while it is the default: stencil fields sent with the
         * stencil off are kept for when stencil_func turns it on */
        if (id)
            static_cast<EffectLayer *>(comp_->layer(c.id, id))->set_look(look);
    } else if (kind == "mesh") {
        MeshParams mp;
        if (!mesh_params(j, &mp, &err)) {
            error(c, "layer", ref, err);
            return;
        }
        id = comp_->add_mesh(c.id, target, lp, mp, now_ms, &err);
    } else if (kind == "text") {
        double font_ref = 0, max = TextLayer::kDefaultGlyphs;
        TextStyle st;
        std::vector<uint32_t> cps;
        bool has = false;
        /* the string checked on its own: refused, the layer is made empty */
        cr::Json style = j;
        style.erase("text");
        if (!num(j, "font", 0, 4294967295.0, &font_ref, &err) ||
            !num(j, "max", 1, TextLayer::kMaxGlyphs, &max, &err) || !text_fields(style, &st, &cps, &has, &err)) {
            error(c, "layer", ref, err);
            return;
        }
        std::string text_err;
        if (j.count("text") && !text_string(str(j, "text"), &cps, &text_err))
            cps.clear();
        auto f = c.assets.find((uint32_t)font_ref);
        id = comp_->add_text(c.id, target, lp, f == c.assets.end() ? 0 : f->second, (uint32_t)max, now_ms, &err);
        if (id) {
            TextLayer *t = static_cast<TextLayer *>(comp_->layer(c.id, id));
            t->set_style(st);
            t->set_text(std::move(cps));
            if (!text_err.empty())
                error(c, "text", ref, text_err);
        }
    } else {
        error(c, "layer", ref, "kind must be video, image, effect, mesh or text");
        return;
    }
    if (!id) {
        error(c, "layer", ref, err);
        return;
    }
    c.refs[ref] = id;
    log_info("client %llu (%s): %s layer %u on %s (%s, z %d)", (unsigned long long)c.id, c.app.c_str(), kind.c_str(),
             id, spec.name.c_str(), klass_name(lp.klass), lp.z);
}

void Server::on_json(Client &c, const std::string &body, int64_t now_ms)
{
    cr::Json j;
    if (!cr::parse_json(body, &j)) {
        error(c, "?", 0, "not a flat JSON object");
        return;
    }
    const std::string op = str(j, "op");
    if (op == "hello") {
        c.app = str(j, "app", "?").substr(0, 64);
        std::string targets;
        for (const TargetSpec &t : slots_->targets())
            if (t.follows.empty())
                targets += (targets.empty() ? "" : ",") + t.name + ":" + std::to_string(t.width) + "x" +
                           std::to_string(t.height);
        send(c, cr::json_object({{"ev", cr::json_quote("hello")},
                                 {"proto", std::to_string(cr::kProtocolVersion)},
                                 {"backend", cr::json_quote(backend_)},
                                 {"targets", cr::json_quote(targets)},
                                 {"repeat", "1"},
                                 {"always_packed", "1"},
                                 {"host_edge", "1"},
                                 {"preload", "1"},
                                 {"others_fps", "1"},
                                 {"render_state", "1"},
                                 {"samplers", "1"},
                                 {"host_layers", "1"},
                                 {"canvas", "1"},
                                 {"curves", "1"},
                                 {"nodes", "1"},
                                 {"draw", "1"},
                                 {"instances", comp_->instancing() ? "1" : "0"},
                                 {"cube", "1"},
                                 {"values", "1"},
                                 {"text", comp_->texts() ? "1" : "0"},
                                 {"scene_anim", comp_->sequences() ? "1" : "0"},
                                 {"over_order", "1"},
#ifdef __linux__
                                 {"shm_frames", "1"},
#endif
                             }));
        c.target_sent.clear();
        c.fps_cap_sent = 0;
        c.host_sent.clear();
        c.hosting_sent.clear();
        c.host_gen = 0;
        log_info("client %llu: %s", (unsigned long long)c.id, c.app.c_str());
        return;
    }
    if (op == "layer") {
        op_layer(c, j, now_ms);
        return;
    }
    if (op == "status") {
        send(c, cr::json_object({{"ev", cr::json_quote("status")}, {"text", cr::json_quote(status_text(now_ms))}}));
        return;
    }
    if (op == "asset") {
        op_asset(c, j);
        return;
    }
    if (op == "canvas") {
        op_canvas(c, j);
        return;
    }
    if (op == "value") {
        op_value(c, j);
        return;
    }
    if (op == "font") {
        op_font(c, j);
        return;
    }
    if (op == "scene") {
        op_scene(c, j);
        return;
    }
    double ref_d = 0;
    std::string err;
    num(j, "ref", 0, 4294967295.0, &ref_d, &err);
    const uint32_t ref = (uint32_t)ref_d;
    auto it = c.refs.find(ref);
    if (op == "edit") {
        op_edit(c, ref, j);
        return;
    }
    if (op == "host") {
        op_host(c, ref, j);
        return;
    }
    if (op == "unhost") {
        op_unhost(c, ref, j);
        return;
    }
    if (op == "drop" && it != c.refs.end() && comp_->edits(c.id, it->second)) {
        comp_->remove(c.id, it->second);
        log_info("client %llu (%s): scene %u dropped", (unsigned long long)c.id, c.app.c_str(), it->second);
        c.refs.erase(it);
        c.layer_sent.erase(ref);
        return;
    }
    Layer *l = it == c.refs.end() ? nullptr : comp_->layer(c.id, it->second);
    if (op == "shm") {
        op_shm(c, ref, l, j);
        return;
    }
    if (op == "slot") {
        op_slot(c, ref, l, j, now_ms);
        return;
    }
    auto va = c.assets.find(ref);
    if ((op == "animate" || op == "stop") && va != c.assets.end() && comp_->value(c.id, va->second)) {
        double anim_d = 0;
        Animation a;
        if (op == "stop") {
            num(j, "anim", 0, 4294967295.0, &anim_d, &err);
            if (!anim_d || !comp_->stop_value(c.id, va->second, (uint32_t)anim_d))
                error(c, op, ref, "no such animation");
        } else if (!animation_fields(j, true, &a, &anim_d, &err) ||
                   !comp_->animate_value(c.id, va->second, (uint32_t)anim_d, a, &err)) {
            error(c, op, ref, err);
        }
        return;
    }
    if (op == "repeat") {
        const bool video = l && std::string(l->kind()) == "video";
        if (video)
            static_cast<VideoLayer *>(l)->repeat(now_ms);
        /* Answered at most once per ref, as frames are (on_frame). */
        const std::string why = video ? "" : l ? "only a video layer repeats a frame" : "no such layer";
        std::string &last = c.frame_error[l ? ref : 0];
        if (!why.empty() && why != last)
            error(c, op, ref, why);
        last = why;
        return;
    }
    if (op == "drop") {
        auto a = c.assets.find(ref);
        if (a != c.assets.end()) {
            if (!comp_->remove_asset(c.id, a->second, &err)) {
                error(c, op, ref, err);
                return;
            }
            c.assets.erase(a);
            c.frame_error.erase(ref);
            return;
        }
    }
    static const char *const ops[] = {"set", "uniform", "drop", "bind", "link", "part", "transform", "animate", "stop",
                                      "text"};
    if (std::find(std::begin(ops), std::end(ops), op) == std::end(ops)) {
        error(c, op, ref, "unknown op");
        return;
    }
    if (!l) {
        error(c, op, ref, "no such layer");
        return;
    }
    if (op == "drop") {
        comp_->remove(c.id, it->second);
        c.refs.erase(it);
        c.layer_sent.erase(ref);
        c.frame_error.erase(ref);
        auto m = c.shm.find(ref);
        if (m != c.shm.end()) {
            unmap(&m->second);
            c.shm.erase(m);
        }
        return;
    }
    op_on_layer(c, op, ref, l, j);
}

namespace {

#ifdef __linux__
/* fd's seals forbid shrinking it; false for a file that takes no seals. */
bool seals_shrink(int fd)
{
    const int seals = fcntl(fd, F_GET_SEALS);
    return seals >= 0 && (seals & F_SEAL_SHRINK) != 0;
}
#endif

}  // namespace

void Server::unmap(Client::Shm *m)
{
    if (m->map)
        munmap(m->map, m->size);
    m->map = nullptr;
}

void Server::op_shm(Client &c, uint32_t ref, Layer *l, const cr::Json &j)
{
    int fd = -1;
    if (!c.fds.empty()) {
        fd = c.fds.front();
        c.fds.pop_front();
    }
    const bool video = l && std::string(l->kind()) == "video";
    const unsigned slots = (unsigned)std::strtoul(str(j, "slots").c_str(), nullptr, 10);
    const size_t slot_bytes = video ? static_cast<VideoLayer *>(l)->frame_bytes() : 0;
    const size_t size = cr::kShmHeader + (size_t)slots * slot_bytes;
    std::string why;
    struct stat st;
    if (!video)
        why = l ? "only a video layer takes shared frames" : "no such layer";
    else if (fd < 0)
        why = "no descriptor passed";
    else if (slots < 1 || slots > cr::kShmMaxSlots)
        why = "slots must be from 1 to " + std::to_string(cr::kShmMaxSlots);
    else if (fstat(fd, &st) != 0 || !S_ISREG(st.st_mode) || (size_t)st.st_size != size)
        why = "the buffer is not " + std::to_string(size) + " bytes";
#ifdef __linux__
    else if (!seals_shrink(fd))   /* it can never shrink under the mapping */
        why = "the buffer is not sealed against shrinking";
#else
    else
        why = "no shared frames on this system";
#endif
    Client::Shm m;
    if (why.empty()) {
        void *p = mmap(nullptr, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
        if (p == MAP_FAILED) {
            why = std::string("mmap: ") + std::strerror(errno);
        } else {
            m.map = static_cast<uint8_t *>(p);
            m.size = size;
            m.slot_bytes = slot_bytes;
            m.slots = slots;
        }
    }
    if (fd >= 0)
        close(fd);
    auto old = c.shm.find(ref);
    if (old != c.shm.end()) {
        unmap(&old->second);
        c.shm.erase(old);
    }
    if (why.empty())
        c.shm[ref] = m;
    send(c, cr::json_object({{"ev", cr::json_quote("shm")}, {"ref", std::to_string(ref)},
                             {"ok", why.empty() ? "1" : "0"}, {"reason", cr::json_quote(why)}}));
}

void Server::op_slot(Client &c, uint32_t ref, Layer *l, const cr::Json &j, int64_t now_ms)
{
    auto m = c.shm.find(ref);
    const unsigned k = (unsigned)std::strtoul(str(j, "slot").c_str(), nullptr, 10);
    std::string why;
    if (m == c.shm.end() || !l || std::string(l->kind()) != "video")
        why = "no shared frames for this layer";
    else if (k >= m->second.slots)
        why = "no such slot";
    else if (static_cast<VideoLayer *>(l)->frame_bytes() != m->second.slot_bytes)
        why = "the layer's frames are another size";
    if (why.empty()) {
        static_cast<VideoLayer *>(l)->offer(m->second.map + cr::kShmHeader + (size_t)k * m->second.slot_bytes, now_ms);
        /* Copied out: the client may fill the slot again. */
        __atomic_store_n(reinterpret_cast<uint32_t *>(m->second.map) + k, 0u, __ATOMIC_RELEASE);
        m->second.frames++;
    }
    std::string &last = c.frame_error[l ? ref : 0];
    if (!why.empty() && why != last)
        error(c, "slot", ref, why);
    last = why;
}

bool Server::stencil_ok(const LayerParams &p) const
{
    const Canvas *cv = p.canvas ? comp_->canvas(p.canvas) : nullptr;
    return cv && cv->spec().depth;
}

void Server::op_canvas(Client &c, const cr::Json &j)
{
    double ref_d = 0, w = 0, h = 0, depth = 0, once = 0;
    std::string err;
    if (!num(j, "ref", 1, 4294967295.0, &ref_d, &err) || ref_d == 0) {
        error(c, "canvas", 0, err.empty() ? "ref missing" : err);
        return;
    }
    const uint32_t ref = (uint32_t)ref_d;
    if (c.refs.count(ref) || c.assets.count(ref)) {
        error(c, "canvas", ref, "ref in use");
        return;
    }
    const int target = slots_->index(str(j, "target"));
    if (target < 0 || !slots_->targets()[target].follows.empty()) {
        error(c, "canvas", ref, "unknown target " + str(j, "target"));
        return;
    }
    CanvasSpec cs;
    if (!num(j, "w", 1, Canvas::kMaxSide, &w, &err) || !num(j, "h", 1, Canvas::kMaxSide, &h, &err) ||
        !num(j, "depth", 0, 1, &depth, &err) || !num(j, "once", 0, 1, &once, &err) ||
        !sampler_fields(j, &cs.sampler, &err)) {
        error(c, "canvas", ref, err);
        return;
    }
    if (!w || !h || w != (double)(uint32_t)w || h != (double)(uint32_t)h) {
        error(c, "canvas", ref, "a canvas needs w and h, whole numbers");
        return;
    }
    if (j.count("clear")) {
        std::vector<float> v;
        if (!numbers(str(j, "clear"), 4, &v) || v.size() != 4) {
            error(c, "canvas", ref, "clear is four numbers from 0 to 1");
            return;
        }
        for (int k = 0; k < 4; k++)
            cs.clear[k] = v[k];
    }
    cs.w = (uint32_t)w;
    cs.h = (uint32_t)h;
    cs.depth = depth != 0;
    cs.once = once != 0;
    const uint32_t id = comp_->add_canvas(c.id, target, cs, &err);
    if (!id) {
        error(c, "canvas", ref, err);
        return;
    }
    c.assets[ref] = id;
    log_info("client %llu (%s): canvas %u on %s (%ux%u%s%s)", (unsigned long long)c.id, c.app.c_str(), id,
             slots_->targets()[target].name.c_str(), cs.w, cs.h, cs.depth ? ", depth" : "", cs.once ? ", once" : "");
}

void Server::op_value(Client &c, const cr::Json &j)
{
    double ref_d = 0;
    std::string err;
    if (!num(j, "ref", 1, 4294967295.0, &ref_d, &err) || ref_d == 0) {
        error(c, "value", 0, err.empty() ? "ref missing" : err);
        return;
    }
    const uint32_t ref = (uint32_t)ref_d;
    auto a = c.assets.find(ref);
    const Compositor::ValueEntry *ve = a == c.assets.end() ? nullptr : comp_->value(c.id, a->second);
    if (c.refs.count(ref) || (a != c.assets.end() && !ve)) {
        error(c, "value", ref, "ref in use");
        return;
    }
    int type = 0;
    if (!choice(j, "type", {"float", "vec2", "vec3", "vec4"}, &type, &err)) {
        error(c, "value", ref, err);
        return;
    }
    const uint32_t width = ve ? ve->width : (uint32_t)type + 1;
    if (ve && ((j.count("type") && (uint32_t)type + 1 != width) ||
               (j.count("target") && slots_->index(str(j, "target")) != ve->target))) {
        error(c, "value", ref, "a value's type and target are set when it is made");
        return;
    }
    std::vector<float> v(width, 0.0f);
    if ((j.count("v") || ve) && (!numbers(str(j, "v"), width, &v) || v.size() != width)) {
        error(c, "value", ref, "v is " + std::to_string(width) + " finite number" + (width > 1 ? "s" : ""));
        return;
    }
    if (ve) {
        if (!comp_->set_value(c.id, a->second, v.data(), &err))
            error(c, "value", ref, err);
        return;
    }
    const int target = slots_->index(str(j, "target"));
    if (target < 0 || !slots_->targets()[target].follows.empty()) {
        error(c, "value", ref, "unknown target " + str(j, "target"));
        return;
    }
    const uint32_t id = comp_->add_value(c.id, target, width, v.data(), &err);
    if (!id) {
        error(c, "value", ref, err);
        return;
    }
    c.assets[ref] = id;
}

void Server::op_font(Client &c, const cr::Json &j)
{
    double ref_d = 0, asset = 0, line = 0, sdf = 0;
    std::string err;
    if (!num(j, "ref", 1, 4294967295.0, &ref_d, &err) || ref_d == 0) {
        error(c, "font", 0, err.empty() ? "ref missing" : err);
        return;
    }
    const uint32_t ref = (uint32_t)ref_d;
    if (c.refs.count(ref) || c.assets.count(ref)) {
        error(c, "font", ref, "ref in use");
        return;
    }
    if (!num(j, "asset", 0, 4294967295.0, &asset, &err) || !num(j, "line", 0, Font::kMaxLine, &line, &err) ||
        !num(j, "sdf", 0, Font::kMaxSdf, &sdf, &err)) {
        error(c, "font", ref, err);
        return;
    }
    auto a = c.assets.find((uint32_t)asset);
    const Asset *at = a == c.assets.end() ? nullptr : comp_->asset(c.id, a->second);
    if (!at) {
        error(c, "font", ref, "no such asset");
        return;
    }
    Font f;
    if (!parse_font(str(j, "glyphs"), str(j, "kerning"), at->params().w, at->params().h, (uint32_t)line,
                    (uint32_t)sdf, &f, &err)) {
        error(c, "font", ref, err);
        return;
    }
    const uint32_t id = comp_->add_font(c.id, a->second, std::move(f), &err);
    if (!id) {
        error(c, "font", ref, err);
        return;
    }
    c.assets[ref] = id;
}

void Server::op_asset(Client &c, const cr::Json &j)
{
    double ref_d = 0, w = 0, h = 0;
    std::string err;
    if (!num(j, "ref", 1, 4294967295.0, &ref_d, &err) || ref_d == 0) {
        error(c, "asset", 0, err.empty() ? "ref missing" : err);
        return;
    }
    const uint32_t ref = (uint32_t)ref_d;
    if (c.refs.count(ref) || c.assets.count(ref)) {
        error(c, "asset", ref, "ref in use");
        return;
    }
    const int target = slots_->index(str(j, "target"));
    if (target < 0 || !slots_->targets()[target].follows.empty()) {
        error(c, "asset", ref, "unknown target " + str(j, "target"));
        return;
    }
    AssetParams ap;
    int format = 0;
    if (!num(j, "w", 1, 2048, &w, &err) || !num(j, "h", 1, 2048, &h, &err) ||
        !choice(j, "format", {"rgba8", "r8", "etc2rgba", "etc2rgb"}, &format, &err) ||
        !sampler_fields(j, &ap.sampler, &err)) {
        error(c, "asset", ref, err);
        return;
    }
    if (!w || !h) {
        error(c, "asset", ref, "an asset needs w and h");
        return;
    }
    ap.w = (uint32_t)w;
    ap.h = (uint32_t)h;
    static const TexFormat kFormats[] = {TexFormat::RGBA8, TexFormat::R8, TexFormat::ETC2RGBA, TexFormat::ETC2RGB};
    ap.format = kFormats[format];
    double cube = 0;
    if (!num(j, "cube", 0, 1, &cube, &err)) {
        error(c, "asset", ref, err);
        return;
    }
    ap.cube = cube != 0;
    const uint32_t id = comp_->add_asset(c.id, target, ap, &err);
    if (!id) {
        error(c, "asset", ref, err);
        return;
    }
    c.assets[ref] = id;
    log_info("client %llu (%s): asset %u on %s (%s %ux%u, %u levels)", (unsigned long long)c.id, c.app.c_str(), id,
             slots_->targets()[target].name.c_str(), tex_format_name(ap.format), ap.w, ap.h, ap.levels());
}

void Server::op_scene(Client &c, const cr::Json &j)
{
    double ref_d = 0, contend = 0;
    std::string err;
    if (!num(j, "ref", 1, 4294967295.0, &ref_d, &err) || ref_d == 0) {
        error(c, "scene", 0, err.empty() ? "ref missing" : err);
        return;
    }
    const uint32_t ref = (uint32_t)ref_d;
    /* Sent again with its ref: the file replaced in place, its edits gone. */
    auto it = c.refs.find(ref);
    const uint32_t again = it != c.refs.end() && comp_->edits(c.id, it->second) ? it->second : 0;
    if ((it != c.refs.end() && !again) || c.assets.count(ref)) {
        error(c, "scene", ref, "ref in use");
        return;
    }
    const int target = slots_->index(str(j, "target"));
    if (target < 0 || !slots_->targets()[target].follows.empty()) {
        error(c, "scene", ref, "unknown target " + str(j, "target"));
        return;
    }
    const TargetSpec &spec = slots_->targets()[target];
    if (!spec.scene_files) {
        error(c, "scene", ref, "target " + spec.name + " takes no scene files (" + spec.name + "_scene_files)");
        return;
    }
    if (again && comp_->scene_target(again) != target) {
        error(c, "scene", ref, "a scene's target is set when it is made");
        return;
    }
    SceneSource src;
    SceneLayers layers;
    double on = 0, order = 0, over = 0;
    if (!num(j, "contend", 0, 1, &contend, &err) || !num(j, "layers", 0, 1, &on, &err) ||
        !num(j, "layers_order", kLowestLayersOrder, INT32_MAX - 1024, &order, &err) ||
        !num(j, "over_order", kLowestLayersOrder, INT32_MAX - 1024, &over, &err) ||
        !check_scene_source(scene_files_, str(j, "file"), str(j, "res"), str(j, "sha256"), &src, &err)) {
        log_warn("client %llu (%s): scene file refused: %s", (unsigned long long)c.id, c.app.c_str(), err.c_str());
        error(c, "scene", ref, err);
        return;
    }
    const uint32_t id = again ? again : comp_->add_scene(c.id, target, src, contend != 0, &err);
    if (!id) {
        error(c, "scene", ref, err);
        return;
    }
    if (again)
        comp_->replace_scene(c.id, id, src, contend != 0);
    layers.on = on != 0;
    layers.order_set = j.count("layers_order") != 0;
    layers.order = (int32_t)order;
    layers.over_set = j.count("over_order") != 0;
    layers.over = (int32_t)over;
    comp_->set_layers(id, layers);
    c.refs[ref] = id;
    c.layer_sent.erase(ref);   /* its state again, even unchanged: send the values again then */
    log_info("client %llu (%s): scene %u %s%s", (unsigned long long)c.id, c.app.c_str(), id,
             comp_->scene_text(id).c_str(), again ? " (replaced)" : "");
}

void Server::op_host(Client &c, uint32_t ref, const cr::Json &j)
{
    /* With into: the client's layers there host, no scene (PROTOCOL.md
     * "Hosting from layers"). */
    const bool from_layers = j.count("into") != 0;
    const int hosted = slots_->index(str(j, "target"));
    const bool known = hosted >= 0 && slots_->targets()[hosted].follows.empty();
    uint32_t scene = 0;
    if (!from_layers) {
        auto it = c.refs.find(ref);
        scene = it != c.refs.end() && comp_->edits(c.id, it->second) ? it->second : 0;
    }
    /* A refusal names the target (and into), and ends what this scene, or
     * this client's layers from any into, hosted of it: the client forgets
     * it too. */
    auto refuse = [&](const std::string &why) {
        if (known && from_layers)
            comp_->unhost_layers(c.id, hosted);
        else if (known && scene)
            comp_->unhost(c.id, scene, hosted);
        std::vector<std::pair<std::string, std::string>> kv = {{"ev", cr::json_quote("error")},
                                                               {"op", cr::json_quote("host")},
                                                               {"ref", std::to_string(ref)},
                                                               {"target", cr::json_quote(str(j, "target"))}};
        if (from_layers)
            kv.push_back({"into", cr::json_quote(str(j, "into"))});
        kv.push_back({"reason", cr::json_quote(why)});
        send(c, cr::json_object(kv));
    };
    const int into = from_layers ? slots_->index(str(j, "into")) : -1;
    if (from_layers && j.count("ref")) {
        refuse("ref or into, not both");
        return;
    }
    if (from_layers && (into < 0 || !slots_->targets()[into].follows.empty())) {
        refuse("unknown target " + str(j, "into"));
        return;
    }
    if (!from_layers && !scene) {
        refuse("no such scene");
        return;
    }
    if (!known) {
        refuse("unknown target " + str(j, "target"));
        return;
    }
    const TargetSpec &from = slots_->targets()[hosted];
    static const char *const keys[] = {"x", "y", "w", "h", "src_x", "src_y", "src_w", "src_h", "shown"};
    double v[] = {0, 0, 0, 0, 0, 0, (double)from.width, (double)from.height, 1};
    std::string err;
    for (size_t i = 0; i < 9; i++)
        if (!num(j, keys[i], 0, i == 8 ? 1 : 65535, &v[i], &err)) {
            refuse(err);
            return;
        }
    const size_t src = j.count("src_x") + j.count("src_y") + j.count("src_w") + j.count("src_h");
    if (src && src != 4) {
        refuse("src_x, src_y, src_w, src_h go together (none: all of " + from.name + ")");
        return;
    }
    /* the optional edge drawn on the hosted picture (PROTOCOL.md "host") */
    static const char *const edge_keys[] = {"edge_top", "edge_bottom", "edge_fade", "edge_dim", "edge_blur"};
    static const double edge_max[] = {720, 720, 360, 4096, 32};
    double ev[5] = {0, 0, 0, 0, 0};
    for (size_t i = 0; i < 5; i++)
        if (!num(j, edge_keys[i], 0, edge_max[i], &ev[i], &err)) {
            refuse(err);
            return;
        }
    Host h;
    h.rect = Rect{(int32_t)v[0], (int32_t)v[1], (uint32_t)v[2], (uint32_t)v[3]};
    h.src = Rect{(int32_t)v[4], (int32_t)v[5], (uint32_t)v[6], (uint32_t)v[7]};
    h.shown = v[8] != 0;
    h.edge.top = (uint32_t)ev[0];
    h.edge.bottom = (uint32_t)ev[1];
    h.edge.fade = (uint32_t)ev[2];
    h.edge.dim = (uint32_t)ev[3];
    h.edge.blur = (uint32_t)ev[4];
    if (from_layers ? !comp_->host_layers(c.id, into, hosted, h, &err) : !comp_->host(c.id, scene, hosted, h, &err)) {
        refuse(err);
        return;
    }
    if (from_layers)
        log_info("client %llu (%s): %s", (unsigned long long)c.id, c.app.c_str(),
                 layer_host_text(hosted, c.id).c_str());
    else
        log_info("client %llu (%s): scene %u %s", (unsigned long long)c.id, c.app.c_str(), scene,
                 comp_->scene_text(scene).c_str());
}

void Server::op_unhost(Client &c, uint32_t ref, const cr::Json &j)
{
    const int hosted = slots_->index(str(j, "target"));
    if (hosted < 0)
        return;   /* nothing hosted there: nothing to end */
    if (j.count("into")) {
        comp_->unhost_layers(c.id, hosted);
    } else {
        auto it = c.refs.find(ref);
        if (it != c.refs.end())
            comp_->unhost(c.id, it->second, hosted);
    }
    log_info("client %llu (%s): ends its host of %s", (unsigned long long)c.id, c.app.c_str(),
             str(j, "target").c_str());
}

std::string Server::layer_host_text(int hosted, uint64_t owner) const
{
    auto it = comp_->layer_hosts().find(std::make_pair(hosted, owner));
    if (it == comp_->layer_hosts().end())
        return std::string();
    const Compositor::LayerHost &lh = it->second;
    const Host &h = lh.host;
    char b[320];
    std::snprintf(b, sizeof b, "hosts %s from its layers on %s at %ux%u+%d+%d from %ux%u+%d+%d%s",
                  slots_->targets()[hosted].name.c_str(), slots_->targets()[lh.into].name.c_str(), h.rect.w,
                  h.rect.h, h.rect.x, h.rect.y, h.src.w, h.src.h, h.src.x, h.src.y, h.shown ? "" : ", not shown");
    std::string text = b;
    if (h.edge.on()) {
        std::snprintf(b, sizeof b, ", its edge %u up and %u down (fade %u, dim %u, blur %u)", h.edge.top,
                      h.edge.bottom, h.edge.fade, h.edge.dim, h.edge.blur);
        text += b;
    }
    if (lh.live)
        text += "; live";
    else if (!lh.why.empty())
        text += "; waiting: " + lh.why + (lh.by ? " (" + app_of(lh.by) + ")" : "");
    return text;
}

void Server::op_edit(Client &c, uint32_t ref, const cr::Json &j)
{
    auto it = c.refs.find(ref);
    SceneEdits *e = it == c.refs.end() ? nullptr : comp_->edits(c.id, it->second);
    if (!e) {
        error(c, "edit", ref, "no such scene");
        return;
    }
    for (const EditProblem &p : e->add(str(j, "lines")))
        error(c, "edit", ref, p.reason, p.line);
}

void Server::op_on_layer(Client &c, const std::string &op, uint32_t ref, Layer *l, const cr::Json &j)
{
    std::string err;
    double part_d = 0;
    if (!num(j, "part", 0, 4294967295.0, &part_d, &err)) {
        error(c, op, ref, err);
        return;
    }
    const uint32_t part = (uint32_t)part_d;
    const bool mesh = std::string(l->kind()) == "mesh";
    if (op == "text") {
        if (std::string(l->kind()) != "text") {
            error(c, op, ref, "only a text layer takes text");
            return;
        }
        TextLayer *t = static_cast<TextLayer *>(l);
        TextStyle st = t->style();
        std::vector<uint32_t> cps;
        bool has = false;
        if (!text_fields(j, &st, &cps, &has, &err)) {
            error(c, op, ref, err);
            return;
        }
        t->set_style(st);
        if (has)
            t->set_text(std::move(cps));
        return;
    }
    if (op == "set") {
        if (!apply(l, j, &err))
            error(c, op, ref, err);
    } else if (op == "uniform") {
        op_uniform(c, ref, l, j);
    } else if (op == "link") {
        double value_d = 0;
        const bool given = j.count("value") && num(j, "value", 0, 4294967295.0, &value_d, &err) &&
                           value_d == (double)(uint32_t)value_d;
        auto v = c.assets.find((uint32_t)value_d);
        const std::string name = str(j, "name");
        if (!given)
            error(c, op, ref, "value is a value's ref, or 0 to unlink");
        else if (name.empty() || name.size() > 64)
            error(c, op, ref, "a link needs a uniform name");
        else if (value_d && (v == c.assets.end() || !comp_->value(c.id, v->second)))
            error(c, op, ref, "no such value");
        else if (!comp_->link(c.id, l->id(), part, name, value_d ? v->second : 0, &err))
            error(c, op, ref, err);
    } else if (op == "bind") {
        const std::string sampler = str(j, "sampler");
        double asset_d = 0;
        num(j, "asset", 0, 4294967295.0, &asset_d, &err);
        auto a = c.assets.find((uint32_t)asset_d);
        if (sampler.empty() || sampler.size() > 64)
            error(c, op, ref, "a bind needs a sampler name");
        else if (a == c.assets.end())
            error(c, op, ref, "no such asset");
        else if (!comp_->bind(c.id, l->id(), part, sampler, a->second, &err))
            error(c, op, ref, err);
    } else if (op == "part") {
        /* everything checked before anything is made: a refused part,
         * pivot or parent leaves nothing */
        PartLook look;
        double parent = 0;
        const bool pivot = str(j, "node") == "1";
        if (!mesh)
            err = "parts are for mesh layers";
        else if (part == 0)
            err = "parts are numbered from 1";
        else if (pivot && (!str(j, "vs").empty() || !str(j, "fs").empty()))
            err = "a pivot (node 1) has no shaders";
        else if (num(j, "parent", 1, 4294967295.0, &parent, &err) && !pivot &&
                 (str(j, "vs").empty() || str(j, "fs").empty()))
            err = "a part needs vs and fs";
        else if (err.empty() && (pivot || look_fields(j, false, &look, &err, stencil_ok(l->params))))
            comp_->add_part(c.id, l->id(), part, pivot ? "" : str(j, "vs"), pivot ? "" : str(j, "fs"), look,
                            (uint32_t)parent, &err);
        if (!err.empty())
            error(c, op, ref, err);
    } else if (op == "transform") {
        MeshLayer *m = mesh ? static_cast<MeshLayer *>(l) : nullptr;
        if (!m || !m->has_part(part)) {
            error(c, op, ref, m ? "no such part" : "transforms are for mesh parts");
            return;
        }
        Pose pose = m->pose(part);
        if (!pose_fields(j, &pose, &err)) {
            error(c, op, ref, err);
            return;
        }
        m->set_pose(part, pose);
        comp_->touch(l);
    } else if (op == "animate") {
        double anim_d = 0;
        Animation a;
        if (!animation_fields(j, false, &a, &anim_d, &err)) {
            error(c, op, ref, err);
            return;
        }
        if (a.property == Animated::Uniform && comp_->linked(c.id, l->id(), part, a.uniform)) {
            error(c, op, ref, "the uniform follows a value: animate the value, or unlink it first");
            return;
        }
        a.owner = c.id;
        if (!l->animate((uint32_t)anim_d, part, a, &err))
            error(c, op, ref, err);
        else
            comp_->touch(l);
    } else if (op == "stop") {
        double anim_d = 0;
        num(j, "anim", 0, 4294967295.0, &anim_d, &err);
        if (!anim_d || !l->stop((uint32_t)anim_d))
            error(c, op, ref, "no such animation");
        else
            comp_->touch(l);
    }
}

void Server::op_uniform(Client &c, uint32_t ref, Layer *l, const cr::Json &j)
{
    const std::string op = "uniform";
    const std::string kind = l->kind();
    double part_d = 0;
    std::string err;
    num(j, "part", 0, 4294967295.0, &part_d, &err);
    const uint32_t part = (uint32_t)part_d;
    if (kind != "effect" && kind != "mesh") {
        error(c, op, ref, "uniforms are for effect layers and mesh parts");
        return;
    }
    if (kind == "effect" && part) {
        error(c, op, ref, "effect layers have no parts");
        return;
    }
    MeshLayer *m = kind == "mesh" ? static_cast<MeshLayer *>(l) : nullptr;
    if (m && !m->has_part(part)) {
        error(c, op, ref, "no such part");
        return;
    }
    const std::string name = str(j, "name");
    if (j.count("type")) {
        int type = 0;
        std::vector<float> v;
        if (!choice(j, "type", {"float", "vec2", "vec3", "vec4", "mat4"}, &type, &err)) {
            error(c, op, ref, err);
            return;
        }
        static const UniformType types[] = {UniformType::Float, UniformType::Vec2, UniformType::Vec3,
                                            UniformType::Vec4, UniformType::Mat4};
        const UniformType t = types[type];
        const uint32_t width = uniform_width(t);
        if (name.empty() || name.size() > 64 || !numbers(str(j, "v"), 1024, &v) || v.size() % width) {
            error(c, op, ref, "a uniform needs a name and 1 to 1024 finite numbers in v, whole elements of its type");
            return;
        }
        const uint32_t elements = (uint32_t)(v.size() / width);
        const bool ok = m ? m->set_uniform(part, name, t, v.data(), elements)
                          : static_cast<EffectLayer *>(l)->set_uniform(name, t, v.data(), elements);
        if (!ok)
            error(c, op, ref,
                  "at most " + std::to_string(Uniforms::kMaxNames) + " uniforms and " +
                      std::to_string(Uniforms::kMaxFloats) + " values a quad or part");
        return;
    }
    float vals[4];
    int n = 0;
    const std::string text = str(j, "v");
    const char *p = text.c_str();
    char *end = nullptr;
    bool finite = true;
    while (n < 4) {
        const float f = std::strtof(p, &end);
        if (end == p)
            break;
        finite = finite && std::isfinite(f);
        vals[n++] = f;
        p = end;
    }
    if (n == 0 || !finite || name.empty() || name.size() > 64) {
        error(c, op, ref, "a uniform needs a name and 1 to 4 finite numbers in v");
        return;
    }
    const bool ok = m ? m->set_uniform(part, name, vals, n) : static_cast<EffectLayer *>(l)->set_uniform(name, vals, n);
    if (!ok)
        error(c, op, ref, "at most " + std::to_string(EffectLayer::kMaxUniforms) + " uniforms a layer");
}
void Server::on_frame(Client &c, const char *body, size_t n, int64_t now_ms)
{
    cr::FrameHeader h;
    if (!cr::parse_frame(body, n, &h)) {
        error(c, "frame", 0, "malformed frame");
        return;
    }
    auto it = c.refs.find(h.ref);
    Layer *l = it == c.refs.end() ? nullptr : comp_->layer(c.id, it->second);
    auto ai = c.assets.find(h.ref);
    Asset *asset = ai == c.assets.end() ? nullptr : comp_->asset(c.id, ai->second);
    std::string err;
    if (asset) {
        std::vector<crk::PixelRect> rects;
        for (const cr::FrameRect &r : h.rects)
            rects.push_back(crk::PixelRect{r.x, r.y, r.w, r.h});
        asset->update(rects, h.pixels, h.pixel_bytes, &err);
    } else if (!l) {
        err = "no such layer";
    } else if (std::string(l->kind()) == "video") {
        VideoLayer *v = static_cast<VideoLayer *>(l);
        if (!h.rects.empty() || h.pixel_bytes != v->frame_bytes())
            err = "a video frame is one whole atlas of " + std::to_string(v->frame_bytes()) + " bytes";
        else
            v->offer(h.pixels, now_ms);
    } else if (std::string(l->kind()) == "image") {
        std::vector<crk::PixelRect> rects;
        for (const cr::FrameRect &r : h.rects)
            rects.push_back(crk::PixelRect{r.x, r.y, r.w, r.h});
        static_cast<ImageLayer *>(l)->update(rects, h.pixels, h.pixel_bytes, &err);
    } else {
        err = std::string(l->kind()) + " layers take no frames";
    }
    /* One error line per layer until it changes, so a producer sending bad
     * frames at 30 a second does not flood its own socket; frames for refs
     * it does not have share one line. */
    std::string &last = c.frame_error[l || asset ? h.ref : 0];
    if (!err.empty() && err != last)
        error(c, "frame", h.ref, err);
    last = err;
}

namespace {

void floats_le(const uint8_t *src, size_t n, std::vector<float> *out)
{
    out->resize(n);
    for (size_t i = 0; i < n; i++) {
        const uint8_t *b = src + i * 4;
        const uint32_t u = b[0] | b[1] << 8 | b[2] << 16 | (uint32_t)b[3] << 24;
        std::memcpy(&(*out)[i], &u, 4);
    }
}

}  // namespace

void Server::on_mesh(Client &c, const char *body, size_t n, int64_t now_ms)
{
    cr::MeshHeader h;
    std::string err;
    if (!cr::parse_mesh(body, n, &h, &err)) {
        const unsigned char *p = reinterpret_cast<const unsigned char *>(body);
        error(c, "mesh", n >= 4 ? (uint32_t)(p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24) : 0, err);
        return;
    }
    auto it = c.refs.find(h.ref);
    if (it == c.refs.end()) {
        error(c, "mesh", h.ref, "no such layer");
        return;
    }
    MeshData d;
    d.vertices = h.vertices;
    floats_le(h.position, (size_t)h.vertices * 3, &d.position);
    if (h.normal)
        floats_le(h.normal, (size_t)h.vertices * 3, &d.normal);
    if (h.texcoord)
        floats_le(h.texcoord, (size_t)h.vertices * 2, &d.texcoord);
    if (h.color)
        floats_le(h.color, (size_t)h.vertices * 4, &d.color);
    d.index.resize(h.indices);
    for (uint32_t i = 0; i < h.indices; i++)
        d.index[i] = (uint16_t)(h.index[i * 2] | h.index[i * 2 + 1] << 8);
    if (!comp_->geometry(c.id, it->second, h.part, std::move(d), now_ms, &err))
        error(c, "mesh", h.ref, err);
}

void Server::report(int64_t now_ms)
{
    /* What each hosted target's event says now (PROTOCOL.md "host"), made
     * again only when the compositor's hosts may have changed (hosts_gen_);
     * a client is compared with it only then: nothing hosted, nothing
     * changes, nothing costs. */
    if (!hosts_gen_ || hosts_serial_ != comp_->host_serial()) {
        hosts_serial_ = comp_->host_serial();
        hosts_gen_++;
        hosts_.clear();
        for (const Compositor::Hosted &x : comp_->hosts()) {
            const Host &h = x.host;
            const std::string &name = slots_->targets()[x.target].name;
            hosts_[name] = cr::json_object({{"ev", cr::json_quote("host")},
                                            {"target", cr::json_quote(name)},
                                            {"into", cr::json_quote(slots_->targets()[x.into].name)},
                                            {"shown", h.shown ? "1" : "0"},
                                            {"x", std::to_string(h.rect.x)},
                                            {"y", std::to_string(h.rect.y)},
                                            {"w", std::to_string(h.rect.w)},
                                            {"h", std::to_string(h.rect.h)},
                                            {"src_x", std::to_string(h.src.x)},
                                            {"src_y", std::to_string(h.src.y)},
                                            {"src_w", std::to_string(h.src.w)},
                                            {"src_h", std::to_string(h.src.h)}});
        }
    }
    /* others_fps (PROTOCOL.md): who holds the others' videos, logged as it
     * changes. */
    std::string requests;
    for (const Compositor::FpsRequest &r : comp_->fps_requests())
        requests += (requests.empty() ? "" : ", ") + app_of(r.owner) + " layer " + std::to_string(r.layer) + " " +
                    std::to_string(r.fps);
    if (requests != fps_requests_) {
        if (requests.empty())
            log_info("others_fps: no layer asks; every video at its own rate");
        else
            log_info("others_fps: shown with it: %s; the other clients' videos at most that a second",
                     requests.c_str());
        fps_requests_ = requests;
    }
    for (Client &c : clients_) {
        if (c.closing || c.app.empty())
            continue;
        const Compositor::FpsRequest *by = nullptr;
        const uint32_t cap = comp_->fps_cap(c.id, &by);
        if (cap != c.fps_cap_sent) {
            c.fps_cap_sent = cap;
            send(c, cr::json_object({{"ev", cr::json_quote("fps_cap")},
                                     {"fps", std::to_string(cap)},
                                     {"app", cr::json_quote(by ? app_of(by->owner) : std::string())}}));
        }
        if (c.host_gen != hosts_gen_) {
            c.host_gen = hosts_gen_;
            for (auto it = c.host_sent.begin(); it != c.host_sent.end();) {
                if (hosts_.count(it->first)) {
                    ++it;
                    continue;
                }
                send(c, cr::json_object({{"ev", cr::json_quote("host")},
                                         {"target", cr::json_quote(it->first)},
                                         {"into", cr::json_quote("")}}));
                it = c.host_sent.erase(it);
            }
            for (const auto &kv : hosts_) {
                std::string &sent = c.host_sent[kv.first];
                if (sent != kv.second)
                    send(c, sent = kv.second);
            }
            /* Its hosts from layers: live, or waiting and why (PROTOCOL.md
             * "Hosting from layers"); none before arrange() decided. One
             * that ended is forgotten, so a new one is told from the start. */
            for (auto it = c.hosting_sent.begin(); it != c.hosting_sent.end();)
                if (comp_->layer_hosts().count(std::make_pair(slots_->index(it->first), c.id)))
                    ++it;
                else
                    it = c.hosting_sent.erase(it);
            for (const auto &kv : comp_->layer_hosts()) {
                const Compositor::LayerHost &lh = kv.second;
                if (lh.owner != c.id || (!lh.live && lh.why.empty()))
                    continue;
                const std::string &name = slots_->targets()[kv.first.first].name;
                const std::string ev = cr::json_object({{"ev", cr::json_quote("hosting")},
                                                        {"target", cr::json_quote(name)},
                                                        {"into", cr::json_quote(slots_->targets()[lh.into].name)},
                                                        {"state", cr::json_quote(lh.live ? "live" : "waiting")},
                                                        {"reason", cr::json_quote(lh.why)},
                                                        {"by", cr::json_quote(lh.by ? app_of(lh.by) : "")}});
                std::string &sent = c.hosting_sent[name];
                if (sent != ev)
                    send(c, sent = ev);
            }
        }
        for (size_t t = 0; t < slots_->targets().size(); t++) {
            if (!slots_->targets()[t].follows.empty())
                continue;   /* a hold: no client's target */
            const TargetStatus &s = slots_->status((int)t);
            const std::string line = std::string(target_state_name(s.state)) + "\n" + holder_name(s.holder) + "\n" +
                                     s.reason + "\n" + std::to_string(s.retry_ms) + "\n" +
                                     rendering_name(s.rendering);
            std::string &sent = c.target_sent[slots_->targets()[t].name];
            if (line == sent)
                continue;
            sent = line;
            send(c, cr::json_object({{"ev", cr::json_quote("target")},
                                     {"target", cr::json_quote(slots_->targets()[t].name)},
                                     {"state", cr::json_quote(target_state_name(s.state))},
                                     {"holder", cr::json_quote(holder_name(s.holder))},
                                     {"reason", cr::json_quote(s.reason)},
                                     {"retry_in_ms", std::to_string(s.retry_ms >= 0 ? std::max<int64_t>(0, s.retry_ms - now_ms)
                                                                                   : -1)},
                                     {"rendering", cr::json_quote(rendering_name(s.rendering))},
                                     /* Always 0: kept for clients that read them. */
                                     {"guide_disabled", "0"},
                                     {"disabled", "0"}}));
        }
        const Governor &gov = comp_->governor();
        const std::string budget = std::to_string(gov.cap()) + "\n" + gov.reason();
        if (budget != c.budget_sent) {
            c.budget_sent = budget;
            send(c, cr::json_object({{"ev", cr::json_quote("budget")},
                                     {"cap_kb_per_s", std::to_string(gov.cap() / 1024)},
                                     {"max_kb_per_s", std::to_string(gov.max() / 1024)},
                                     {"floor_kb_per_s", std::to_string(gov.floor() / 1024)},
                                     {"reason", cr::json_quote(gov.reason())}}));
        }
        for (const auto &kv : c.refs) {
            if (SceneEdits *e = comp_->edits(c.id, kv.second))
                for (const EditProblem &p : e->take_problems())
                    error(c, "edit", kv.first, p.reason, p.line);
            std::string reason;
            const LayerState s = comp_->state(kv.second, &reason);
            if (reason == "scene")
                reason = scene_reason(c, kv.second);
            const std::string line = state_line(s, reason);
            std::string &sent = c.layer_sent[kv.first];
            if (line == sent)
                continue;
            sent = line;
            send(c, cr::json_object({{"ev", cr::json_quote("layer")},
                                     {"ref", std::to_string(kv.first)},
                                     {"state", cr::json_quote(layer_state_name(s))},
                                     {"reason", cr::json_quote(reason)}}));
        }
    }
    for (size_t i = clients_.size(); i-- > 0;)
        if (clients_[i].closing)
            drop_client(i);
}

std::string Server::app_of(uint64_t id) const
{
    for (const Client &c : clients_)
        if (c.id == id)
            return c.app;
    return "?";
}

std::string Server::status_text(int64_t now_ms) const
{
    std::string s;
    char line[320];
    const Governor &gov = comp_->governor();
    char configured[64] = "";
    if (gov.ceiling() < gov.max())
        std::snprintf(configured, sizeof configured, ", configured %llu", (unsigned long long)(gov.max() / 1024));
    std::snprintf(line, sizeof line, "upload: cap %llu KB/s (ceiling %llu%s, floor %llu): %s\n",
                  (unsigned long long)(gov.cap() / 1024), (unsigned long long)(gov.ceiling() / 1024), configured,
                  (unsigned long long)(gov.floor() / 1024), gov.reason().c_str());
    s += line;
    if (ceiling_text)
        s += ceiling_text();
    if (!fps_requests_.empty())
        s += "others_fps: " + fps_requests_ + "\n";
    for (size_t t = 0; t < slots_->targets().size(); t++) {
        const TargetSpec &spec = slots_->targets()[t];
        const TargetStatus &st = slots_->status((int)t);
        const std::string rendering = slots_->rendering_text((int)t, now_ms);
        std::snprintf(line, sizeof line, "target %s: slot 0x%llx scene 0x%llx %ux%u: %s%s%s%s%s%s%s\n",
                      spec.name.c_str(), (unsigned long long)spec.slot, (unsigned long long)spec.scene_id, spec.width,
                      spec.height, target_state_name(st.state), st.holder != Holder::None ? " (" : "",
                      st.holder != Holder::None ? holder_name(st.holder) : "", st.holder != Holder::None ? ")" : "",
                      st.reason.empty() ? "" : (" " + st.reason).c_str(), rendering.empty() ? "" : "; ",
                      rendering.c_str());
        s += line;
        if (const CompositeVideo *cv = comp_->composite((int)t)) {
            std::snprintf(line, sizeof line, "  videos composed into one %ux%u at %d,%d: ", cv->video().w,
                          cv->video().h, cv->x(), cv->y());
            s += line + cv->stats() + "\n";
        }
    }
    for (const auto &kv : comp_->layer_hosts())
        s += app_of(kv.second.owner) + " " + layer_host_text(kv.first.first, kv.first.second) + "\n";
    for (const std::string &d : drop_ins_)
        s += "drop-in " + d + "\n";
    s += slots_->renderer_text(now_ms);
    s += slots_->port().status_text(now_ms);
    s += slots_->table_text();
    for (const Client &c : clients_)
        for (const auto &kv : c.assets)
            for (const Asset *a : comp_->assets())
                if (a->id() == kv.second) {
                    const std::string levels = a->params().cube              ? " (cube map)"
                                               : a->params().levels() > 1 ? " (" + std::to_string(a->params().levels()) +
                                                                                " mip levels)"
                                                                          : "";
                    std::snprintf(line, sizeof line, "asset %u %s %ux%u%s of %s on %s: %s\n", a->id(),
                                  tex_format_name(a->params().format), a->params().w, a->params().h, levels.c_str(),
                                  c.app.c_str(), slots_->targets()[a->target()].name.c_str(), a->stats().c_str());
                    s += line;
                }
    for (const Client &c : clients_)
        for (const auto &kv : c.assets)
            if (const Canvas *cv = comp_->canvas(kv.second)) {
                std::snprintf(line, sizeof line, "canvas %u %ux%u%s%s of %s on %s: %s\n", cv->id(), cv->spec().w,
                              cv->spec().h, cv->spec().depth ? " depth" : "", cv->spec().once ? " once" : "",
                              c.app.c_str(), slots_->targets()[cv->target()].name.c_str(),
                              !cv->refused().empty() ? cv->refused().c_str() : cv->attached() ? "made" : "not made yet");
                s += line;
            }
    for (const Client &c : clients_)
        for (const auto &kv : c.refs) {
            std::string reason;
            const LayerState st = comp_->state(kv.second, &reason);
            if (reason == "scene")
                reason = scene_reason(c, kv.second);
            const std::string scene = comp_->scene_text(kv.second);
            if (!scene.empty()) {
                s += "scene " + std::to_string(kv.second) + " of " + c.app + " " + scene + ": " +
                     layer_state_name(st) + (reason.empty() ? "" : " - " + reason) + "\n";
                continue;
            }
            const Layer *l = nullptr;
            for (const Layer *x : comp_->layers())
                if (x->id() == kv.second)
                    l = x;
            if (!l)
                continue;
            std::snprintf(line, sizeof line, "layer %u %s of %s on %s, %s z %d%s%s: %s%s%s\n", l->id(), l->kind(),
                          c.app.c_str(), slots_->targets()[l->target()].name.c_str(), klass_name(l->params.klass),
                          l->params.z, l->params.guide_hold ? "" : ", guide_hold 0", l->params.yield ? "" : ", yield 0",
                          layer_state_name(st),
                          reason.empty() ? "" : " - ", reason.c_str());
            s += line;
            const std::string stats = l->stats();
            if (!stats.empty())
                s += "  " + stats + "\n";
            auto m = c.shm.find(kv.first);
            if (m != c.shm.end())
                s += "  " + std::to_string((unsigned long long)m->second.frames) + " frames through its shared buffer of " +
                     std::to_string(m->second.slots) + " slots\n";
        }
    return s;
}

}  // namespace crs
