/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 Robert Nisipeanu */
/* Host test for slot arbitration (slots.h): a slot is requested once while
 * any layer wants it and released only after none has for linger_ms, so
 * clients coming and going cause no display traffic; content of the stock
 * HMI is yielded to unless a layer contends, which retries on the 2/5/10/20/30
 * s ladder, reset after 30 s shown; content of anything else is always
 * yielded to; a slot the table names as held is not asked for; refusals and
 * no answer retry on the ladder; requests are spaced; the display service
 * going away takes every target down and its return maps the wanted ones
 * again after the settle time; two targets sharing a scene id are never up
 * together. With tables of one row per mapping, as the car reports them:
 * the holder is the row shown; a parked target stays mapped with no
 * timeout until shown; a contending target parked behind the stock HMI's
 * content unmaps it as the HMI, 1.5 s apart four times, then 10 s, then
 * every 30 s, the count starting over after 10 s shown or a release and the
 * spacing never under 1.5 s, brief shows not ending the back-off, never foreign content, never without a
 * contending layer, never in another slot; a released target is idle;
 * nothing is asked for while the table reports the slot disabled (for at
 * most 30 s after that report), a request left unanswered by a lock is
 * taken down when the slot is free again, and a locked slot coming back is
 * asked for at once. Warm scenes: a target's scene is
 * published once and kept across releases, losses and the display service
 * going; a target with the same scene id takes it down only when it needs
 * the id. After a release the next request waits for the display's
 * confirmation and the renderer's unsubscription, at most 1 s; a fetch failing right after the publication is
 * asked again after 250 ms, three times, then on the ladder; a scene the
 * display removed is asked for again 2 s after, and a fetch failing within
 * 300 ms of that request is asked again after 1.5 s, four times, then on
 * the ladder. Rendering: a
 * shown scene its renderer subscribed to is verified; one not subscribed
 * 1.5 s after it was shown, or after the renderer unsubscribed, is released
 * and asked for again at once, then on the ladder, its scene kept; with no
 * subscription seen since start, nothing is verified or done. Holds: asked
 * for only while the map is shown and the box is mapped in the slot, and
 * released within three passes of the map not being shown, or once the box
 * has been gone or unmapped 3 s (a take-over's unmap and the box mapped
 * again behind ours keep it held; the box coming and going keeps the
 * spacing); a take-over unmaps the shown stock content and the stock
 * contents mapped before ours or while ours was asked for, never those
 * mapped after it; the take-overs are counted; the HMI mapping its content
 * again behind ours is logged; rendering verification never releases a
 * hold; HMI content off the take-over list (the seat-belt panel) shown in
 * the slot makes it yield at once, and it is not asked for while that is
 * shown; parked there, it is never taken over or yielded to; the HMI
 * mapping the box again behind ours takes no second take-over; more than 3
 * losses within 60 s, not to a lock, give it up; a slot reported disabled
 * (a lock, or a slot the unit does not use) is not asked for, the hold
 * waiting as "slot locked", until it is enabled; after a door lock the hold
 * is asked for again and takes over again once the slot is free and the
 * map shown, at once again after a second lock; its take-overs' count
 * starts over after 10 s shown, not at a release, so the map coming and
 * going every 2 s keeps them on their steps; the map flapping spaces
 * requests 1 s and take-overs 1.5 s apart. A hold with its slot from the
 * table (guide_slots = auto) takes 0x103 or 0x105, whichever the table
 * reports the box in (each with the other disabled, as on two cars), and
 * none before the box, keeps
 * its slot when the box is unmapped or mapped in any other slot or a
 * disabled one, moves with it (released first, never two slots; each move
 * a loss; a ladder wait carried over), is asked for again after display
 * drops right after its mapping in either slot, and yields to the seat-belt
 * panel there; a
 * listed slot stays where it is. A loss
 * with the slot locked does not climb the ladder, and after a lock a
 * take-over target is asked for once the slot is not locked, with stock
 * content shown there or not. Accepted, not mapped, for any target, with
 * or without take-overs: a map the display accepted with no map status for
 * 3 s, or a parked, shown or lingering scene whose own row the slot table
 * reports unmapped (none mapped) for 3 s, is released and asked for again
 * on the ladder, or at once when the slot comes back from a lock, never
 * while it is locked; a row mapped again within the 3 s, or a parked
 * scene the stock map stays ahead of, is left alone. The panel on its own scene id: shown with
 * the map and the HUD at once, each released and asked for again in its
 * warm scene alone; falling back to the HUD's id when the display refuses
 * the scene as unknown, the map and the HUD untouched; kept on its own id
 * through display drops right after its mapping; never
 * for failed fetches, an unknown client, a removed fetch, a busy slot or a
 * removal; the HMI's speech dialog in 0x203, on the HUD's id, given way to.
 * Giving way: the HUD to a list in 0x322 as shipped, asked for again
 * yield_ms after it goes, a call's pop-up in 0x321 left alone; to one in
 * 0x321 when hud_yield_slots names it; never to route guidance (BMW's, in its own
 * slot or a yield slot, and the turn box); to nothing while a layer has
 * yield false, and asked for again at once when one sets it while waiting.
 * Kept through a lock, with a port that keeps fetched scenes: a shown or
 * parked target (map, panel, HUD, guide hold) lost to a lock, or refused
 * or unmapped with no map status in a locked slot, is kept: nothing
 * released, asked for or flushed while locked; the first report of its
 * slot unlocked re-maps it (no fetch, no resend), at most once a second;
 * the stock map shown first is taken over at once, later take-overs on
 * their steps; a refused re-map falls back to a release and a full request
 * 1 s after the re-map, a dropped fetch to one at once; a parked target
 * that yields is released, not kept; a hold whose slot the lock left alone
 * is released as the map goes; a lock over 3 min, the heartbeat
 * replies stopping, nothing wanting it or the display service going
 * release it; a kept scene id is never taken by another target. Stalled
 * fetches, subscriptions not observable: a fetch accepted and never
 * completed is taken down at 5 s, its scene republished from the second in
 * a row (a no answer after one counting, no answers alone not), the framework reconnected once at the third and again at the
 * sixth, two targets stalling together reconnecting once; the count starts
 * over after a fetch completes, a showing, or while not wanted. The boot
 * hold: nothing asked for before the stock HMI's content is mapped (our own
 * scene ids not counting) or 10 s; at once when it is, at 1 s when the
 * first table has it, and no hold without a slot table. Preload, with a
 * port that keeps a fetch unmapped: the first preload layer publishes the
 * scene and fetches it with no map (loading, then loaded), staged and
 * flushed, with no traffic after; wanted, the loaded scene is mapped with
 * no fetch; its linger over, or parked with nothing wanting it, it is
 * unmapped and loaded again, or released when the port has lost the
 * fetch; the last preload layer gone releases it; a warm scene's resend
 * is charged at the load's fetch; a fetch the display drops, a refused or
 * stalled load and the heartbeat replies stopping load it again on the
 * ladder (no incident; a stall counted), which starts over after 30 s
 * loaded; the display service gone and back loads it after the settle
 * time; a target wanting its scene id has it released first, and no load
 * goes while that target is wanted or holds the id; a lock leaves it
 * loaded, and wanted then it waits until the slot is back; a kept target
 * nothing wants is loaded; a pop-up while loading releases the load,
 * never loaded without a fetch; after an unmap a report of its own row
 * still mapped counts as ours, and one that stays so 3 s releases it and
 * loads it again on the ladder; stalled loads nothing wants never
 * reconnect the framework, a wanted target's third stall in a row does. A
 * target with no preload layer, or a port that cannot keep a fetch, is as
 * without preload, also waiting on the ladder while another target with
 * its scene id is wanted. */
#include <cstdio>
#include <map>
#include <sstream>
#include <string>
#include <vector>

#include <unistd.h>

#include "../src/log.h"
#include "../src/slots.h"

using namespace crs;

static int failures;
static std::vector<std::string> calls;

static void ok(const char *name, bool cond)
{
    std::printf("%-4s %s\n", cond ? "ok" : "FAIL", name);
    if (!cond) failures++;
}

static std::string joined()
{
    std::string s;
    for (auto &c : calls) s += (s.empty() ? "" : "; ") + c;
    calls.clear();
    return s;
}

static bool calls_are(const std::string &want)
{
    const std::string got = joined();
    if (got == want)
        return true;
    std::printf("     got  \"%s\"\n     want \"%s\"\n", got.c_str(), want.c_str());
    return false;
}

struct FakePort : Port {
    bool up = true;
    bool confirm = true;
    bool available() const override { return up; }
    bool confirmed(const TargetSpec &) const override { return confirm; }
    /* By target name: when the display accepted its map (Port::accepted_ms). */
    std::map<std::string, int64_t> accepted;
    int64_t accepted_ms(const TargetSpec &t) const override
    {
        auto a = accepted.find(t.name);
        return a == accepted.end() ? -1 : a->second;
    }
    void request(const TargetSpec &t) override { calls.push_back("request " + t.name); }
    void release(const TargetSpec &t) override { calls.push_back("release " + t.name); }
    /* Kept through a lock (Port::keep): only when keeps; remap sends
     * nothing once the display has dropped the fetch (!fetched). */
    bool keeps = false, fetched = true;
    bool keep(const TargetSpec &t) override
    {
        if (keeps)
            calls.push_back("keep " + t.name);
        return keeps;
    }
    bool remap(const TargetSpec &t, int64_t) override
    {
        calls.push_back("remap " + t.name + (fetched ? "" : " (not fetched)"));
        return fetched;
    }
    void take_over(const TargetSpec &t, uint64_t content) override
    {
        char b[24];
        std::snprintf(b, sizeof b, "0x%llx", (unsigned long long)content);
        calls.push_back("take over " + t.name + " " + b);
    }
    void refresh_slots() override { calls.push_back("slots?"); }
    /* By target name: the display accepted its fetch and never completed
     * it (Port::fetch_accepted). */
    std::map<std::string, bool> fetching;
    bool fetch_accepted(const TargetSpec &t) const override
    {
        auto f = fetching.find(t.name);
        return f != fetching.end() && f->second;
    }
    /* The boot hold applies (Port::slot_table). */
    bool table = false;
    bool slot_table() const override { return table; }
    /* Preload (Port::preloads): a load is a fetch alone; an unmap keeps the
     * fetch, false once the display has dropped it (!fetched). */
    bool preloads_ok = false;
    bool preloads() const override { return preloads_ok; }
    void load(const TargetSpec &t) override { calls.push_back("load " + t.name); }
    bool unmap(const TargetSpec &t) override
    {
        calls.push_back("unmap " + t.name + (fetched ? "" : " (not fetched)"));
        return fetched;
    }
};

struct FakeScenes : Scenes {
    bool fail = false;
    bool publish(const TargetSpec &t, std::string *err) override
    {
        calls.push_back("publish " + t.name);
        if (fail) *err = "refused";
        return !fail;
    }
    void unpublish(const TargetSpec &t) override { calls.push_back("unpublish " + t.name); }
    int resends = 0;
    void resent(const TargetSpec &, int64_t) override { resends++; }
};

static const uint64_t kMapScene = 0x010004f0, kPanelScene = 0x01000400;
static const uint64_t kMapSlot = 0x100, kPanelSlot = 0x203, kHudSlot = 0x323;
static const uint64_t kStockMap = 0x01000101;   /* an HmiMain3D scene */
static const uint64_t kHmiMap = 0x01000300;     /* the HMI's map in Map view (VERIFIED) */

struct Rig {
    FakePort port;
    FakeScenes scenes;
    SlotManager m{&port, &scenes};
    int64_t now = 100000;
    Rig()
    {
        TargetSpec map;
        map.name = "map"; map.slot = kMapSlot; map.scene_id = kMapScene; map.width = 1088; map.height = 480;
        map.linger_ms = 2000;
        map.take_over_stock = true;
        TargetSpec panel;
        panel.name = "panel"; panel.slot = kPanelSlot; panel.scene_id = kPanelScene; panel.width = 1920;
        panel.height = 720; panel.linger_ms = 3000;
        TargetSpec hud;
        hud.name = "hud"; hud.slot = kHudSlot; hud.scene_id = kPanelScene; hud.width = 800; hud.height = 480;
        m.add(map);
        m.add(panel);
        m.add(hud);
    }
    void run(int64_t ms, int64_t step = 10)
    {
        for (int64_t t = 0; t < ms; t += step) {
            now += step;
            m.tick(now);
        }
    }
    /* A report of one row: occupied, its content is shown. */
    void slot(uint64_t id, uint32_t status, uint64_t content)
    {
        SlotInfo s;
        s.slot = id; s.status = status; s.content = content; s.map_status = status == 2 ? 1 : 0;
        m.on_slots({s}, now);
    }
    /* A report of one slot as the car gives it: one row per mapping
     * (content, map status), the slot's status in each. */
    void rows(uint64_t id, uint32_t status, std::vector<std::pair<uint64_t, uint32_t>> mappings)
    {
        std::vector<SlotInfo> t;
        for (const auto &mp : mappings) {
            SlotInfo s;
            s.slot = id; s.status = status; s.content = mp.first; s.map_status = mp.second;
            t.push_back(s);
        }
        m.on_slots(t, now);
    }
    TargetState state(int i) const { return m.status(i).state; }
};

static void refcount_and_linger()
{
    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    ok("a wanted target is published and requested", calls_are("publish map; request map") &&
                                                         r.state(0) == TargetState::Acquiring);
    r.m.on_shown(kMapScene, r.now);
    ok("and shown once the display says so", r.state(0) == TargetState::Shown && r.m.published(0));
    /* A second client, then the first leaving: still wanted (the compositor
     * ORs its layers), so nothing reaches the display. */
    r.m.want(0, true, false);
    r.run(5000);
    ok("layers coming and going while one wants it: no display traffic", calls_are(""));
    r.m.want(0, false, false);
    r.run(1000);
    ok("the last layer gone: lingering, still mapped", r.state(0) == TargetState::Lingering && calls_are(""));
    r.m.want(0, true, false);
    r.m.tick(r.now);
    ok("wanted again within the linger: shown at once, no request",
       r.state(0) == TargetState::Shown && calls_are(""));
    r.m.want(0, false, false);
    r.run(1990);
    ok("not released before linger_ms", r.state(0) == TargetState::Lingering && calls_are(""));
    r.run(20);
    ok("released after linger_ms: released, its scene kept published", calls_are("release map") &&
           r.state(0) == TargetState::Idle && !r.m.requested(0) && r.m.published(0));
}

static void timeout_and_ladder()
{
    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    joined();
    r.run(4990);
    ok("no answer: still acquiring before 5 s", r.state(0) == TargetState::Acquiring);
    r.run(20);
    ok("no answer for 5 s: taken down, waiting 2 s",
       calls_are("release map") && r.state(0) == TargetState::Waiting &&
           r.m.status(0).retry_ms == r.now + 2000 - 10);
    r.run(1980);
    ok("nothing before the 2 s retry", calls_are(""));
    r.run(20);
    ok("requested again after 2 s", calls_are("request map"));
    r.m.on_refused(kMapScene, Refusal::NoSlot, "E_DCSM_SLOTID_UNKNOWN", r.now);
    ok("a configuration refusal retries on the ladder (5 s)",
       calls_are("release map") && r.m.status(0).retry_ms == r.now + 5000 &&
           r.m.status(0).holder == Holder::None);
    const int64_t at = r.now;
    r.run(4000);
    r.m.on_shown(kMapScene, r.now);
    ok("a late answer to a request taken down is ignored", r.state(0) == TargetState::Waiting);
    r.run(1000);
    ok("next request at the 5 s step", calls_are("request map") && r.now - at == 5000);
}

static void stock_yield()
{
    Rig r;
    r.m.want(1, true, false);   /* an overlay: yields */
    r.m.tick(r.now);
    r.m.on_shown(kPanelScene, r.now);
    joined();
    /* The stock HMI maps its speech dialog over ours. */
    r.slot(kPanelSlot, 2, 0x01000400 + 1);
    r.m.on_lost(kPanelScene, "fetch removed", r.now);
    ok("taken by the stock HMI: down, waiting for the slot to be free",
       calls_are("release panel") && r.state(1) == TargetState::Waiting &&
           r.m.status(1).holder == Holder::Stock && r.m.status(1).retry_ms == -1);
    r.run(60000);
    const std::string polled = joined();
    ok("no request while the stock HMI holds it, the table polled every 5 s",
       polled.find("request") == std::string::npos && polled.find("slots?") != std::string::npos &&
           polled.size() <= std::string("slots?; ").size() * 12);
    r.slot(kPanelSlot, 1, 0);
    r.m.tick(r.now);
    ok("requested again once the slot is free", calls_are("request panel"));
}

static void stock_contend()
{
    Rig r;
    r.m.want(0, true, true);   /* the Waze map contends */
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    joined();
    const int64_t steps[] = {2000, 5000, 10000, 20000, 30000, 30000};
    bool ladder = true;
    for (int64_t step : steps) {
        r.slot(kMapSlot, 2, kStockMap);
        r.m.on_lost(kMapScene, "fetch removed", r.now);
        joined();
        const int64_t at = r.now;
        r.run(step - 10);
        ladder = ladder && calls_are("");
        r.run(10);
        ladder = ladder && calls_are("request map") && r.now - at == step;
        r.m.on_shown(kMapScene, r.now);
        r.run(1000);
    }
    ok("contending with the stock map: retries after 2, 5, 10, 20, 30, 30 s", ladder);
    r.run(30000);
    r.slot(kMapSlot, 2, kStockMap);
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    joined();
    ok("30 s shown resets the ladder to 2 s", r.m.status(0).retry_ms == r.now + 2000);
}

static void foreign_always_yields()
{
    Rig r;
    r.slot(kMapSlot, 2, 0x00007777);   /* content of an app outside the service */
    r.m.want(0, true, true);
    r.m.tick(r.now);
    ok("a slot held by a foreign app is not asked for, even contending",
       calls_are("slots?") && r.state(0) == TargetState::Waiting && r.m.status(0).holder == Holder::Foreign);
    r.run(20000);
    ok("still not asked for while it holds it", joined().find("request") == std::string::npos);
    r.slot(kMapSlot, 1, 0);
    r.m.tick(r.now);
    ok("asked for once it is free", calls_are("publish map; request map"));
}

static void idle_precheck()
{
    Rig r;
    r.slot(kPanelSlot, 2, 0x01000400);   /* our panel scene id, but not ours: the speech dialog */
    r.m.want(1, true, false);
    r.m.tick(r.now);
    ok("our scene id in the slot while we publish nothing is the stock HMI's: yield",
       r.state(1) == TargetState::Waiting && r.m.status(1).holder == Holder::Stock &&
           joined().find("request") == std::string::npos);
    r.m.want(1, true, true);
    r.m.tick(r.now);
    ok("a contending layer arriving while yielding retries on the ladder",
       r.m.status(1).retry_ms == r.now + 2000);
    r.m.want(1, false, false);
    r.run(2000);
    ok("nobody wants it when the timer passes: idle", r.state(1) == TargetState::Idle && calls_are(""));
}

static void busy_refusal_unknown_holder()
{
    Rig r;
    r.m.want(1, true, false);
    r.m.tick(r.now);
    joined();
    r.m.on_refused(kPanelScene, Refusal::Busy, "E_DCSM_PRIOTOOLOW", r.now);
    ok("a busy refusal with no table: held by the stock HMI, yield",
       calls_are("release panel") && r.m.status(1).holder == Holder::Stock &&
           r.m.status(1).retry_ms == -1);
    r.run(100);
    ok("the slot table is asked for", calls_are("slots?"));
}

static void availability()
{
    Rig r;
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    joined();
    r.port.up = false;
    r.m.on_availability(false, r.now);
    r.m.tick(r.now);
    ok("display service gone: nothing sent, the scene kept, unavailable",
       calls_are("") && r.state(0) == TargetState::Unavailable && r.m.published(0) && !r.m.requested(0));
    r.run(10000);
    ok("nothing while it is gone", calls_are(""));
    r.port.up = true;
    r.m.on_availability(true, r.now);
    const int64_t at = r.now;
    r.run(990);
    ok("back: nothing during the settle time", calls_are("") && r.state(0) == TargetState::Idle);
    r.run(20);
    ok("requested again after it", calls_are("request map") && r.now - at >= 1000);
    r.m.want(1, false, false);
    ok("an unwanted target stays idle throughout", r.state(1) == TargetState::Idle);
}

static void shared_scene_id()
{
    Rig r;
    r.m.want(1, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kPanelScene, r.now);
    joined();
    r.m.want(2, true, false);   /* the HUD has the panel's scene id */
    r.run(5000);
    ok("a second target with a published scene id waits",
       r.state(2) == TargetState::Waiting && joined().find("hud") == std::string::npos);
    r.m.want(1, false, false);
    r.run(3100);
    const std::string c = joined();
    ok("and is requested once the first is idle",
       c.find("release panel") != std::string::npos &&
           c.find("publish hud; request hud") != std::string::npos);
}

static void request_gap()
{
    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    r.m.on_refused(kMapScene, Refusal::Transient, "E_FETCH_STATUS_FAILED", r.now);
    joined();
    r.m.want(0, false, false);
    r.run(2000);
    r.m.want(0, true, false);
    r.m.tick(r.now);
    ok("after a refusal the ladder is not bypassed by the demand flapping",
       calls_are("request map") && r.now >= 100000 + 2000);
    r.m.on_refused(kMapScene, Refusal::Transient, "E_FETCH_STATUS_FAILED", r.now);
    joined();
    r.m.want(0, false, false);
    r.run(4000);
    r.m.want(0, true, false);
    r.run(500);
    ok("the next step is still 5 s", calls_are(""));
}

static void lost_while_lingering()
{
    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    r.m.want(0, false, false);
    r.m.tick(r.now);
    joined();
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    ok("lost while lingering: down and idle, no retry", calls_are("release map") &&
                                                           r.state(0) == TargetState::Idle);
}

static void scene_failure()
{
    Rig r;
    r.scenes.fail = true;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    ok("a scene that cannot be published is not requested, and retried on the ladder",
       calls_are("publish map") && r.state(0) == TargetState::Waiting && r.m.status(0).retry_ms == r.now + 2000);
}

static void ladder_rechecks_the_table()
{
    Rig r;
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    r.slot(kMapSlot, 2, kStockMap);
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    joined();
    r.m.want(0, true, false);   /* the contending layer goes; a yielding one stays */
    r.run(3000);
    ok("on the ladder, the contending layer gone: the stock map's slot is not asked for",
       joined().find("request") == std::string::npos && r.m.status(0).holder == Holder::Stock &&
           r.m.status(0).retry_ms == -1);
}

static void lost_to_our_own_id()
{
    std::vector<std::string> evidence;
    auto shown_panel = [&](Rig &r) {
        r.m.on_evidence = [&](Evidence e, const std::string &, int64_t) { evidence.push_back(evidence_name(e)); };
        r.m.want(1, true, false);
        r.m.tick(r.now);
        r.m.on_shown(kPanelScene, r.now);
        r.slot(kPanelSlot, 2, kPanelScene);   /* the table names our mapping */
        joined();
    };
    Rig a;
    shown_panel(a);
    a.m.on_lost(kPanelScene, "fetch removed", a.now);
    ok("lost while the table names our id: undecided, the table asked for, no evidence yet",
       a.m.status(1).state == TargetState::Waiting && evidence.empty() &&
           joined() == "release panel; slots?");
    a.slot(kPanelSlot, 2, kPanelScene);   /* after our unfetch it still names that id */
    a.m.tick(a.now);
    ok("the next report still names it: the stock HMI's (the speech dialog), yielded to, no evidence",
       a.m.status(1).holder == Holder::Stock && a.m.status(1).retry_ms == -1 && evidence.empty());

    Rig b;
    shown_panel(b);
    b.m.on_lost(kPanelScene, "fetch removed", b.now);
    b.slot(kPanelSlot, 1, 0);
    b.m.tick(b.now);
    ok("the next report shows it free: the loss was ours, evidence, and a retry after the removal wait",
       evidence.size() == 1 && evidence[0] == std::string("scene removed") && b.m.status(1).retry_ms == b.now + SlotManager::kRemovalWaitMs);

    Rig c;
    evidence.clear();
    shown_panel(c);
    c.m.on_lost(kPanelScene, "fetch removed", c.now);
    c.run(990);
    const bool waited = evidence.empty();
    c.run(20);
    ok("no report within 1 s: the loss was ours", waited && evidence.size() == 1);
    ok("and the wait counts from the loss", c.m.status(1).retry_ms == c.now - 1010 + SlotManager::kRemovalWaitMs);

    Rig d;
    std::vector<std::string> ev2;
    d.m.on_evidence = [&](Evidence e, const std::string &, int64_t) { ev2.push_back(evidence_name(e)); };
    d.m.want(0, true, false);
    d.m.tick(d.now);
    d.m.on_shown(kMapScene, d.now);
    d.slot(kMapSlot, 1, kMapScene);   /* a removal: the slot available, our content still named */
    d.m.on_lost(kMapScene, "fetch removed", d.now);
    ok("removed with the slot shown available: evidence at once, and the removal wait",
       ev2.size() == 1 && d.m.status(0).retry_ms == d.now + SlotManager::kRemovalWaitMs);
}

static void lock_is_not_evidence()
{
    Rig r;
    std::vector<std::string> ev;
    r.m.on_evidence = [&](Evidence e, const std::string &, int64_t) { ev.push_back(evidence_name(e)); };
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    joined();
    r.slot(kMapSlot, 0, kMapScene);   /* a door-open warning locks the slot */
    r.m.on_lost(kMapScene, "unmapped", r.now);
    r.run(1500);
    ok("a scene the display takes with a lock is not upload evidence", ev.empty());
    r.slot(kMapSlot, 1, 0);
    r.run(1100);
    r.m.on_shown(kMapScene, r.now);
    joined();
    r.slot(kMapSlot, 1, 0);           /* removed with the slot free: the link */
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    ok("one removed with the slot free still is", ev.size() == 1 && ev[0] == std::string("scene removed"));

    Rig l;   /* lingering: the last layer stopped wanting it */
    std::vector<std::string> evl;
    l.m.on_evidence = [&](Evidence e, const std::string &, int64_t) { evl.push_back(evidence_name(e)); };
    l.m.want(1, true, false);
    l.m.tick(l.now);
    l.m.on_shown(kPanelScene, l.now);
    l.m.want(1, false, false);
    l.run(100);
    l.slot(kPanelSlot, 0, kPanelScene);
    l.m.on_lost(kPanelScene, "unmapped", l.now);
    ok("a lock while lingering is not evidence either", evl.empty());
}

static void slot_comes_back()
{
    Rig r;
    r.m.want(0, true, true);   /* contending, like the Waze map */
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    joined();
    /* Three locks in a row. */
    for (int k = 0; k < 3; k++) {
        r.slot(kMapSlot, 0, kMapScene);   /* a door-open warning disables the slot */
        r.m.on_lost(kMapScene, "unmapped", r.now);
        r.slot(kMapSlot, 1, 0);
        r.run(1100);
        r.m.on_shown(kMapScene, r.now);
        joined();
    }
    r.slot(kMapSlot, 0, kMapScene);
    r.m.on_lost(kMapScene, "unmapped", r.now);
    const int64_t lost = r.now;
    ok("a fourth lock in a row: the ladder not climbed, 2 s", r.m.status(0).retry_ms == lost + 2000);
    joined();
    r.run(3000);   /* one report, before the loss: the display reports a slot only when it changes */
    ok("while the slot stays disabled, nothing is asked for", joined().find("request") == std::string::npos);
    r.slot(kMapSlot, 1, 0);           /* the door closed: the slot is free again */
    r.run(1100);
    ok("the slot free again after it was away: asked for at once",
       joined().find("request map") != std::string::npos && r.now - lost < 5000);

    Rig v;
    v.m.want(0, true, true);
    v.m.tick(v.now);
    v.m.on_shown(kMapScene, v.now);
    v.slot(kMapSlot, 2, kMapScene);   /* the table names our mapping */
    joined();
    v.m.on_lost(kMapScene, "unmapped", v.now);   /* undecided: the table is asked for */
    v.slot(kMapSlot, 0, kMapScene);   /* its answer: disabled */
    v.run(20);
    v.slot(kMapSlot, 1, 0);
    v.run(1100);
    ok("a loss decided by the next report, the slot disabled then free: asked for at once",
       joined().find("request map") != std::string::npos);

    /* The table as the car reports slot 0x100: our entry and the stock
     * map's, with one slot status. */
    auto table = [](uint32_t status, uint32_t ours_map, uint32_t stock_map) {
        SlotInfo o, h;
        o.slot = h.slot = kMapSlot;
        o.status = h.status = status;
        o.content = kMapScene;
        h.content = 0x01000300;
        o.map_status = ours_map;
        h.map_status = stock_map;
        return std::vector<SlotInfo>{o, h};
    };
    Rig e;
    e.m.want(0, true, true);
    e.m.tick(e.now);
    e.m.on_shown(kMapScene, e.now);
    e.m.on_slots(table(2, 1, 0), e.now);   /* ours mapped, the stock entry listed but not mapped */
    joined();
    e.m.on_lost(kMapScene, "unmapped", e.now);
    e.m.on_slots(table(1, 0, 0), e.now);
    e.run(1500);
    ok("a stock entry listed beside ours but not mapped is not the slot away: the removal wait",
       joined().find("request") == std::string::npos);
    e.run(3600);
    e.m.on_shown(kMapScene, e.now);
    e.m.on_slots(table(2, 0, 1), e.now);   /* the stock map mapped over ours */
    joined();
    e.m.on_lost(kMapScene, "unmapped", e.now);
    e.m.on_slots(table(1, 0, 0), e.now);   /* and gone again */
    e.run(1100);
    ok("the stock map mapped there and gone again: asked for at once",
       joined().find("request map") != std::string::npos);

    /* A lock of 0x100 with everything unmapped, then the slot back straight
     * to occupied with the HMI's map shown (the sequence the car reported for
     * 0x105 after a door lock). */
    Rig s;
    s.m.want(0, true, true);
    s.m.tick(s.now);
    s.m.on_shown(kMapScene, s.now);
    s.run(15000);
    for (int k = 0; k < 2; k++) {
        joined();
        s.rows(kMapSlot, 0, {{kMapScene, 0}, {kHmiMap, 0}});
        s.m.on_lost(kMapScene, "unmapped", s.now);
        s.run(500);
        s.rows(kMapSlot, 2, {{kHmiMap, 1}});
        s.run(10);
        ok(k ? "a second lock 15 s later: asked for at once again"
             : "the slot back 0 -> 2 with the stock map shown: a take-over target asked for at once",
           calls_are("release map; request map"));
        s.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
        s.m.on_parked(kMapScene, s.now);
        s.run(10);
        s.rows(kMapSlot, 2, {{kMapScene, 1}, {kHmiMap, 3}});
        s.m.on_shown(kMapScene, s.now);
        s.run(15000);
    }

    Rig q;
    q.m.want(0, true, true);
    q.m.tick(q.now);
    q.m.on_shown(kMapScene, q.now);
    joined();
    q.slot(kMapSlot, 1, 0);           /* the display drops our scene and reports the slot free */
    q.m.on_lost(kMapScene, "unmapped", q.now);
    q.slot(kMapSlot, 1, 0);
    q.run(1500);
    ok("a slot reported free without having been away waits for the ladder",
       joined().find("request") == std::string::npos && q.m.status(0).retry_ms > q.now);
}

static void multi_row_holder()
{
    Rig a;
    /* The stock map shown, ours still listed (unmapped) after it: the last
     * row is not the holder. */
    a.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 0}});
    a.m.want(0, true, false);
    a.m.tick(a.now);
    ok("rows like the car's: the shown row holds the slot, whatever comes last",
       a.state(0) == TargetState::Waiting && a.m.status(0).holder == Holder::Stock &&
           joined().find("request") == std::string::npos);
    a.rows(kMapSlot, 1, {{kHmiMap, 0}, {kMapScene, 0}});
    a.m.tick(a.now);
    ok("every row listed unmapped: free, asked for", calls_are("publish map; request map"));

    Rig b;
    b.rows(kMapSlot, 2, {{0x00007777, 0}, {kHmiMap, 1}});
    b.m.want(0, true, true);
    b.m.tick(b.now);
    ok("a foreign row listed but not shown does not hold it: the stock map does, and is contended",
       calls_are("publish map; request map"));

    Rig c;
    c.rows(kMapSlot, 2, {{kHmiMap, 3}, {0x00007777, 1}});
    c.m.want(0, true, true);
    c.m.tick(c.now);
    ok("a foreign row shown, the stock map parked: foreign holds it, yielded to even contending",
       c.m.status(0).holder == Holder::Foreign && joined().find("request") == std::string::npos);
}

/* The map requested and parked behind the stock map: (ours, 3), (stock, 1). */
static void park(Rig &r, bool contend, uint64_t holder = kHmiMap)
{
    r.m.want(0, true, contend);
    r.m.tick(r.now);
    r.rows(kMapSlot, 2, {{holder, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
}

static void parked_then_shown()
{
    Rig r;
    park(r, false);
    ok("map status 3: parked behind the stock HMI, the table asked for",
       r.state(0) == TargetState::Parked && r.m.status(0).holder == Holder::Stock &&
           r.m.status(0).reason == "parked behind stock" && r.m.published(0) &&
           calls_are("publish map; request map; slots?"));
    r.run(30000);
    const std::string c = joined();
    ok("parked for 30 s: no timeout, no release, no request, no take-over without a contending layer",
       r.state(0) == TargetState::Parked && c.find("release") == std::string::npos &&
           c.find("request") == std::string::npos && c.find("take over") == std::string::npos);
    r.rows(kMapSlot, 2, {{kHmiMap, 0}, {kMapScene, 1}});
    r.m.on_shown(kMapScene, r.now);
    ok("the stock map unmapped: ours shown (3 -> 1)", r.state(0) == TargetState::Shown && calls_are(""));
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
    ok("shown, then 1 -> 3: parked again, still mapped", r.state(0) == TargetState::Parked &&
                                                            calls_are("slots?") && r.m.published(0));
    r.m.want(0, false, false);
    r.m.tick(r.now);
    ok("parked and nobody wants it: released at once, idle", calls_are("release map") &&
                                                                r.state(0) == TargetState::Idle);

    Rig u;
    u.m.want(0, true, false);
    u.m.tick(u.now);
    joined();
    u.m.on_parked(kMapScene, u.now);
    ok("parked before the table names a holder: parked, holder unknown",
       u.state(0) == TargetState::Parked && u.m.status(0).holder == Holder::None &&
           u.m.status(0).reason == "parked");
    u.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    ok("the table names it: parked behind stock", u.m.status(0).holder == Holder::Stock &&
                                                     u.m.status(0).reason == "parked behind stock");
}

static void take_over()
{
    Rig r;
    park(r, true);
    joined();
    r.m.tick(r.now);
    ok("contending, parked behind the stock map: it is unmapped as the HMI at once",
       calls_are("take over map 0x1000300; slots?"));
    ok("the next take-over wakes the loop", r.m.wake_in_ms(r.now) == 1500);
    /* The stock map stays on top: the take-overs back off. */
    const int64_t gaps[] = {1500, 1500, 1500, 1500, 10000, 30000, 30000};
    bool spaced = true;
    for (int64_t gap : gaps) {
        const int64_t at = r.now;
        r.run(gap - 10);
        spaced = spaced && joined().find("take over") == std::string::npos;
        r.run(10);
        spaced = spaced && joined().find("take over map 0x1000300") != std::string::npos && r.now - at == gap;
    }
    ok("still behind it: again after 1.5 s four times, then 10, 30, 30 s", spaced);
    r.rows(kMapSlot, 2, {{kHmiMap, 3}, {kMapScene, 1}});
    r.m.on_shown(kMapScene, r.now);
    ok("promoted: shown, the HMI's map parked behind ours", r.state(0) == TargetState::Shown);
    r.run(20000);
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
    joined();
    r.m.tick(r.now);
    ok("on top again after 20 s shown: the count started over after 10 s shown, at once",
       joined().find("take over map 0x1000300") != std::string::npos);
    r.run(1490);
    const bool quiet = joined().find("take over") == std::string::npos;
    r.run(10);
    ok("and 1.5 s to the next", quiet && joined().find("take over map 0x1000300") != std::string::npos);

    Rig s;
    park(s, true);
    s.m.tick(s.now);
    s.run(1500);
    const int64_t second = s.now;
    ok("two take-overs 1.5 s apart", joined().find("take over map 0x1000300; slots?; take over") !=
                                         std::string::npos);
    s.m.want(0, false, false);
    s.m.tick(s.now);
    s.run(500);
    park(s, true);   /* the stream back, the stock map shown again because of our release */
    joined();
    s.run(990);
    const bool floor = joined().find("take over") == std::string::npos;
    s.run(20);
    ok("released and asked for again: the count starts over, still 1.5 s after the last take-over",
       floor && joined().find("take over map 0x1000300") != std::string::npos && s.now - second <= 1510);

    Rig h;
    park(h, true);
    h.m.tick(h.now);
    const int64_t first = h.now;
    h.run(100);
    h.rows(kMapSlot, 2, {{kHmiMap, 3}, {kMapScene, 1}});
    h.m.on_shown(kMapScene, h.now);
    h.run(100);
    h.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    h.m.on_parked(kMapScene, h.now);
    joined();
    h.run(1290);
    const bool held = joined().find("take over") == std::string::npos;
    h.run(20);
    ok("shown and parked again at once: the next take-over still 1.5 s after the last",
       held && joined().find("take over map 0x1000300") != std::string::npos && h.now - first <= 1510);

    Rig f;
    park(f, true, 0x00007777);
    f.run(60000);
    ok("parked behind foreign content: never unmapped", joined().find("take over") == std::string::npos &&
                                                           f.state(0) == TargetState::Parked);

    Rig n;
    park(n, false);
    n.run(10000);
    n.m.want(0, true, true);
    n.m.tick(n.now);
    ok("no take-over until a layer contends; then at once",
       joined().find("take over map 0x1000300") != std::string::npos);

    Rig o;
    o.m.want(0, true, true);
    o.m.tick(o.now);
    o.rows(kPanelSlot, 2, {{kHmiMap, 1}});   /* the stock map shown in another slot */
    o.rows(kMapSlot, 2, {{kMapScene, 3}});
    o.m.on_parked(kMapScene, o.now);
    o.run(10000);
    ok("stock content shown only in another slot: never unmapped", joined().find("take over") == std::string::npos);

    Rig p;
    p.m.want(1, true, true);   /* the panel does not take over */
    p.m.tick(p.now);
    p.rows(kPanelSlot, 2, {{0x01000401, 1}, {kPanelScene, 3}});
    p.m.on_parked(kPanelScene, p.now);
    p.run(10000);
    ok("a target without take_over_stock never unmaps", joined().find("take over") == std::string::npos &&
                                                           p.state(1) == TargetState::Parked);
}

/* The map shown, then a lock (a door-open or check-control warning):
 * every mapping in the slot unmapped, the slot disabled. */
static void lock_map(Rig &r)
{
    r.rows(kMapSlot, 0, {{kHmiMap, 3}, {kMapScene, 1}});
    r.m.on_lost(kMapScene, "unmapped", r.now);
}

/* The lock gone: our request goes, the HMI's map (still fetched) is mapped
 * first and ours parks behind it. */
static void lift_and_park(Rig &r)
{
    r.rows(kMapSlot, 1, {{kHmiMap, 0}, {kMapScene, 0}});
    r.run(10);
    r.rows(kMapSlot, 2, {{kHmiMap, 1}});
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
}

/* Car log 2026-11-03 06:52 (A): an 8.2 s lock, then the stock map back on
 * top after four take-overs in a row; the fifth shows ours. */
static void lock_then_take_overs()
{
    Rig r;
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.rows(kMapSlot, 2, {{kMapScene, 1}, {kHmiMap, 3}});
    r.m.on_shown(kMapScene, r.now);
    joined();
    lock_map(r);
    r.run(8200);
    const std::string locked = joined();
    ok("an 8.2 s lock: taken down, nothing asked for while the slot is disabled",
       locked.find("release map") != std::string::npos && locked.find("request") == std::string::npos &&
           r.m.status(0).reason == "slot locked");
    lift_and_park(r);
    ok("the lock gone: asked for at once", joined().find("request map") != std::string::npos);
    r.m.tick(r.now);
    const int64_t parked = r.now;
    int taken = 0;
    while (taken < 5 && r.now - parked < 60000) {
        if (joined().find("take over map 0x1000300") != std::string::npos && ++taken == 5) {
            r.rows(kMapSlot, 2, {{kHmiMap, 3}, {kMapScene, 1}});
            r.m.on_shown(kMapScene, r.now);
        }
        r.run(10);
    }
    ok("the stock map back on top four times, the fifth take-over shows ours within 6.1 s of the park",
       r.state(0) == TargetState::Shown && r.now - parked <= 6100);
    r.run(40000);
    ok("shown: no more take-overs", joined().find("take over") == std::string::npos);
}

/* The display shows ours and parks it again within moments, over and over:
 * the take-overs keep backing off. */
static void brief_shows_back_off()
{
    Rig r;
    park(r, true);
    joined();
    std::vector<int64_t> at;
    for (int64_t t = 0; t < 45000; t += 10) {
        if (joined().find("take over map 0x1000300") != std::string::npos) {
            at.push_back(r.now);
            r.run(200);
            r.rows(kMapSlot, 2, {{kHmiMap, 3}, {kMapScene, 1}});
            r.m.on_shown(kMapScene, r.now);
            r.run(100);
            r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
            r.m.on_parked(kMapScene, r.now);
        }
        r.run(10);
    }
    const int64_t want[] = {1500, 1500, 1500, 1500, 10000, 30000};
    bool ladder = at.size() == 7;
    for (size_t k = 0; ladder && k < 6; k++)
        ladder = at[k + 1] - at[k] == want[k];
    ok("shown 200 ms, then parked again, each time: 1.5 s four times, then 10, then 30 s", ladder);
}

/* Car log 2026-11-03 07:00 (B, C): shown 18 s after a take-over, then
 * another lock: its take-overs start from the first step again, whatever
 * step the last run reached. */
static void take_overs_restart_when_shown()
{
    Rig r;
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
    r.m.tick(r.now);
    r.run(6000);   /* four lost the race, the fifth worked */
    r.rows(kMapSlot, 2, {{kHmiMap, 3}, {kMapScene, 1}});
    r.m.on_shown(kMapScene, r.now);
    r.run(18000);
    joined();
    lock_map(r);
    r.run(2000);
    lift_and_park(r);
    joined();
    r.m.tick(r.now);
    ok("parked behind the stock map after the next lock: a take-over at once",
       joined().find("take over map 0x1000300") != std::string::npos);
    r.run(1490);
    const bool quiet = joined().find("take over") == std::string::npos;
    r.run(10);
    ok("and the next 1.5 s later", quiet && joined().find("take over map 0x1000300") != std::string::npos);
}

/* Car log 2026-11-12 08:04: the map parked behind the stock map after a
 * lock, then a second lock unmaps ours (3 -> 0) with no map status; only
 * the slot table tells. Released 3 s later and asked for again once the
 * slot is free, not left parked while the take-overs unmap the stock map
 * every 30 s. */
static void not_mapped_map_after_lock()
{
    Rig r;
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
    r.m.tick(r.now);
    ok("map: parked behind the stock map, a take-over", joined().find("take over map 0x1000300") != std::string::npos);
    r.rows(kMapSlot, 1, {{kHmiMap, 0}, {kMapScene, 3}});
    r.run(150);
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.run(1500);
    joined();
    r.rows(kMapSlot, 0, {{kHmiMap, 1}, {kMapScene, 3}, {kMapScene, 0}});
    r.run(3500);
    ok("map: a lock listing ours parked and unmapped: still mapped, kept", r.state(0) == TargetState::Parked &&
                                                                           joined().find("release") == std::string::npos);
    r.rows(kMapSlot, 0, {{kHmiMap, 1}, {kMapScene, 0}});
    r.run(2990);
    ok("map: ours unmapped in the locked slot, 2.99 s: kept",
       r.state(0) == TargetState::Parked && joined().find("release") == std::string::npos);
    r.run(10);
    ok("map: 3 s: released, waiting", joined().find("release map") == 0 && r.state(0) == TargetState::Waiting &&
                                          !r.m.requested(0));
    r.rows(kMapSlot, 0, {{kHmiMap, 0}, {kMapScene, 0}});
    r.run(100);
    const std::string locked = joined();
    ok("map: nothing asked for or taken over while the slot is locked",
       locked.find("request") == std::string::npos && locked.find("take over") == std::string::npos);
    r.rows(kMapSlot, 1, {{kHmiMap, 0}});
    r.run(10);
    ok("map: the lock gone: asked for again at once", calls_are("request map") && r.state(0) == TargetState::Acquiring);
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
    r.m.tick(r.now);
    ok("map: parked again: a take-over at once, the count started over",
       joined().find("take over map 0x1000300") != std::string::npos);
    r.run(1490);
    const bool spaced = joined().find("take over") == std::string::npos;
    r.run(10);
    ok("map: and the next 1.5 s later", spaced && joined().find("take over map 0x1000300") != std::string::npos);
    r.rows(kMapSlot, 2, {{kHmiMap, 3}, {kMapScene, 1}});
    r.m.on_shown(kMapScene, r.now);
    ok("map: and shown", r.state(0) == TargetState::Shown);

    Rig k;   /* parked, the stock map staying ahead: the take-overs' business */
    k.m.want(0, true, true);
    k.m.tick(k.now);
    k.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    k.m.on_parked(kMapScene, k.now);
    k.run(20000);
    const std::string ahead = joined();
    ok("map: parked 20 s behind the stock map: taken over on its steps, never released",
       k.state(0) == TargetState::Parked && ahead.find("release") == std::string::npos &&
           ahead.find("take over map 0x1000300") != std::string::npos);
}

/* The panel (no take-overs) and the HUD: a shown scene the table reports
 * unmapped with no map status, and a map the display accepted and never
 * answered, are released and asked for again on the ladder. */
static void not_mapped_panel_and_hud()
{
    Rig r;
    r.m.want(1, true, false);
    r.m.tick(r.now);
    r.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    r.m.on_shown(kPanelScene, r.now);
    joined();
    r.rows(kPanelSlot, 1, {{kPanelScene, 0}});
    r.run(1000);
    r.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    r.run(5000);
    ok("panel: its row unmapped 1 s, then mapped again: kept", r.state(1) == TargetState::Shown && calls_are(""));
    r.rows(kPanelSlot, 1, {{kPanelScene, 0}});
    r.run(2990);
    ok("panel: shown, its row unmapped 2.99 s: kept", r.state(1) == TargetState::Shown && calls_are(""));
    r.run(10);
    ok("panel: 3 s: released, waiting on the ladder", calls_are("release panel") &&
                                                          r.state(1) == TargetState::Waiting &&
                                                          r.m.status(1).retry_ms == r.now + 2000);
    r.run(2000);
    ok("panel: asked for again 2 s later", calls_are("request panel") && r.state(1) == TargetState::Acquiring);

    Rig h;
    h.m.want(2, true, false);
    h.m.tick(h.now);
    joined();
    h.port.accepted["hud"] = h.now;
    h.run(2990);
    ok("hud: its map accepted, no map status for 2.99 s: still acquiring",
       h.state(2) == TargetState::Acquiring && calls_are(""));
    h.run(10);
    ok("hud: 3 s: released, waiting", calls_are("release hud") && h.state(2) == TargetState::Waiting);
    h.port.accepted.clear();
    h.run(2000);
    ok("hud: asked for again on the ladder", calls_are("request hud"));
    h.rows(kHudSlot, 2, {{kPanelScene, 1}});
    h.m.on_shown(kPanelScene, h.now);
    ok("hud: and shown", h.state(2) == TargetState::Shown);
    h.run(10000);
    ok("hud: shown with its row mapped: nothing more", calls_are("") && h.state(2) == TargetState::Shown);
}

/* Car log 2026-11-01 13:49: a 6 s lock with the map's 2 s retry due in it.
 * Nothing is asked for while the slot is reported disabled; the map is
 * asked for on the first tick the slot is reported free. */
static void no_request_while_locked()
{
    Rig r;
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    joined();
    lock_map(r);
    r.run(4000);
    ok("the 2 s retry due while the slot is disabled: not asked for; the table asked for at the loss, polled at the retry",
       calls_are("release map; slots?; slots?") && r.state(0) == TargetState::Waiting);
    r.rows(kMapSlot, 1, {{kHmiMap, 0}});
    r.run(10);
    ok("the slot free again: asked for on the next tick", calls_are("request map"));

    Rig a;   /* a request out when the lock comes */
    a.m.want(0, true, true);
    a.m.tick(a.now);
    joined();
    a.run(100);
    a.rows(kMapSlot, 0, {{kHmiMap, 0}});
    a.run(2000);
    ok("a request out when the slot is locked: still acquiring", a.state(0) == TargetState::Acquiring);
    a.rows(kMapSlot, 1, {{kHmiMap, 0}});
    ok("the slot free again: that request taken down", calls_are("release map"));
    a.run(10);
    ok("and asked for again at once, not after the 5 s timeout", calls_are("request map"));
    a.rows(kMapSlot, 1, {{kHmiMap, 0}});
    a.run(10);
    ok("a request sent with the slot free is left alone", calls_are("") && a.state(0) == TargetState::Acquiring);

    Rig d;   /* a removal, then a lock before its 2 s wait is over */
    d.m.want(0, true, false);
    d.m.tick(d.now);
    d.m.on_shown(kMapScene, d.now);
    d.slot(kMapSlot, 1, 0);
    d.m.on_lost(kMapScene, "fetch removed", d.now);
    d.run(1000);
    d.slot(kMapSlot, 0, 0);
    joined();
    d.run(3000);
    ok("a removal's retry falls due while the slot is disabled: not asked for",
       joined().find("request") == std::string::npos);
    d.slot(kMapSlot, 1, 0);
    d.run(10);
    ok("free again: asked for at once", calls_are("request map"));

    Rig i;   /* wanted while the slot is disabled */
    i.slot(kMapSlot, 0, 0);
    i.m.want(0, true, false);
    i.m.tick(i.now);
    ok("a target wanted while its slot is disabled waits, slot locked",
       joined().find("request") == std::string::npos && i.state(0) == TargetState::Waiting &&
           i.m.status(0).reason == "slot locked");

    Rig k;   /* the display reports the lock, then nothing more */
    k.m.want(0, true, true);
    k.m.tick(k.now);
    k.m.on_shown(kMapScene, k.now);
    lock_map(k);
    const int64_t reported = k.now;
    joined();
    k.run(SlotManager::kLockTrustMs - 10);
    const bool held = joined().find("request") == std::string::npos;
    k.run(20);
    ok("no report since the lock: asked for again once that report is 30 s old",
       held && joined().find("request map") != std::string::npos && k.now - reported <= SlotManager::kLockTrustMs + 10);

    Rig p;   /* a lock reported again by each poll is trusted */
    p.m.want(0, true, true);
    p.m.tick(p.now);
    p.m.on_shown(kMapScene, p.now);
    lock_map(p);
    joined();
    for (int n = 0; n < 12; n++) {
        p.run(5000);
        p.rows(kMapSlot, 0, {{kHmiMap, 0}, {kMapScene, 0}});
    }
    ok("a lock each poll still reports: nothing asked for in 60 s", joined().find("request") == std::string::npos);
}

static void fallback_and_lock()
{
    Rig r;
    park(r, true);
    r.m.tick(r.now);
    r.rows(kMapSlot, 2, {{kHmiMap, 3}, {kMapScene, 1}});
    r.m.on_shown(kMapScene, r.now);
    joined();
    r.m.want(0, false, false);
    r.run(2010);
    ok("the stream ended: released after the linger, idle (the display shows the parked stock map)",
       calls_are("release map") && r.state(0) == TargetState::Idle);
    r.rows(kMapSlot, 2, {{kHmiMap, 1}});
    r.m.want(0, true, false);
    r.m.tick(r.now);
    ok("then a yielding layer: the stock map's slot is not asked for",
       r.state(0) == TargetState::Waiting && r.m.status(0).holder == Holder::Stock);

    Rig l;
    l.m.want(0, true, true);
    l.m.tick(l.now);
    l.rows(kMapSlot, 2, {{kMapScene, 1}, {kHmiMap, 3}});
    l.m.on_shown(kMapScene, l.now);
    joined();
    /* A door opens: the slot locked, every mapping unmapped. */
    l.rows(kMapSlot, 0, {{kMapScene, 0}, {kHmiMap, 0}});
    l.m.on_lost(kMapScene, "unmapped", l.now);
    l.run(500);
    ok("a lock: down, waiting on the ladder", l.state(0) == TargetState::Waiting &&
                                                 joined().find("request") == std::string::npos);
    l.rows(kMapSlot, 1, {{kHmiMap, 0}});
    l.run(600);
    ok("the lock gone: asked for at once", calls_are("request map") && l.m.status(0).retry_ms < 0);

    Rig q;
    park(q, false);
    joined();
    q.rows(kMapSlot, 0, {{kHmiMap, 0}, {kMapScene, 0}});
    q.m.on_lost(kMapScene, "unmapped", q.now);
    ok("a lock while parked: down and waiting", calls_are("release map") &&
                                                   q.state(0) == TargetState::Waiting);
    q.rows(kMapSlot, 1, {{kHmiMap, 0}});
    q.run(1100);
    ok("free again: asked for at once", calls_are("request map"));
}

static void wake()
{
    Rig r;
    ok("no timer when idle", r.m.wake_in_ms(r.now) == -1);
    r.m.want(0, true, false);
    r.m.tick(r.now);
    ok("acquiring wakes at the start timeout", r.m.wake_in_ms(r.now) == 5000);
    r.m.on_shown(kMapScene, r.now);
    r.m.want(0, false, false);
    r.m.tick(r.now);
    ok("lingering wakes at its end", r.m.wake_in_ms(r.now) == 2000);
}

static const std::string kRenderer = "00000000-0000-0000-0000-000000000001";

static void warm_scenes()
{
    Rig r;
    r.m.want(1, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kPanelScene, r.now);
    joined();
    r.m.want(1, false, false);
    r.run(3100);
    ok("released after its linger: the panel's scene stays published",
       calls_are("release panel") && r.m.published(1) && !r.m.requested(1));
    r.m.want(1, true, false);
    r.m.tick(r.now);
    ok("wanted again: requested, nothing published", calls_are("request panel") && r.m.requested(1));
    r.m.on_shown(kPanelScene, r.now);
    r.m.want(1, false, false);
    r.run(3100);
    joined();
    r.m.want(2, true, false);
    r.m.tick(r.now);
    ok("the HUD (the panel's scene id) wanted: the panel's released scene unpublished, then the HUD's published",
       calls_are("unpublish panel; publish hud; request hud") && !r.m.published(1) && r.m.published(2));
    r.m.want(1, true, false);
    r.run(100);
    ok("the panel wanted while the HUD is requested: it waits, the HUD's scene untouched",
       calls_are("") && r.state(1) == TargetState::Waiting && r.m.published(2));
}

/* The panel yields to the stock HMI (waiting for the slot to be free) while
 * the HUD, with the panel's scene id, is shown: the slot coming free must not
 * take the HUD's scene. */
static void shared_scene_in_use()
{
    Rig r;
    r.slot(kPanelSlot, 2, 0x01000101);
    r.m.want(1, true, false);
    r.run(100);
    ok("the panel yields to the stock HMI, waiting for the slot",
       r.state(1) == TargetState::Waiting && r.m.status(1).retry_ms < 0 && calls_are("slots?"));
    r.m.want(2, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kPanelScene, r.now);
    ok("the HUD is shown", calls_are("publish hud; request hud") && r.state(2) == TargetState::Shown);
    r.slot(kPanelSlot, 1, 0);
    r.run(3000);
    ok("the slot free: the panel waits, the HUD's scene and request untouched",
       calls_are("") && r.state(1) == TargetState::Waiting &&
           r.m.status(1).reason == "scene id in use by another target" && r.state(2) == TargetState::Shown &&
           r.m.published(2) && r.m.requested(2) && !r.m.requested(1));
    r.m.want(2, false, false);
    r.run(3100);
    ok("the HUD released: the panel takes the scene id",
       calls_are("release hud; unpublish hud; publish panel; request panel") && r.m.requested(1));
}

/* A fresh retry's early request goes only from its wait. */
static void fresh_retry_cleared()
{
    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    const int64_t asked = r.now;
    r.run(10);
    r.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", r.now);
    r.m.want(0, false, false);
    r.run(300);
    ok("unwanted during the 250 ms retry: idle", r.state(0) == TargetState::Idle);
    joined();
    r.m.want(0, true, false);
    while (r.now - asked < 990)
        r.run(10);
    ok("wanted again: no request within 1 s of the last", calls_are(""));
    r.run(10);
    ok("then requested", calls_are("request map") && r.now - asked == 1000);
}

static void release_confirmation()
{
    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    joined();
    r.port.confirm = false;
    r.m.want(0, false, false);
    while (r.state(0) != TargetState::Idle)
        r.run(10);
    const int64_t released = r.now;
    r.m.want(0, true, false);
    r.run(500);
    ok("wanted again before the display confirms the release: not asked for", calls_are("release map"));
    ok("woken when the wait for the confirmation ends", r.m.wake_in_ms(r.now) == released + 1000 - r.now);
    r.port.confirm = true;
    r.m.tick(r.now);
    ok("confirmed: asked for at once", calls_are("request map"));

    r.m.on_shown(kMapScene, r.now);
    r.port.confirm = false;
    r.m.want(0, false, false);
    while (r.state(0) != TargetState::Idle)
        r.run(10);
    const int64_t again = r.now;
    joined();
    r.m.want(0, true, false);
    r.run(990);
    ok("never confirmed: nothing for 1 s", calls_are(""));
    r.run(10);
    ok("then asked for anyway", calls_are("request map") && r.now - again == 1000);

    /* Subscriptions observable: the renderer's unsubscription is awaited
     * too (it follows the display's confirmation by about 150 ms). */
    r.m.on_subscription(kMapScene, true, false, kRenderer, r.now);
    r.m.on_shown(kMapScene, r.now);
    r.port.confirm = true;
    r.m.want(0, false, false);
    while (r.state(0) != TargetState::Idle)
        r.run(10);
    const int64_t third = r.now;
    joined();
    r.m.want(0, true, false);
    r.run(150);
    ok("confirmed, the renderer still subscribed: not asked for", calls_are(""));
    r.m.on_subscription(kMapScene, false, false, kRenderer, r.now);
    r.m.tick(r.now);
    ok("the renderer unsubscribed: asked for at once", calls_are("request map") && r.now - third == 150);
    r.m.on_shown(kMapScene, r.now);
    r.m.on_subscription(kMapScene, true, false, kRenderer, r.now);
    r.m.want(0, false, false);
    while (r.state(0) != TargetState::Idle)
        r.run(10);
    const int64_t fourth = r.now;
    joined();
    r.m.want(0, true, false);
    r.run(990);
    ok("a renderer that stays subscribed: nothing for 1 s", calls_are(""));
    r.run(10);
    ok("then asked for anyway", calls_are("request map") && r.now - fourth == 1000);
}

static void fresh_fetch_failed()
{
    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    joined();
    bool quick = true;
    for (int k = 0; k < SlotManager::kFreshRetries; k++) {
        r.run(10);
        r.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", r.now);
        const int64_t at = r.now;
        quick = quick && calls_are("release map");
        r.run(240);
        quick = quick && calls_are("");
        r.run(10);
        quick = quick && calls_are("request map") && r.now - at == 250;
    }
    ok("a fetch failing right after the publication: asked again after 250 ms, three times", quick);
    r.run(10);
    r.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", r.now);
    int64_t at = r.now;
    joined();
    r.run(1990);
    ok("the fourth: the ladder", calls_are(""));
    r.run(10);
    ok("its first step, 2 s", calls_are("request map") && r.now - at == 2000);
    r.m.on_shown(kMapScene, r.now);
    r.run(40000);
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    r.run(5000);
    r.run(500);
    joined();
    r.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", r.now);
    at = r.now;
    joined();
    r.run(4990);
    ok("a fetch failing long after the publication: the ladder at once", calls_are(""));
    r.run(10);
    ok("its next step, 5 s", calls_are("request map") && r.now - at == 5000);
}

/* On the car: the KOMBI removed the shown map scene, failed the fetch asked
 * 2 s later within 85-360 ms, and took one asked 3.6 s after the removal
 * (once only 7 s after it): asked at 2 s and again 1.5 s after each failure
 * within a second of the request, the fourth retry comes at about 8.5 s. */
static void removal_retry()
{
    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    r.run(40000);
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    const int64_t removed = r.now;
    joined();
    r.run(1990);
    ok("a scene the display removed: not asked for again within 2 s", calls_are(""));
    r.run(10);
    ok("then asked for", calls_are("request map") && r.now - removed == 2000);
    bool quick = true;
    for (int k = 0; k < SlotManager::kNotReadyRetries; k++) {
        r.run(130);
        r.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", r.now);
        const int64_t at = r.now;
        quick = quick && calls_are("release map") && r.m.status(0).reason == "refused: E_FETCH_STATUS_FAILED";
        r.run(1490);
        quick = quick && calls_are("");
        r.run(10);
        quick = quick && calls_are("request map") && r.now - at == 1500;
    }
    ok("a fetch failing within a second of it: not ready, asked again after 1.5 s, four times", quick);
    ok("no resend charged while the display fails the fetches", r.scenes.resends == 0);
    r.run(130);
    r.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", r.now);
    const int64_t at = r.now;
    joined();
    r.run(4990);
    ok("the fifth: the ladder's next step", calls_are(""));
    r.run(10);
    ok("5 s", calls_are("request map") && r.now - at == 5000);
    r.m.on_shown(kMapScene, r.now);
    ok("charged once when the display takes it", r.scenes.resends == 1);

    Rig s;   /* failing later than a second after the request: a refusal, the ladder */
    s.m.want(0, true, false);
    s.m.tick(s.now);
    s.m.on_shown(kMapScene, s.now);
    s.run(40000);
    s.m.on_lost(kMapScene, "fetch removed", s.now);
    s.run(5000);
    s.run(1100);
    joined();
    s.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", s.now);
    ok("a slow failure after a removal is not 'not ready': the ladder",
       s.m.status(0).retry_ms == s.now + 5000);

    /* On the car such failures came up to 360 ms after the request. */
    Rig q;
    q.m.want(0, true, false);
    q.m.tick(q.now);
    q.m.on_shown(kMapScene, q.now);
    q.run(40000);
    q.m.on_lost(kMapScene, "fetch removed", q.now);
    const int64_t gone = q.now;
    q.run(2000);
    joined();
    q.run(320);
    q.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", q.now);
    const int64_t failed = q.now;
    joined();
    q.run(1490);
    bool spaced = calls_are("");
    q.run(10);
    ok("a failure 320 ms after the request asked 2 s after a removal: not ready, asked again 1.5 s later",
       spaced && calls_are("request map") && q.now - failed == 1500 && q.now - gone == 3820);
    q.run(990);
    q.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", q.now);
    const int64_t again = q.now;
    joined();
    q.run(1490);
    spaced = calls_are("");
    q.run(10);
    ok("one 990 ms after its request too, the requests 1.5 s apart and more",
       spaced && calls_are("request map") && q.now - again == 1500);

    Rig k;   /* the slot reported locked after a not-ready failure: nothing asked for until it is free */
    k.m.want(0, true, false);
    k.m.tick(k.now);
    k.m.on_shown(kMapScene, k.now);
    k.run(40000);
    k.m.on_lost(kMapScene, "fetch removed", k.now);
    k.run(2000);
    joined();
    k.run(320);
    k.m.on_refused(kMapScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", k.now);
    k.slot(kMapSlot, 0, 0);
    joined();
    k.run(5000);
    const bool held = joined().find("request") == std::string::npos;
    k.slot(kMapSlot, 1, 0);
    const int64_t freed = k.now;
    k.run(1100);
    ok("a not-ready retry waits out a lock, then asks once the slot is free",
       held && joined().find("request map") != std::string::npos && k.now - freed <= 1100);

    Rig h;   /* the stock map taking the slot is not a removal by the display */
    h.m.want(0, true, true);
    h.m.tick(h.now);
    h.m.on_shown(kMapScene, h.now);
    h.slot(kMapSlot, 2, kStockMap);
    h.m.on_lost(kMapScene, "fetch removed", h.now);
    ok("a slot the stock HMI takes: the ladder's 2 s", h.m.status(0).retry_ms == h.now + 2000);
}

static void rendering()
{
    Rig n;
    n.m.want(0, true, false);
    n.m.tick(n.now);
    n.m.on_shown(kMapScene, n.now);
    joined();
    n.run(10000);
    ok("no subscription line since start: shown, not observable, nothing done",
       n.m.status(0).rendering == Rendering::Unobservable && n.state(0) == TargetState::Shown && calls_are("") &&
           n.m.renderer_text(n.now).find("not observable") != std::string::npos);

    Rig r;
    r.m.want(0, true, false);
    r.m.tick(r.now);
    r.run(100);
    r.m.on_subscription(kMapScene, true, false, kRenderer, r.now);
    r.run(300);
    ok("subscribed at the fetch, before the map: not counted yet", r.m.status(0).rendering == Rendering::None);
    r.m.on_shown(kMapScene, r.now);
    joined();
    ok("shown: verified at once", r.m.status(0).rendering == Rendering::Verified);
    r.run(10000);
    ok("and kept, nothing done", calls_are("") && r.state(0) == TargetState::Shown &&
                                    r.m.status(0).rendering == Rendering::Verified);
    r.m.on_subscription(kMapScene, false, false, kRenderer, r.now);
    r.m.tick(r.now);
    ok("the renderer unsubscribing while shown: checking", r.m.status(0).rendering == Rendering::Checking &&
                                                               r.m.wake_in_ms(r.now) == SlotManager::kVerifyMs);
    r.run(1000);
    r.m.on_subscription(kMapScene, true, false, kRenderer, r.now);
    r.run(1000);
    ok("subscribed again within 1.5 s: verified, nothing done",
       r.m.status(0).rendering == Rendering::Verified && calls_are(""));
    r.m.on_renderer_gone(kRenderer, r.now);
    r.m.tick(r.now);
    r.run(1490);
    ok("the renderer gone: not subscribed for 1.49 s, still shown",
       calls_are("") && r.state(0) == TargetState::Shown && r.m.status(0).rendering == Rendering::Checking);
    r.run(20);
    ok("at 1.5 s: released and asked for again at once, the scene kept",
       calls_are("release map; request map") && r.m.published(0) && r.state(0) == TargetState::Acquiring);
    r.run(200);
    r.m.on_shown(kMapScene, r.now);
    const int64_t shown = r.now;
    r.run(1510);
    ok("shown again, still not subscribed: released and unpublished (a fresh offer next), on the ladder (2 s) this time",
       calls_are("release map; unpublish map") && r.state(0) == TargetState::Waiting &&
           r.m.status(0).retry_ms == shown + SlotManager::kVerifyMs + 2000);
    r.run(2000);
    ok("asked for again at the step, published again", calls_are("publish map; request map"));
    r.m.on_subscription(kMapScene, true, false, kRenderer, r.now);
    r.run(100);
    r.m.on_shown(kMapScene, r.now);
    ok("subscribed: verified", r.m.status(0).rendering == Rendering::Verified && r.m.published(0));

    /* the renderer never subscribing: every kReconnectAfter-th recovery in a row asks the unit to reconnect */
    Rig k;
    int stuck = 0;
    k.m.on_renderer_stuck = [&stuck](int64_t) { stuck++; };
    k.m.on_subscription(kMapScene, true, false, kRenderer, k.now);    /* subscription lines are readable */
    k.m.on_subscription(kMapScene, false, false, kRenderer, k.now);
    k.m.want(0, true, false);
    k.m.tick(k.now);
    k.run(100);
    k.m.on_subscription(kMapScene, true, false, kRenderer, k.now);   /* the console shows subscriptions: then the renderer goes */
    k.m.on_renderer_gone(kRenderer, k.now);
    for (int n = 0; n < SlotManager::kReconnectAfter; n++) {
        k.m.on_shown(kMapScene, k.now);
        k.run(1510);
        for (int w = 0; w < 600 && k.state(0) != TargetState::Acquiring; w++)
            k.run(100);
        k.run(100);
    }
    ok("not subscribed through kReconnectAfter recoveries: one reconnect asked", stuck == 1);
    calls.clear();

    Rig u;
    u.m.on_subscription(0x01000300, true, false, kRenderer, u.now);   /* no target of ours publishes it */
    u.m.want(0, true, false);
    u.m.tick(u.now);
    u.m.on_shown(kMapScene, u.now);
    u.m.on_subscription(kMapScene, true, true, kRenderer, u.now);     /* a scene the client does not know */
    joined();
    u.run(1600);
    ok("a subscription line of any scene makes subscriptions observable; one the client did not know is not ours",
       calls_are("release map; request map"));
}


/* The RAMSES console the car's DLT daemon turns off and on (console_live_since): a subscription line read once,
 * then the console quiet, a shown map whose subscription is not read is not released (the car, 2026-11-23: every
 * showing released 1.5 s after it for 8 min); live again, a map fetched in the quiet stays; its renderer read
 * unsubscribing, or a fetch made while live and not subscribed, is released as before; the console going quiet
 * during the check stops it; with no console_live_since it is checked as before. */
static void quiet_console()
{
    int64_t since = -1;
    Rig r;
    r.m.console_live_since = [&since](int64_t) { return since; };
    r.m.on_subscription(0x01000300, true, false, kRenderer, r.now);   /* subscription lines are readable */
    r.m.want(0, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    joined();
    r.run(10000);
    ok("quiet console: a shown map whose subscription is not read is kept, not verified",
       calls_are("") && r.state(0) == TargetState::Shown && r.m.status(0).rendering == Rendering::Unobservable);
    since = r.now;
    r.run(5000);
    ok("live again: the map fetched while it was quiet stays", calls_are("") && r.state(0) == TargetState::Shown);
    r.m.on_subscription(kMapScene, false, false, kRenderer, r.now);
    r.run(1480);
    ok("its renderer read unsubscribing while live: checking", calls_are("") &&
                                                                    r.m.status(0).rendering == Rendering::Checking);
    r.run(40);
    ok("not subscribed again 1.5 s on: released and asked for again at once", calls_are("release map; request map"));
    r.run(200);
    r.m.on_shown(kMapScene, r.now);
    r.run(1510);
    ok("fetched while live and not subscribed: released again, on the ladder",
       joined().find("release map") != std::string::npos && r.state(0) == TargetState::Waiting);

    Rig q;
    q.m.console_live_since = [&since](int64_t) { return since; };
    since = q.now - 1000;
    q.m.on_subscription(0x01000300, true, false, kRenderer, q.now);
    q.m.want(0, true, false);
    q.m.tick(q.now);
    q.m.on_shown(kMapScene, q.now);
    joined();
    q.run(1000);
    since = -1;
    q.run(5000);
    ok("the console quiet during the check: not released", calls_are("") && q.state(0) == TargetState::Shown &&
                                                              q.m.status(0).rendering == Rendering::Unobservable);

    Rig n;
    n.m.on_subscription(0x01000300, true, false, kRenderer, n.now);
    n.m.want(0, true, false);
    n.m.tick(n.now);
    n.m.on_shown(kMapScene, n.now);
    joined();
    n.run(1510);
    ok("no console_live_since: checked as before", calls_are("release map; request map"));
}

/* The lines logged since the last call. */
static std::string logged()
{
    static uint64_t seq;
    std::vector<std::string> lines;
    cld::log_lines_since(&seq, &lines);
    std::string s;
    for (const std::string &l : lines)
        s += l + "\n";
    return s;
}

static bool requested_none(const std::string &calls) { return calls.find("request") == std::string::npos; }

static const uint64_t kGuideSlot = 0x105, kGuideScene = 0x010004f1;
/* The HMI's maneuver panel; a second content a take-over may unmap (not the
 * HMI's: for the queue's order); the seat-belt-warning panel, never taken
 * over. */
static const uint64_t kBox = 0x01000310, kBoxAlt = 0x01000315, kBelt = 0x01000314;

/* The rig with a hold of kGuideSlot following the map (target 3); from_table:
 * its slot from the slot table instead (guide_slots = auto). */
struct GuideRig : Rig {
    static const int kGuide = 3;
    explicit GuideRig(bool from_table = false)
    {
        TargetSpec g;
        g.name = "guide"; g.slot = from_table ? 0 : kGuideSlot; g.scene_id = kGuideScene; g.width = g.height = 16;
        g.linger_ms = 0; g.take_over_stock = true; g.follows = "map"; g.take_over_contents = {kBox, kBoxAlt};
        if (from_table)
            g.table_slots = {0x105, 0x103};
        m.add(g);
    }
    uint64_t guide_slot() const { return m.targets()[kGuide].slot; }
    /* The hold asked for and shown, the box parked behind it. */
    void hold()
    {
        pass();
        rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
        m.on_shown(kGuideScene, now);
    }
    /* Passes of the render loop, as Service::after_poll runs them. */
    void pass(int64_t ms = 10)
    {
        for (int64_t t = 0; t < ms; t += 10) {
            now += 10;
            m.follow(now);
            m.tick(now);
        }
    }
    void show_map()
    {
        m.want(0, true, true);
        pass();
        rows(kMapSlot, 2, {{kMapScene, 1}});
        m.on_shown(kMapScene, now);
    }
};

static void guide_follows_the_map()
{
    GuideRig r;
    logged();
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBoxAlt, 3}});   /* a route: the box shown */
    r.pass(3000);
    ok("hold: the map not shown, the guidance slot not asked for", joined().find("guide") == std::string::npos);
    r.show_map();
    joined();
    r.pass();
    ok("the map shown: the hold's empty scene published and asked for", calls_are("publish guide; request guide") &&
                                                                          r.state(GuideRig::kGuide) ==
                                                                              TargetState::Acquiring);
    ok("logged with ours and the slot's rows",
       logged().find("target guide: hold acquiring (was idle); ours 0x10004f1; slot 0x105 status 2: 0x1000310 class "
                     "0 map 1, 0x1000315 class 0 map 3") != std::string::npos);
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBoxAlt, 3}, {kGuideScene, 3}});
    r.m.on_parked(kGuideScene, r.now);
    joined();
    r.pass();
    ok("parked behind the box: the HMI's contents mapped before ours unmapped as the HMI, shown and parked",
       calls_are("take over guide 0x1000310; take over guide 0x1000315; slots?"));
    const std::string over = logged();
    ok("the take-over logged with what it unmapped, ours and the rows",
       over.find("target guide: take-over 1 (1 since start): unmapping the stock HMI's 0x1000310 (class 0, map "
                 "status 1), 0x1000315 (class 0, map status 3) in slot 0x105 as the HMI; the next") !=
               std::string::npos &&
           over.find("ours 0x10004f1; slot status 2:") != std::string::npos);
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}, {kBoxAlt, 3}});
    r.m.on_shown(kGuideScene, r.now);
    const std::string again = logged();
    ok("the HMI maps the box again behind ours: a line for each content, and the hold shown",
       again.find("target guide: the stock HMI's 0x1000310 is mapped again, parked behind ours (map status 3, "
                  "was 1)") != std::string::npos &&
           again.find("the stock HMI's 0x1000315 is mapped again, parked behind ours (map status 3, was 3)") ==
               std::string::npos &&
           again.find("target guide: hold shown (was parked)") != std::string::npos &&
           r.state(GuideRig::kGuide) == TargetState::Shown);
    r.pass(60000);
    ok("held behind the map for a minute: no more take-overs, no traffic", calls_are("") &&
                                                                            r.state(GuideRig::kGuide) ==
                                                                                TargetState::Shown);
    r.m.want(0, false, false);
    r.pass(30);
    ok("the map no longer shown (lingering): the hold released within three passes",
       calls_are("release guide") && r.state(0) == TargetState::Lingering &&
           r.state(GuideRig::kGuide) == TargetState::Idle &&
           logged().find("target guide: hold idle (was lingering)") != std::string::npos);
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBoxAlt, 3}});
    r.m.want(0, true, true);
    r.pass(20);
    ok("the map shown again from its linger: the hold asked for again at once, in the same scene",
       calls_are("request guide") && r.state(0) == TargetState::Shown);

    GuideRig p;
    p.rows(kGuideSlot, 2, {{kBox, 1}});
    p.show_map();
    p.pass();
    p.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}});
    p.m.on_parked(kGuideScene, p.now);
    p.m.want(0, false, false);
    joined();
    p.pass(30);
    ok("parked when the map goes: released", joined().find("release guide") != std::string::npos &&
                                                 p.state(GuideRig::kGuide) == TargetState::Idle);
}

/* The status lists every slot the reports name: what the KOMBI shows beside ours (a dark box under a layout). */
static void table_in_status()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBoxAlt, 3}});
    r.rows(kMapSlot, 2, {{kMapScene, 1}});
    const std::string t = r.m.table_text();
    ok("the table text: a line for each slot reported, its rows in order",
       t.find("slot 0x100 status 2: 0x10004f0 class 0 map 1\n") != std::string::npos &&
           t.find("slot 0x105 status 2: 0x1000310 class 0 map 1, 0x1000315 class 0 map 3\n") != std::string::npos);
}

static void guide_queue_order()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.show_map();
    r.pass();
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}});
    r.m.on_parked(kGuideScene, r.now);
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}, {kBoxAlt, 3}});   /* mapped after ours */
    joined();
    logged();
    r.pass();
    ok("take-over: the shown box unmapped; content mapped after ours left parked behind it",
       calls_are("take over guide 0x1000310; slots?") &&
           logged().find("unmapping the stock HMI's 0x1000310 (class 0, map status 1) in slot 0x105 as the HMI; "
                         "left parked, mapped after ours: 0x1000315 (class 0, map status 3)") != std::string::npos);
    /* One report for the unmap and the HMI's map again: 1 -> 3, never 0. */
    r.rows(kGuideSlot, 2, {{kBoxAlt, 1}, {kGuideScene, 3}, {kBox, 3}});
    r.pass(3000);
    ok("a stock content shown in its place: unmapped at the next take-over, the re-mapped box left behind ours",
       joined().find("take over guide 0x1000315") != std::string::npos &&
           logged().find("take-over 2 (2 since start): unmapping the stock HMI's 0x1000315 (class 0, map status 1) "
                         "in slot 0x105 as the HMI; left parked, mapped after ours: 0x1000310") != std::string::npos);

    GuideRig a;
    a.rows(kGuideSlot, 2, {{kBox, 1}});
    a.show_map();
    a.pass();
    a.rows(kGuideSlot, 2, {{kBox, 1}, {kBoxAlt, 3}});   /* mapped while ours is asked for */
    a.rows(kGuideSlot, 2, {{kBox, 1}, {kBoxAlt, 3}, {kGuideScene, 3}});
    a.m.on_parked(kGuideScene, a.now);
    joined();
    a.pass();
    ok("content mapped while ours was asked for can be ahead of it: unmapped too",
       calls_are("take over guide 0x1000310; take over guide 0x1000315; slots?"));
}

static void guide_never_verified_out()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.show_map();
    r.m.on_subscription(kMapScene, true, false, "renderer-1", r.now);   /* subscriptions observable */
    r.pass();
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    joined();
    r.pass(60000);
    ok("subscriptions observable, the KOMBI never subscribing to the hold's empty scene: kept, never released",
       calls_are("") && r.state(GuideRig::kGuide) == TargetState::Shown &&
           r.m.status(GuideRig::kGuide).rendering == Rendering::Checking && r.state(0) == TargetState::Shown);
}

/* Slot 0x105 as the car reported it with a route (2026-11-03): the box
 * shown, the seat-belt variant 0x01000314 parked behind it at all times. */
static void guide_live_route()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    r.show_map();
    joined();
    r.pass();
    ok("the box shown, the seat-belt panel parked: the hold asked for", calls_are("publish guide; request guide"));
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}, {kGuideScene, 3}});
    r.m.on_parked(kGuideScene, r.now);
    joined();
    logged();
    r.pass();
    ok("parked behind both: the box taken over, the seat-belt panel left alone",
       calls_are("take over guide 0x1000310; slots?") &&
           logged().find("unmapping the stock HMI's 0x1000310 (class 0, map status 1) in slot 0x105 as the HMI; the "
                         "next") != std::string::npos);
    /* The KOMBI shows ours, not the parked seat-belt panel; the HMI maps the
     * box again behind ours about 100 ms later, before our map status. */
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}});
    r.pass(100);
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    r.pass(5000);
    ok("ours shown, the box mapped again behind it: no second take-over", joined().find("take over") ==
                                                                               std::string::npos);
    r.m.on_shown(kGuideScene, r.now);
    r.pass(60000);
    ok("held a minute with both parked behind it: no traffic, no yield",
       calls_are("") && r.state(GuideRig::kGuide) == TargetState::Shown &&
           logged().find("yields") == std::string::npos);
    r.m.want(0, false, false);
    r.pass(30);
    ok("the map hidden: released", calls_are("release guide") && r.state(GuideRig::kGuide) == TargetState::Idle);
}

static void guide_yields()
{
    /* The take-over as on the car, but the KOMBI promotes the seat-belt
     * panel instead of ours. */
    GuideRig k;
    k.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    k.show_map();
    k.pass();
    k.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}, {kGuideScene, 3}});
    k.m.on_parked(kGuideScene, k.now);
    k.pass();
    joined();
    logged();
    k.rows(kGuideSlot, 2, {{kBelt, 1}, {kGuideScene, 3}});
    k.rows(kGuideSlot, 2, {{kBelt, 1}, {kGuideScene, 3}, {kBox, 3}});
    k.pass();
    ok("the seat-belt panel promoted instead of ours: released in the same pass, never taken over",
       calls_are("release guide") && k.state(GuideRig::kGuide) == TargetState::Idle &&
           logged().find("target guide: hold yields to 0x1000314 (class 0, map status 1)") != std::string::npos);
    k.rows(kGuideSlot, 2, {{kBelt, 1}, {kBox, 3}});
    k.pass(10000);
    ok("not asked for while it is shown, the map shown", calls_are("") && k.state(0) == TargetState::Shown);
    k.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    k.pass();
    ok("parked again: asked for again", calls_are("request guide") &&
                                            logged().find("hold no longer yields: 0x1000314 is not shown") !=
                                                std::string::npos);

    /* A seat-belt warning while held: the KOMBI shows the panel over ours. */
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    r.show_map();
    r.pass();
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    joined();
    r.rows(kGuideSlot, 2, {{kBelt, 1}, {kGuideScene, 3}, {kBox, 3}});
    r.m.on_parked(kGuideScene, r.now);
    r.pass();
    ok("the seat-belt panel shown over the hold: released, never taken over",
       calls_are("slots?; release guide") && r.state(GuideRig::kGuide) == TargetState::Idle);
    r.rows(kGuideSlot, 2, {{kBelt, 1}, {kBox, 3}});
    r.pass(10000);
    ok("not asked for while it is shown", calls_are(""));
    r.rows(kGuideSlot, 2, {{kBelt, 0}, {kBox, 1}});
    r.pass();
    ok("unmapped: asked for again", calls_are("request guide"));

    GuideRig b;
    b.rows(kGuideSlot, 2, {{kBelt, 1}});
    b.show_map();
    joined();
    b.pass(5000);
    ok("the seat-belt panel shown when the map is: never asked for, never taken over", calls_are(""));

    GuideRig o;
    o.rows(kGuideSlot, 2, {{kBox, 1}});
    o.show_map();
    o.pass();
    o.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}});
    o.m.on_parked(kGuideScene, o.now);
    o.rows(kGuideSlot, 2, {{0x01000330, 1}, {kGuideScene, 3}});   /* other HMI content in its place */
    joined();
    o.pass(5000);
    ok("parked behind HMI content off the list: yields, no take-over", calls_are("release guide") &&
                                                                        o.state(GuideRig::kGuide) == TargetState::Idle);
}

/* The guide hold parked behind the box, then a lock that unmaps it with no
 * map status: released 3 s later, not a loss, and asked for again once the
 * slot is free. */
static void guide_not_mapped()
{
    GuideRig h;
    h.rows(kGuideSlot, 2, {{kBox, 1}});
    h.show_map();
    h.pass();
    h.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}});
    h.m.on_parked(kGuideScene, h.now);
    h.pass();
    ok("guide: parked behind the box: a take-over", joined().find("take over guide 0x1000310") != std::string::npos);
    h.rows(kGuideSlot, 0, {{kBox, 1}, {kGuideScene, 0}});
    h.pass(3000);
    ok("guide: unmapped in its locked slot 3 s: released, waiting",
       joined().find("release guide") != std::string::npos && h.state(GuideRig::kGuide) == TargetState::Waiting);
    h.pass(5000);
    ok("guide: not asked for while the slot is locked", requested_none(joined()));
    h.rows(kGuideSlot, 2, {{kBox, 1}});
    h.pass();
    ok("guide: the slot free: asked for again at once", calls_are("request guide"));
    h.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
    h.m.on_shown(kGuideScene, h.now);
    h.pass(5000);
    ok("guide: shown, not given up", h.state(GuideRig::kGuide) == TargetState::Shown &&
                                         logged().find("given up") == std::string::npos);
}

/* A door opened: the KOMBI locks 0x105 and unmaps everything in it, then
 * the HMI maps the box and the seat-belt panel again, as seen on the car
 * (2026-11-03) with `panel` there. The map staying shown is this test's. */
static void guide_door_lock()
{
    GuideRig h;
    h.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    h.show_map();
    h.pass();
    h.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    h.m.on_shown(kGuideScene, h.now);
    joined();
    logged();
    const int64_t door = h.now;
    h.rows(kGuideSlot, 0, {{kGuideScene, 0}, {kBelt, 0}, {kBox, 0}});
    h.m.on_lost(kGuideScene, "unmapped", h.now);
    h.pass(9000);
    const std::string locked = joined();
    ok("the lock, the box unmapped with it: the hold down, not asked for while it lasts",
       locked.find("release guide") == 0 && requested_none(locked) &&
           h.state(GuideRig::kGuide) == TargetState::Idle);
    h.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    h.pass();
    ok("the slot free, the box shown again: asked for at once", calls_are("request guide"));
    h.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}, {kGuideScene, 3}});
    h.m.on_parked(kGuideScene, h.now);
    joined();
    h.pass();
    const std::string over = joined();
    ok("parked: one take-over, of the box", over.find("take over guide 0x1000310") == 0 &&
                                                over.rfind("take over") == 0);
    h.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    h.m.on_shown(kGuideScene, h.now);
    h.pass(door + 15000 - h.now);
    ok("held again, not given up", calls_are("") && h.state(GuideRig::kGuide) == TargetState::Shown &&
                                       logged().find("given up") == std::string::npos);
    /* A second lock 15 s after the first, the slot back 1 s later. */
    h.rows(kGuideSlot, 0, {{kGuideScene, 0}, {kBelt, 0}, {kBox, 0}});
    h.m.on_lost(kGuideScene, "unmapped", h.now);
    h.pass(1000);
    joined();
    h.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    h.pass();
    ok("a second lock 15 s later: asked for at once when the slot is free, the ladder not climbed",
       calls_are("request guide"));

    /* The map lost with it: its slot locked too, the map refused "fetch
     * removed" once when the slots come back and shown at the next try. */
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    r.show_map();
    r.pass();
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    joined();
    logged();
    const int64_t lock = r.now;
    r.rows(kMapSlot, 0, {{kMapScene, 0}});
    r.rows(kGuideSlot, 0, {{kGuideScene, 0}, {kBelt, 0}, {kBox, 0}});
    r.m.on_lost(kMapScene, "unmapped", r.now);
    r.m.on_lost(kGuideScene, "unmapped", r.now);
    r.pass();
    ok("the lock: the map and the hold down", calls_are("release map; release guide"));
    int map_requests = 0;
    int64_t map_shown = -1, guide_request = -1;
    std::string all;
    for (int64_t w = 0; w < 30000 && guide_request < 0; w += 10) {
        if (w == 2000) {
            r.slot(kMapSlot, 1, 0);
            r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});   /* the HMI maps its contents again */
        }
        r.pass();
        const std::string c = joined();
        all += c + "; ";
        if (c.find("request map") != std::string::npos && ++map_requests == 1) {
            r.m.on_refused(kMapScene, Refusal::Transient, "fetch removed", r.now);
        } else if (c.find("request map") != std::string::npos) {
            r.rows(kMapSlot, 2, {{kMapScene, 1}});
            r.m.on_shown(kMapScene, r.now);
            map_shown = r.now;
        }
        if (c.find("request guide") != std::string::npos)
            guide_request = r.now;
    }
    ok("the slots free: the map refused once, then shown; the hold asked for only once the map is shown",
       map_requests == 2 && map_shown > lock && guide_request > map_shown &&
           all.find("request guide") == all.rfind("request guide"));
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}, {kGuideScene, 3}});
    r.m.on_parked(kGuideScene, r.now);
    joined();
    r.pass();
    const std::string again = joined();
    ok("one take-over, of the box", again.find("take over guide 0x1000310") == 0 && again.rfind("take over") == 0);
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    r.pass(10000);
    ok("the map lost too: held again once it is shown, not given up",
       calls_are("") && r.state(GuideRig::kGuide) == TargetState::Shown &&
           logged().find("given up") == std::string::npos);
}

/* The take-overs' count starts over once the hold has been shown 10 s. */
static void guide_take_over_settle()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    r.show_map();
    r.pass();
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}, {kGuideScene, 3}});
    r.m.on_parked(kGuideScene, r.now);
    r.pass();
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    r.pass(5000);
    logged();
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}, {kBelt, 3}});   /* the box over ours again */
    r.m.on_parked(kGuideScene, r.now);
    r.pass();
    ok("parked again 5 s after shown: the count goes on",
       logged().find("take-over 2 (2 since start): unmapping the stock HMI's 0x1000310") != std::string::npos);
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}, {kBelt, 3}});
    r.m.on_shown(kGuideScene, r.now);
    r.pass(10000);
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}, {kBelt, 3}});
    r.m.on_parked(kGuideScene, r.now);
    r.pass();
    ok("parked again 10 s after shown: the count started over, the take-over at once",
       logged().find("take-over 1 (3 since start): unmapping the stock HMI's 0x1000310") != std::string::npos);
}

static void guide_gives_up()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.show_map();
    logged();
    int requests = 0;
    for (int k = 0; k < 6; k++) {
        bool asked = false;
        for (int64_t w = 0; w < 30000 && !asked; w += 100) {
            r.pass(100);
            asked = joined().find("request guide") != std::string::npos;
        }
        if (!asked)
            break;
        requests++;
        r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
        r.m.on_shown(kGuideScene, r.now);
        r.rows(kGuideSlot, 2, {{kBox, 1}});   /* the HMI's box over ours again */
        r.m.on_lost(kGuideScene, "fetch removed", r.now);
    }
    r.pass(300000);
    ok("our scene removed 4 times within 60 s: given up, not asked for again",
       requests == 4 && joined().find("request guide") == std::string::npos &&
           logged().find("target guide: hold given up: its scene fetch removed, 4 losses within 60 s") !=
               std::string::npos);

    GuideRig l;
    l.rows(kGuideSlot, 2, {{kBox, 1}});
    l.show_map();
    int asked = 0;
    for (int k = 0; k < 6; k++) {
        l.pass(1100);
        if (joined().find("request guide") == std::string::npos)
            break;
        asked++;
        l.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
        l.m.on_shown(kGuideScene, l.now);
        l.rows(kGuideSlot, 0, {{kGuideScene, 0}, {kBox, 0}});   /* a lock */
        l.m.on_lost(kGuideScene, "unmapped", l.now);
        l.rows(kGuideSlot, 2, {{kBox, 1}});
    }
    ok("losses to a lock do not count", asked == 6);

    /* The seat-belt panel shown over the hold: parked again and yielded to,
     * one loss each time. */
    GuideRig y;
    y.rows(kGuideSlot, 2, {{kBox, 1}});
    y.show_map();
    logged();
    int held = 0;
    for (int k = 0; k < 4; k++) {
        bool asked = false;
        for (int64_t w = 0; w < 30000 && !asked; w += 100) {
            y.pass(100);
            asked = joined().find("request guide") != std::string::npos;
        }
        if (!asked)
            break;
        y.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
        y.m.on_shown(kGuideScene, y.now);
        held++;
        y.rows(kGuideSlot, 2, {{kBelt, 1}, {kGuideScene, 3}, {kBox, 3}});
        y.m.on_parked(kGuideScene, y.now);
        y.pass();
        y.rows(kGuideSlot, 2, {{kBox, 1}});   /* the seat belt fastened */
        if (k == 2)
            ok("three seat-belt events within 60 s: three losses, not given up",
               logged().find("given up") == std::string::npos);
    }
    ok("a fourth: given up", held == 4 && logged().find("hold given up") != std::string::npos);
}

/* Losses until the hold gives up: yields, the seat-belt panel shown over
 * the hold (BMW's own content), or else faults, our scene unmapped with
 * only the box (on the take-over list) in the slot, Dcsm2 staying up (the
 * KOMBI's renderer restarting). Returns the requests. */
static int lose_until_given_up(GuideRig &r, bool yields)
{
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.show_map();
    int requests = 0;
    for (int k = 0; k < 6; k++) {
        bool asked = false;
        for (int64_t w = 0; w < 30000 && !asked; w += 100) {
            r.pass(100);
            asked = joined().find("request guide") != std::string::npos;
        }
        if (!asked)
            break;
        requests++;
        r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
        r.m.on_shown(kGuideScene, r.now);
        if (yields) {
            r.rows(kGuideSlot, 2, {{kBelt, 1}, {kGuideScene, 3}, {kBox, 3}});
            r.m.on_parked(kGuideScene, r.now);
            r.pass();
            r.rows(kGuideSlot, 2, {{kBox, 1}});   /* the seat belt fastened */
        } else {
            r.rows(kGuideSlot, 2, {{kBox, 1}});
            r.m.on_lost(kGuideScene, "unmapped", r.now);
        }
    }
    r.pass(300000);
    return requests;
}

/* Give-ups in two starts, of unmaps or of yields to the seat-belt panel:
 * given up in each, held again at the next start. */
static void guide_gives_up_twice()
{
    for (bool yields : {false, true}) {
        const std::string what = yields ? "yields only" : "unmaps only";
        for (int start = 1; start <= 2; start++) {
            GuideRig r;
            logged();
            const int asked = lose_until_given_up(r, yields);
            ok((what + ", start " + std::to_string(start) + ": held, then given up").c_str(),
               asked == 4 && logged().find("hold given up") != std::string::npos);
        }
    }
}

static void guide_slot_disabled()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.show_map();
    r.pass();
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    joined();
    r.rows(kGuideSlot, 0, {{kGuideScene, 1}, {kBox, 3}});   /* reported disabled before the KOMBI unmaps ours */
    r.pass(20);
    ok("held, then the slot disabled: kept until the KOMBI unmaps it", calls_are("") &&
                                                                        r.state(GuideRig::kGuide) ==
                                                                            TargetState::Shown);
    r.rows(kGuideSlot, 0, {{kGuideScene, 0}, {kBox, 3}});
    r.m.on_lost(kGuideScene, "unmapped", r.now);
    r.pass(10000);
    ok("unmapped, the box still mapped: not asked for while the slot is disabled, waiting as \"slot locked\"",
       requested_none(joined()) && r.state(GuideRig::kGuide) == TargetState::Waiting &&
           r.m.status(GuideRig::kGuide).reason == "slot locked");
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.pass();
    ok("enabled again: asked for at once", calls_are("request guide"));

    GuideRig d;
    d.rows(kGuideSlot, 0, {{kBox, 1}});
    d.show_map();
    joined();
    d.pass(10000);
    ok("the box in a slot reported disabled when the map is shown: never asked for, waiting as \"slot locked\"",
       requested_none(joined()) && d.m.status(GuideRig::kGuide).reason == "slot locked");
    d.pass(40000);
    ok("50 s with no report since: still not asked for (no lock trust for a hold)",
       requested_none(joined()) && d.m.status(GuideRig::kGuide).reason == "slot locked");

    GuideRig u;
    u.show_map();
    joined();
    u.pass(40000);
    ok("a slot the table never names: never asked for, idle",
       requested_none(joined()) && u.state(GuideRig::kGuide) == TargetState::Idle);
    u.rows(kGuideSlot, 2, {{kBox, 1}});
    u.pass();
    ok("the box reported there: asked for at once", joined().find("request guide") != std::string::npos);
}

/* Display drops: one within 10 s of a mapping is logged with the target
 * mapped last, one line, and nothing else follows: the HUD dropped on right
 * after its mapping, again and again, is asked for again each time, as is
 * the map. panel and hud (one scene id) are never asked for at once. */
struct HudRig {
    FakePort port;
    FakeScenes scenes;
    SlotManager m{&port, &scenes};
    int64_t now = 100000;
    int map = 0, panel = 1, hud = 2;
    /* own_panel: the panel on its own scene id, falling back to the HUD's,
     * as cluster-render's main sets it (holds.h fallback_rules). */
    explicit HudRig(bool own_panel = false)
    {
        TargetSpec mp, pn, h;
        mp.name = "map"; mp.slot = kMapSlot; mp.scene_id = kMapScene; mp.width = 1088; mp.height = 480; mp.linger_ms = 0;
        pn.name = "panel"; pn.slot = kPanelSlot; pn.scene_id = kPanelScene; pn.width = 1920; pn.height = 720;
        if (own_panel) {
            pn.scene_id = 0x010004f8;
            pn.linger_ms = 3000;
            pn.fallback_scene_id = kPanelScene;
        }
        h.name = "hud"; h.slot = kHudSlot; h.scene_id = kPanelScene; h.width = 800; h.height = 480;
        if (own_panel)
            h.linger_ms = 3000;
        h.share = true;   /* as cluster-render's main sets the iDrive 7 HUD */
        m.add(mp);
        m.add(pn);
        m.add(h);
    }
    void pass(int64_t ms) { for (int64_t t = 0; t < ms; t += 10) { now += 10; m.tick(now); } }
    void show(int i, uint64_t scene)
    {
        m.want(i, true, true);
        pass(1200);
        m.on_shown(scene, now);
        pass(20);
    }
    void drop()
    {
        port.up = false;
        m.on_availability(false, now);
        port.up = true;
        m.on_availability(true, now);
    }
};

static void hud_drops()
{
    {
        HudRig r;
        r.show(r.map, kMapScene);
        r.show(r.hud, kPanelScene);
        r.pass(3000);
        logged();
        r.drop();
        std::string log = logged();
        ok("a drop 3 s after the HUD's mapping: logged, naming the HUD, once",
           log.find("target hud: the display service went away 3020 ms after its mapping (target shown)") !=
                   std::string::npos &&
               log.find("went away", log.find("went away") + 1) == std::string::npos);
        calls.clear();
        r.pass(1500);
        ok("the HUD and the map asked for again", r.m.requested(r.hud) && r.m.requested(r.map));
        r.m.on_shown(kPanelScene, r.now);
        r.pass(100);
        r.m.on_shown(kMapScene, r.now);   /* the map mapped again after the HUD */
        r.pass(2000);
        logged();
        r.drop();
        ok("a drop after the map's later mapping: logged naming the map",
           logged().find("target map: the display service went away 2000 ms after its mapping") != std::string::npos);
        for (int k = 0; k < 5; k++) {
            r.pass(1500);
            ok(("drop " + std::to_string(k + 1) + " right after the HUD's mapping: the HUD asked for again").c_str(),
               r.m.requested(r.hud) && r.m.status(r.hud).state == TargetState::Acquiring);
            r.m.on_shown(kPanelScene, r.now);
            r.m.on_shown(kMapScene, r.now);
            r.pass(500);
            r.drop();
        }
        r.pass(1500);
        r.m.on_shown(kPanelScene, r.now);
        r.pass(100);
        ok("after them all the HUD shown", r.m.status(r.hud).state == TargetState::Shown);
    }

    HudRig r;
    calls.clear();
    r.m.want(r.panel, true, false);
    r.m.want(r.hud, true, true);
    bool both = false;
    for (int k = 0; k < 600; k++) {
        r.pass(10);
        if (k == 150)
            r.m.on_shown(kPanelScene, r.now);
        const bool p = r.m.requested(r.panel), h = r.m.requested(r.hud);
        both = both || (p && h);
    }
    ok("panel and hud wanted at once: never both asked for, the second waits for the scene id",
       !both && r.m.status(r.hud).reason == "scene id in use by another target");
}

/* The targets as cluster-render's main sets them on iDrive 7: the panel on
 * its own scene id, falling back to the HUD's (holds.h fallback_rules). */
static const uint64_t kOwnPanelScene = 0x010004f8;

struct OwnRig : HudRig {
    OwnRig() : HudRig(true) {}
    uint64_t panel_scene() const { return m.targets()[panel].scene_id; }
};

static void panel_hud_map_together()
{
    OwnRig r;
    calls.clear();
    r.m.want(r.map, true, true);
    r.m.want(r.panel, true, false);
    r.m.want(r.hud, true, true);
    r.m.tick(r.now);
    ok("own ids: map, panel and hud published and asked for in one tick",
       calls_are("publish map; request map; publish panel; request panel; publish hud; request hud"));
    r.m.on_shown(kMapScene, r.now);
    r.m.on_shown(kOwnPanelScene, r.now);
    r.m.on_shown(kPanelScene, r.now);
    r.pass(5000);
    ok("own ids: all three shown at once, each with its own scene id",
       r.m.status(r.map).state == TargetState::Shown && r.m.status(r.panel).state == TargetState::Shown &&
           r.m.status(r.hud).state == TargetState::Shown && r.panel_scene() == kOwnPanelScene && calls_are(""));
    r.m.want(r.panel, false, false);
    r.pass(3100);
    ok("own ids: the panel released after its linger, its scene kept, the HUD and the map untouched",
       calls_are("release panel") && r.m.published(r.panel) && r.m.status(r.hud).state == TargetState::Shown &&
           r.m.status(r.map).state == TargetState::Shown && r.m.published(r.hud));
    r.m.want(r.panel, true, false);
    r.pass(1200);
    ok("own ids: the panel asked for again in its warm scene, nothing unpublished",
       calls_are("request panel") && r.m.requested(r.hud));
    r.m.on_shown(kOwnPanelScene, r.now);
    r.m.want(r.hud, false, false);
    r.pass(3100);
    ok("own ids: the HUD released, the panel kept", calls_are("release hud") && r.m.status(r.panel).state == TargetState::Shown);
    r.m.want(r.hud, true, true);
    r.pass(1200);
    ok("own ids: the HUD asked for again while the panel is shown, in its own warm scene",
       calls_are("request hud") && r.m.requested(r.panel));
    r.m.unpublish_all();
    ok("own ids: every scene unpublished at exit", calls_are("unpublish map; unpublish panel; unpublish hud"));
}

static void panel_falls_back_on_refusal()
{
    {
        OwnRig r;
        r.show(r.hud, kPanelScene);
        calls.clear();
        r.m.want(r.panel, true, false);
        r.m.tick(r.now);
        joined();
        r.pass(10);
        r.m.on_refused(kOwnPanelScene, Refusal::UnknownContent, "E_DCSM_CONTENTID_UNKNOWN", r.now);
        ok("fallback: the scene unknown to the display: released, unpublished, on the HUD's id",
           calls_are("release panel; unpublish panel") && r.panel_scene() == kPanelScene &&
               r.m.status(r.panel).state == TargetState::Waiting);
        r.pass(3000);
        ok("fallback: on the HUD's id, the panel waits while the HUD is asked for, the HUD untouched",
           calls_are("") && r.m.status(r.panel).state == TargetState::Waiting && !r.m.requested(r.panel) &&
               r.m.status(r.hud).state == TargetState::Shown && r.m.published(r.hud));
        r.m.want(r.hud, false, true);
        r.pass(3100);
        ok("fallback: the HUD released, the panel takes the id",
           calls_are("release hud; unpublish hud; publish panel; request panel"));
        r.m.on_refused(kPanelScene, Refusal::UnknownContent, "E_DCSM_CONTENTID_UNKNOWN", r.now);
        ok("fallback: the fallback refused waits on the ladder, no further fallback",
           calls_are("release panel") && r.panel_scene() == kPanelScene &&
               r.m.status(r.panel).state == TargetState::Waiting);
    }
    {
        OwnRig r;
        r.m.want(r.panel, true, false);
        /* Each refusal answers a request: it comes while the panel is
         * acquiring, and the panel then waits. */
        const auto refuse = [&](Refusal kind, const char *why) {
            for (int k = 0; k < 6000 && r.m.status(r.panel).state != TargetState::Acquiring; k++)
                r.pass(10);
            const bool acquiring = r.m.status(r.panel).state == TargetState::Acquiring;
            r.pass(10);
            r.m.on_refused(kOwnPanelScene, kind, why, r.now);
            return acquiring && r.m.status(r.panel).state == TargetState::Waiting;
        };
        bool answered = true;
        for (int k = 0; k <= SlotManager::kFreshRetries; k++)
            answered = refuse(Refusal::FetchFailed, "E_FETCH_STATUS_FAILED") && answered;
        answered = refuse(Refusal::Config, "E_DCSM_HANDLE_UNKNOWN") && answered;
        answered = refuse(Refusal::Transient, "fetch removed") && answered;
        answered = refuse(Refusal::Busy, "E_DCSM_PRIOTOOLOW") && answered;
        ok("fallback: failed fetches, an unknown client, a removed fetch, a busy slot, each answering a request: "
           "no fallback",
           answered && r.panel_scene() == kOwnPanelScene && joined().find("unpublish") == std::string::npos);
        r.pass(20000);
        r.m.on_shown(kOwnPanelScene, r.now);
        r.pass(3000);
        r.m.on_lost(kOwnPanelScene, "fetch removed", r.now);
        ok("fallback: removed right after its mapping: an ordinary loss", r.panel_scene() == kOwnPanelScene);
    }
}

/* Drops right after the panel's mapping on its own id: the panel stays on
 * its own id and is asked for again each time. */
static void panel_keeps_its_id_through_drops()
{
    OwnRig r;
    r.show(r.map, kMapScene);
    r.show(r.panel, kOwnPanelScene);
    for (int k = 0; k < 3; k++) {
        r.pass(2000);
        calls.clear();
        r.drop();
        r.pass(1500);
        ok(("drop " + std::to_string(k + 1) + " 2 s after the panel's mapping: still on its own id, asked for again")
               .c_str(),
           r.panel_scene() == kOwnPanelScene && r.m.requested(r.panel) &&
               joined().find("unpublish panel") == std::string::npos);
        r.m.on_shown(kOwnPanelScene, r.now);
    }
}

/* The HMI's speech dialog (0x01000400) in the panel's slot while the HUD
 * has that id: the stock HMI's, and the panel gives way to it. */
static void panel_yields_to_speech_dialog()
{
    OwnRig r;
    r.show(r.hud, kPanelScene);
    SlotInfo dialog;
    dialog.slot = kPanelSlot; dialog.status = 2; dialog.content = kPanelScene; dialog.map_status = 1;
    r.m.on_slots({dialog}, r.now);
    calls.clear();
    r.m.want(r.panel, true, false);
    r.pass(3000);
    ok("speech dialog: with the HUD on 0x1000400, the dialog in 0x203 is the stock HMI's and the panel waits",
       !r.m.requested(r.panel) && r.m.status(r.panel).state == TargetState::Waiting &&
           r.m.status(r.panel).holder == Holder::Stock && joined().find("request panel") == std::string::npos);
    dialog.status = 1; dialog.content = 0; dialog.map_status = 0;
    r.m.on_slots({dialog}, r.now);
    r.pass(1200);
    ok("speech dialog: gone, the panel asked for", r.m.requested(r.panel) && r.m.status(r.hud).state == TargetState::Shown);
}

/* Display drops around the hold: logged with the target mapped last, once
 * per event, a re-park and re-show by the display being no mapping; the
 * hold asked for again with the map. Its slot refused as unknown: not asked
 * for again until the next start. */
static void guide_drops()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.show_map();
    r.hold();
    r.pass(2000);
    r.rows(kMapSlot, 2, {{kStockMap, 1}});
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    r.pass(5000);
    joined();
    r.pass(100);
    ok("the map lost: the hold released, the map asked for again", r.state(GuideRig::kGuide) == TargetState::Idle &&
                                                                     r.state(0) == TargetState::Acquiring);
    logged();
    r.port.up = false;
    r.m.on_availability(false, r.now);
    ok("the display service gone right after the map's request: logged naming the map",
       logged().find("target map: the display service went away") != std::string::npos);
    r.port.up = true;
    r.m.on_availability(true, r.now);
    r.pass(500);
    r.port.up = false;
    r.m.on_availability(false, r.now);   /* again, before the settle: nothing asked for since */
    r.m.on_availability(false, r.now);   /* and a duplicate notice */
    const std::string again = logged();
    ok("two more drops within 10 s: the hold's older event logged once, the map's not again",
       again.find("target guide: the display service went away") != std::string::npos &&
           again.find("target map:") == std::string::npos &&
           again.find("went away", again.find("went away") + 1) == std::string::npos);
    r.port.up = true;
    r.m.on_availability(true, r.now);
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.pass(1100);
    r.show_map();
    r.pass();
    ok("back: the map shown, the hold asked for again", r.m.requested(GuideRig::kGuide));

    GuideRig s;
    s.rows(kGuideSlot, 2, {{kBox, 1}});
    s.show_map();
    s.hold();
    s.pass(11000);
    s.rows(kGuideSlot, 2, {{kBelt, 1}, {kGuideScene, 3}});
    s.m.on_parked(kGuideScene, s.now);
    s.rows(kGuideSlot, 2, {{kGuideScene, 1}});
    s.m.on_shown(kGuideScene, s.now);   /* parked and shown again by the display */
    s.pass(100);
    logged();
    s.port.up = false;
    s.m.on_availability(false, s.now);
    ok("a re-park and re-show by the display is no mapping: nothing logged 11 s after the hold's",
       logged().find("went away") == std::string::npos);

    GuideRig n;
    n.rows(kGuideSlot, 2, {{kBox, 1}});
    n.show_map();
    n.pass();
    joined();
    n.m.on_refused(kGuideScene, Refusal::NoSlot, "map E_DCSM_SLOTID_UNKNOWN", n.now);
    n.pass(60000);
    ok("the hold's slot refused as unknown: not asked for again, idle; the map kept",
       requested_none(joined()) && n.state(GuideRig::kGuide) == TargetState::Idle && n.state(0) == TargetState::Shown);
    GuideRig next;
    next.rows(kGuideSlot, 2, {{kBox, 1}});
    next.show_map();
    next.pass();
    ok("the next start: the hold asked for again", next.m.requested(GuideRig::kGuide));
}

static void guide_no_flapping()
{
    GuideRig r;
    r.rows(kGuideSlot, 2, {{kBox, 1}});
    r.show_map();
    joined();
    /* The map shown and not, every 150 ms for 20 s; the KOMBI parks the
     * hold behind the box, a take-over shows it with the box parked, a
     * release shows the box. */
    std::vector<int64_t> requests, overs;
    for (int k = 0; k < 2000; k++) {
        if (k % 15 == 0)
            r.m.want(0, (k / 15) % 2 == 1, true);
        r.pass();
        const std::string c = joined();
        if (c.find("request guide") != std::string::npos) {
            requests.push_back(r.now);
            r.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}});
            r.m.on_parked(kGuideScene, r.now);
        }
        if (c.find("take over guide 0x1000310") != std::string::npos) {
            overs.push_back(r.now);
            r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
            r.m.on_shown(kGuideScene, r.now);
        }
        if (c.find("release guide") != std::string::npos)
            r.rows(kGuideSlot, 2, {{kBox, 1}});
    }
    bool spaced = requests.size() >= 2 && overs.size() >= 2;
    for (size_t i = 1; i < requests.size(); i++)
        spaced = spaced && requests[i] - requests[i - 1] >= SlotManager::kMinRequestGapMs;
    for (size_t i = 1; i < overs.size(); i++)
        spaced = spaced && overs[i] - overs[i - 1] >= SlotManager::kTakeOverMs[0];
    ok("the map flapping every 150 ms for 20 s: requests at least 1 s apart, take-overs at least 1.5 s",
       spaced && requests.size() <= 20 && overs.size() <= 14);
    r.m.want(0, false, false);
    r.pass(30);
    ok("and the map left hidden: the hold released, idle", r.state(GuideRig::kGuide) == TargetState::Idle);

    /* The map shown and hidden every 2 s for 60 s: the hold never shown
     * 10 s, its take-overs on their steps. */
    GuideRig f;
    f.rows(kGuideSlot, 2, {{kBox, 1}});
    f.show_map();
    joined();
    std::vector<int64_t> takes;
    for (int k = 0; k < 6000; k++) {
        if (k % 200 == 0)
            f.m.want(0, (k / 200) % 2 == 0, true);
        f.pass();
        const std::string c = joined();
        if (c.find("request guide") != std::string::npos) {
            f.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}});
            f.m.on_parked(kGuideScene, f.now);
        }
        if (c.find("take over guide 0x1000310") != std::string::npos) {
            takes.push_back(f.now);
            f.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
            f.m.on_shown(kGuideScene, f.now);
        }
        if (c.find("release guide") != std::string::npos)
            f.rows(kGuideSlot, 2, {{kBox, 1}});
    }
    bool stepped = takes.size() >= 6;
    for (size_t i = 1; i < takes.size(); i++)
        stepped = stepped && takes[i] - takes[i - 1] >= SlotManager::kTakeOverMs[std::min<size_t>(i - 1, 5)];
    ok("the map flapping every 2 s for 60 s: take-overs 1.5 s apart four times, then 10 s, then 30 s",
       stepped && takes.size() <= 7);
}

/* guide_slots = auto: the hold goes to 0x103 or 0x105, whichever the table
 * reports the box in, with the one scene id; before the box, it has none. */
static const uint64_t kOtherGuideSlot = 0x103;

/* The hold, wanted with the map shown and the box shown in slot, asked for
 * there and shown, then the display service gone 2 s later and back. */
static void map_then_drop(GuideRig &r, uint64_t slot)
{
    r.port.up = true;
    r.m.on_availability(true, r.now);
    r.rows(slot, 2, {{kBox, 1}});
    r.show_map();
    r.pass(2000);
    r.rows(kMapSlot, 2, {{kMapScene, 1}});
    r.m.on_shown(kMapScene, r.now);
    r.pass();
    r.rows(slot, 2, {{kGuideScene, 1}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    r.pass(2000);
    r.port.up = false;
    r.m.on_availability(false, r.now);
}

static void guide_auto_slot()
{
    /* A 2021 X5 G05 (US, 2026-11-04): 0x105 reported disabled and empty,
     * the box shown in 0x103 with the seat-belt panel parked behind it. */
    GuideRig r(true);
    logged();
    r.slot(kGuideSlot, 0, 0);
    r.rows(kOtherGuideSlot, 2, {{kBelt, 3}, {kBox, 1}});
    ok("auto, the box in 0x103 and 0x105 disabled: the hold's slot is 0x103, logged with the rows",
       r.guide_slot() == kOtherGuideSlot &&
           logged().find("target guide: hold moves to slot 0x103, where the slot table reports 0x1000310 (class 0, "
                         "map status 1) (no slot before); ours 0x10004f1; slot 0x103 status 2: 0x1000314 class 0 "
                         "map 3, 0x1000310 class 0 map 1") != std::string::npos);
    r.pass(3000);
    ok("auto: the map not shown, nothing asked for", requested_none(joined()));
    r.show_map();
    joined();
    r.pass();
    ok("the map shown: the hold asked for, in 0x103", calls_are("publish guide; request guide") &&
                                                          r.state(GuideRig::kGuide) == TargetState::Acquiring);
    r.rows(kOtherGuideSlot, 2, {{kBelt, 3}, {kBox, 1}, {kGuideScene, 3}});
    r.m.on_parked(kGuideScene, r.now);
    joined();
    logged();
    r.pass();
    ok("parked in 0x103: the box taken over, the seat-belt panel left alone",
       calls_are("take over guide 0x1000310; slots?") &&
           logged().find("unmapping the stock HMI's 0x1000310 (class 0, map status 1) in slot 0x103 as the HMI; the "
                         "next") != std::string::npos);
    r.rows(kOtherGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    r.slot(kGuideSlot, 0, 0);
    r.pass(60000);
    ok("held in 0x103 a minute, the box parked behind it, 0x105 still disabled: no traffic, not moved",
       calls_are("") && r.state(GuideRig::kGuide) == TargetState::Shown && r.guide_slot() == kOtherGuideSlot);
    r.m.want(0, false, false);
    r.pass(30);
    ok("the map hidden: released", calls_are("release guide") && r.state(GuideRig::kGuide) == TargetState::Idle);
    r.rows(kOtherGuideSlot, 1, {{kBelt, 3}, {kBox, 0}});   /* the route over: the box listed, unmapped */
    r.pass(100);
    ok("the box unmapped: the hold keeps 0x103", r.guide_slot() == kOtherGuideSlot);

    /* The owner's car (2026-11-03): the box in 0x105, 0x103 disabled. */
    GuideRig f(true);
    f.slot(kOtherGuideSlot, 0, 0);
    f.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    f.show_map();
    joined();
    f.pass();
    ok("auto, the box in 0x105 and 0x103 disabled: asked for in 0x105",
       f.guide_slot() == kGuideSlot && calls_are("publish guide; request guide"));
    f.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}, {kGuideScene, 3}});
    f.m.on_parked(kGuideScene, f.now);
    joined();
    f.pass();
    ok("parked: the box taken over, the seat-belt panel left alone, as with guide_slots = 0x105",
       calls_are("take over guide 0x1000310; slots?"));

    /* 0x105 and 0x103 disabled, the box nowhere the hold follows it. */
    GuideRig a(true);
    a.slot(kGuideSlot, 0, 0);
    a.rows(kOtherGuideSlot, 0, {{kBox, 0}});   /* listed, unmapped */
    a.rows(0x104, 2, {{kBox, 1}});
    a.rows(0x203, 2, {{kBoxAlt, 1}});
    a.show_map();
    joined();
    a.pass(40000);
    ok("auto, 0x105 and 0x103 disabled, the box shown only in 0x104 and 0x203 (another target's): no slot, never "
       "asked for, idle",
       requested_none(joined()) && a.guide_slot() == 0 && a.state(GuideRig::kGuide) == TargetState::Idle);
    a.rows(kOtherGuideSlot, 0, {{kBox, 1}});
    a.pass(100);
    ok("the box in 0x103 reported disabled: not followed", a.guide_slot() == 0 && requested_none(joined()));
    a.rows(kOtherGuideSlot, 2, {{kBox, 1}});
    a.pass();
    ok("the box shown in 0x103: asked for there at once", calls_are("publish guide; request guide") &&
                                                              a.guide_slot() == kOtherGuideSlot);
    a.rows(0x104, 2, {{kBox, 1}});
    a.rows(kOtherGuideSlot, 1, {{kBox, 0}});
    a.pass(100);
    ok("then the box in 0x104 only: the hold stays in 0x103", a.guide_slot() == kOtherGuideSlot &&
                                                                 calls_are(""));

    /* The box moving while held. */
    GuideRig v(true);
    v.rows(kGuideSlot, 2, {{kBox, 1}});
    v.show_map();
    v.hold();
    joined();
    logged();
    v.rows(kOtherGuideSlot, 2, {{kBox, 1}});
    ok("held in 0x105, the box shown in 0x103: released from 0x105 in the same report, idle",
       calls_are("release guide") && v.guide_slot() == kOtherGuideSlot &&
           v.state(GuideRig::kGuide) == TargetState::Idle &&
           logged().find("target guide: hold moves to slot 0x103, where the slot table reports 0x1000310 (class 0, "
                         "map status 1) (was slot 0x105, released there)") != std::string::npos);
    v.pass(1000);
    ok("then asked for in 0x103, once, the request gap kept", calls_are("request guide"));
    v.rows(kGuideSlot, 1, {{kBox, 0}});
    v.rows(kOtherGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}});
    v.m.on_parked(kGuideScene, v.now);
    joined();
    v.pass();
    ok("the box left listed unmapped in 0x105: not followed back; in 0x103 taken over",
       v.guide_slot() == kOtherGuideSlot && calls_are("take over guide 0x1000310; slots?"));

    /* Moved while waiting on the ladder: the wait carries over. */
    GuideRig l(true);
    l.rows(kGuideSlot, 2, {{kBox, 1}});
    l.show_map();
    l.pass();
    joined();
    l.m.on_refused(kGuideScene, Refusal::Transient, "no valid reply", l.now);
    l.pass(2000);
    ok("refused in 0x105: asked again after the ladder's 2 s", calls_are("release guide; request guide"));
    l.m.on_refused(kGuideScene, Refusal::Transient, "no valid reply", l.now);
    joined();
    l.pass(100);
    l.rows(kOtherGuideSlot, 2, {{kBox, 1}});
    l.pass(4700);
    ok("refused again, then the box in 0x103: still waiting, not asked for before the ladder's 5 s",
       l.guide_slot() == kOtherGuideSlot && l.state(GuideRig::kGuide) == TargetState::Waiting && calls_are(""));
    l.pass(300);
    ok("then asked for in 0x103 at the end of that wait", calls_are("request guide"));

    /* The box moving to and fro: each move a loss; more than 3 within 60 s
     * give the hold up. */
    GuideRig p(true);
    p.rows(kGuideSlot, 2, {{kBox, 1}});
    p.show_map();
    logged();
    int moves = 0;
    for (int k = 0; k < 6; k++) {
        bool asked = false;
        for (int64_t w = 0; w < 10000 && !asked; w += 100) {
            p.pass(100);
            asked = joined().find("request guide") != std::string::npos;
        }
        if (!asked)
            break;
        const uint64_t at = p.guide_slot(), to = at == kGuideSlot ? kOtherGuideSlot : kGuideSlot;
        p.rows(at, 2, {{kGuideScene, 1}, {kBox, 3}});
        p.m.on_shown(kGuideScene, p.now);
        p.rows(at, 1, {{kGuideScene, 1}});
        p.rows(to, 2, {{kBox, 1}});
        moves++;
    }
    p.pass(120000);
    ok("the box moving between 0x105 and 0x103 while held: given up after 4 moves",
       moves == 4 && requested_none(joined()) &&
           logged().find("target guide: hold given up: its scene moved with the box to another slot, 4 losses "
                         "within 60 s") != std::string::npos);
    GuideRig w(true);
    w.rows(kGuideSlot, 2, {{kBox, 1}});
    w.pass(2000);
    w.slot(kGuideSlot, 0, 0);   /* a move from a locked slot counts too */
    for (int k = 0; k < 4; k++) {
        w.rows(k % 2 ? kGuideSlot : kOtherGuideSlot, 2, {{kBox, 1}});
        w.pass(2000);
    }
    w.show_map();
    joined();
    w.pass(60000);
    ok("the box moving 4 times within 60 s while the map is hidden: given up, never asked for",
       requested_none(joined()));

    /* The display service gone 2 s after the hold's mapping, in 0x105,
     * 0x103, then 0x105 again: logged naming the hold each time, and the
     * hold asked for again after each. */
    {
        GuideRig e(true);
        for (uint64_t slot : {kGuideSlot, kOtherGuideSlot, kGuideSlot}) {
            logged();
            map_then_drop(e, slot);
            char what[96];
            std::snprintf(what, sizeof what, "the display service gone 2 s after the hold's mapping in 0x%llx: logged",
                          (unsigned long long)slot);
            ok(what, logged().find("target guide: the display service went away 2000 ms after its mapping") !=
                         std::string::npos);
        }
        joined();
        e.port.up = true;
        e.m.on_availability(true, e.now);
        e.rows(kGuideSlot, 2, {{kBox, 1}});
        e.pass(1100);
        e.show_map();
        e.pass();
        ok("then the box in 0x105 again: the hold asked for", joined().find("request guide") != std::string::npos);
    }

    /* The seat-belt warning in the followed slot. */
    GuideRig b(true);
    b.rows(kOtherGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    b.show_map();
    b.pass();
    b.rows(kOtherGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    b.m.on_shown(kGuideScene, b.now);
    joined();
    b.rows(kOtherGuideSlot, 2, {{kBelt, 1}, {kGuideScene, 3}, {kBox, 3}});
    b.m.on_parked(kGuideScene, b.now);
    b.pass();
    ok("auto, the seat-belt panel shown over the hold in 0x103: released at once, never taken over, not moved",
       calls_are("slots?; release guide") && b.state(GuideRig::kGuide) == TargetState::Idle &&
           b.guide_slot() == kOtherGuideSlot);
    b.rows(kOtherGuideSlot, 2, {{kBelt, 1}, {kBox, 3}});
    b.pass(10000);
    ok("not asked for while it is shown", calls_are(""));
    b.rows(kOtherGuideSlot, 2, {{kBelt, 0}, {kBox, 1}});
    b.pass();
    ok("the warning over: asked for again in 0x103", calls_are("request guide"));

    /* No box in either slot: no slot, never asked for, whatever the slots'
     * status; the box mapped in one: that one. */
    auto first = [](GuideRig &g, uint32_t s105, uint32_t s103) {
        SlotInfo m, a, b;
        m.slot = kMapSlot; m.status = 2; m.content = kStockMap; m.map_status = 1;
        a.slot = kGuideSlot; a.status = s105;
        b.slot = kOtherGuideSlot; b.status = s103;
        g.m.on_slots({m, b, a}, g.now);
    };
    for (uint32_t s105 : {0u, 1u}) {
        for (uint32_t s103 : {0u, 1u}) {
            GuideRig o(true);
            first(o, s105, s103);
            o.show_map();
            joined();
            o.pass(30000);
            char what[96];
            std::snprintf(what, sizeof what, "auto, no box, 0x105 status %u, 0x103 status %u: no slot, never asked for",
                          s105, s103);
            ok(what, o.guide_slot() == 0 && requested_none(joined()) && o.state(GuideRig::kGuide) == TargetState::Idle);
        }
    }
    GuideRig o(true);
    first(o, 1, 1);
    o.show_map();
    joined();
    logged();
    o.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    o.pass();
    ok("then the box shown in 0x105: the hold's slot, asked for there, not a loss",
       o.guide_slot() == kGuideSlot && calls_are("publish guide; request guide") &&
           logged().find("hold moves to slot 0x105, where the slot table reports 0x1000310 (class 0, map status 1) "
                         "(no slot before)") != std::string::npos);

    /* An explicit slot keeps its slot whatever the table says. */
    GuideRig x;
    x.slot(kGuideSlot, 0, 0);
    x.rows(kOtherGuideSlot, 2, {{kBox, 1}});
    x.show_map();
    joined();
    x.pass(10000);
    ok("guide_slots = 0x105, the box in 0x103 and 0x105 disabled: never asked for, idle",
       requested_none(joined()) && x.guide_slot() == kGuideSlot && x.state(GuideRig::kGuide) == TargetState::Idle);
}

/* The hold occupies its slot only while the box is mapped there: no box
 * (Waze, no route), no hold, the car's badge left in the slot; the box
 * mapped (a route), held and taken over; the box mapped again behind ours,
 * still held, through the report between the take-over's unmap and the
 * HMI's map again; the box unmapped or gone (the route over), released 3 s
 * later and not asked for again; in 0x105 or 0x103, fixed or auto. */
static void guide_box_comes_and_goes()
{
    for (bool from_table : {false, true}) {
        for (uint64_t slot : {kGuideSlot, kOtherGuideSlot}) {
            if (!from_table && slot != kGuideSlot)
                continue;
            char tag[48];
            std::snprintf(tag, sizeof tag, "%s, 0x%llx: ", from_table ? "auto" : "guide_slots = 0x105",
                          (unsigned long long)slot);
            const std::string t = tag;
            GuideRig r(from_table);
            if (from_table)
                r.slot(slot == kGuideSlot ? kOtherGuideSlot : kGuideSlot, 0, 0);
            r.rows(slot, 2, {{kBelt, 3}});   /* the badge: the slot empty but for the parked seat-belt panel */
            r.show_map();
            joined();
            logged();
            r.pass(30000);
            ok((t + "the map shown, no box: never asked for, idle").c_str(),
               requested_none(joined()) && r.state(GuideRig::kGuide) == TargetState::Idle &&
                   r.m.requested(0) && logged().find("target guide") == std::string::npos);
            r.rows(slot, 2, {{kBox, 1}, {kBelt, 3}});   /* a route */
            r.pass();
            ok((t + "the box shown: asked for in the same pass").c_str(),
               joined().find("request guide") != std::string::npos && r.guide_slot() == slot &&
                   logged().find("target guide: the box is mapped: held while the map is shown") != std::string::npos);
            r.rows(slot, 2, {{kBox, 1}, {kBelt, 3}, {kGuideScene, 3}});
            r.m.on_parked(kGuideScene, r.now);
            joined();
            r.pass();
            ok((t + "parked behind it: taken over").c_str(), calls_are("take over guide 0x1000310; slots?"));
            /* The KOMBI shows ours; the HMI maps the box again behind ours
             * about 100 ms later, in a report of its own. */
            r.rows(slot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 0}});
            r.m.on_shown(kGuideScene, r.now);
            r.pass(100);
            r.rows(slot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
            r.pass(60000);
            ok((t + "the box unmapped by the take-over, then mapped again behind ours: held a minute, no traffic").c_str(),
               calls_are("") && r.state(GuideRig::kGuide) == TargetState::Shown &&
                   logged().find("no box mapped") == std::string::npos);
            r.rows(slot, 2, {{kGuideScene, 1}, {kBelt, 3}});   /* the route over: the box unfetched */
            r.pass(2900);
            ok((t + "the box gone: held under 3 s").c_str(), calls_are("") &&
                                                               r.state(GuideRig::kGuide) == TargetState::Shown);
            r.pass(200);
            ok((t + "the box gone 3 s: released, logged").c_str(),
               calls_are("release guide") && r.state(GuideRig::kGuide) == TargetState::Idle &&
                   logged().find("target guide: no box mapped: not held") != std::string::npos);
            r.rows(slot, 2, {{kBelt, 3}});
            r.pass(30000);
            ok((t + "then no box, the map still shown: never asked for again, not given up").c_str(),
               requested_none(joined()) && r.state(GuideRig::kGuide) == TargetState::Idle &&
                   r.guide_slot() == slot && logged().find("given up") == std::string::npos);
            r.rows(slot, 2, {{kBox, 1}, {kBelt, 3}});
            r.pass();
            ok((t + "the next route: asked for again").c_str(), joined().find("request guide") != std::string::npos);
        }
    }

    /* The route over with the box listed, unmapped (not unfetched). */
    GuideRig u;
    u.rows(kGuideSlot, 2, {{kBox, 1}});
    u.show_map();
    u.hold();
    u.pass(1000);
    joined();
    u.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 0}});
    u.pass(3100);
    ok("the box listed unmapped 3 s: released", calls_are("release guide") &&
                                                    u.state(GuideRig::kGuide) == TargetState::Idle);

    /* Parked behind the box, the route over before a take-over: the KOMBI
     * shows ours; released 3 s later. */
    GuideRig p;
    p.rows(kGuideSlot, 2, {{kBox, 1}});
    p.show_map();
    p.pass();
    p.rows(kGuideSlot, 2, {{kBox, 1}, {kGuideScene, 3}});
    p.m.on_parked(kGuideScene, p.now);
    joined();
    p.rows(kGuideSlot, 2, {{kGuideScene, 1}});
    p.m.on_shown(kGuideScene, p.now);
    p.pass(3100);
    ok("parked, the box gone before the take-over: released 3 s later, no take-over",
       calls_are("release guide") && p.state(GuideRig::kGuide) == TargetState::Idle);

    /* The seat-belt warning while held, the route over during it: not asked
     * for again when the warning goes. */
    GuideRig b;
    b.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    b.show_map();
    b.hold();
    joined();
    b.rows(kGuideSlot, 2, {{kBelt, 1}, {kGuideScene, 3}, {kBox, 3}});
    b.m.on_parked(kGuideScene, b.now);
    b.pass();
    ok("the seat-belt panel shown over the hold: released at once", calls_are("slots?; release guide") &&
                                                                       b.state(GuideRig::kGuide) == TargetState::Idle);
    b.rows(kGuideSlot, 2, {{kBelt, 1}});
    b.pass(5000);
    b.rows(kGuideSlot, 2, {{kBelt, 3}});
    b.pass(10000);
    ok("the route over during the warning, the warning gone: not asked for again", requested_none(joined()));

    /* The box shown on_ms and gone off_ms, over and over for 60 s, the map
     * shown; the KOMBI parks the hold behind the box, a take-over shows it
     * with the box parked, a release leaves the box. */
    struct Flap {
        std::vector<int64_t> requests, overs;
        int releases = 0;
    };
    auto flap = [](int64_t on_ms, int64_t off_ms) {
        GuideRig f;
        f.show_map();
        joined();
        Flap out;
        bool box = false;
        uint32_t ours = 0;   /* our map status */
        auto report = [&]() {
            std::vector<std::pair<uint64_t, uint32_t>> v;
            if (ours)
                v.push_back({kGuideScene, ours});
            if (box)
                v.push_back({kBox, ours == 1 ? 3u : 1u});
            if (v.empty())
                f.slot(kGuideSlot, 1, 0);
            else
                f.rows(kGuideSlot, 2, v);
        };
        int64_t next = f.now;
        for (int64_t end = f.now + 60000; f.now < end;) {
            if (f.now >= next) {
                box = !box;
                next = f.now + (box ? on_ms : off_ms);
                report();
            }
            f.pass();
            const std::string c = joined();
            if (c.find("request guide") != std::string::npos) {
                out.requests.push_back(f.now);
                ours = box ? 3 : 1;
                report();
                if (box)
                    f.m.on_parked(kGuideScene, f.now);
                else
                    f.m.on_shown(kGuideScene, f.now);
            }
            if (c.find("take over guide 0x1000310") != std::string::npos) {
                out.overs.push_back(f.now);
                ours = 1;
                report();
                f.m.on_shown(kGuideScene, f.now);
            }
            if (c.find("release guide") != std::string::npos) {
                out.releases++;
                ours = 0;
                report();
            }
        }
        return out;
    };
    auto spaced = [](const Flap &x) {
        bool ok = true;
        for (size_t i = 1; i < x.requests.size(); i++)
            ok = ok && x.requests[i] - x.requests[i - 1] >= SlotManager::kMinRequestGapMs;
        for (size_t i = 1; i < x.overs.size(); i++)
            ok = ok && x.overs[i] - x.overs[i - 1] >= SlotManager::kTakeOverMs[std::min<size_t>(i - 1, 5)];
        return ok;
    };
    const Flap fast = flap(150, 150);
    ok("the box shown and gone every 150 ms for 60 s: held throughout, one request, one take-over, no release",
       fast.requests.size() == 1 && fast.overs.size() == 1 && fast.releases == 0);
    const Flap slow = flap(200, 3100);
    ok("the box shown 200 ms, gone 3.1 s, for 60 s: released each time, requests at least 1 s apart, take-overs on "
       "their steps",
       slow.requests.size() >= 10 && slow.releases >= 10 && !slow.overs.empty() && spaced(slow));
}

/* The INCIDENT lines of what was logged since the last call. */
static std::string incidents()
{
    std::string s;
    std::istringstream in(logged());
    std::string line;
    while (std::getline(in, line)) {
        const size_t at = line.find("INCIDENT");
        if (at != std::string::npos)
            s += line.substr(at) + "\n";
    }
    return s;
}

/* A shown target lost and back: one line each, the reason named. */
static void incident_lines()
{
    Rig r;
    r.m.budget_text = [] { return std::string("cap 5000 ceiling 5500"); };
    /* Asked for again by the slot manager, then shown. */
    auto back = [&r]() {
        for (int k = 0; k < 6000 && r.state(0) != TargetState::Acquiring; k++)
            r.run(10);
        r.m.on_shown(kMapScene, r.now);
        return r.state(0) == TargetState::Shown;
    };
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    r.run(312000);
    logged();
    r.slot(kMapSlot, 1, 0);
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    ok("a removal: lost, KOMBI removal, the budget, how long it was shown",
       incidents() == "INCIDENT target map lost: KOMBI removal, cap 5000 ceiling 5500, since-shown 312 s\n");
    r.run(2130);
    r.m.on_shown(kMapScene, r.now);
    ok("shown again: back after the time it was gone, by a full request",
       incidents() == "INCIDENT target map back after 2130 ms, full request\n");

    r.run(1000);
    r.m.on_lost(kMapScene, "unmapped", r.now);
    ok("unmapped", incidents().find("INCIDENT target map lost: unmap, ") == 0);
    const bool b1 = back();
    ok("back", b1 && incidents().find("INCIDENT target map back after ") == 0);

    r.port.up = false;
    r.m.on_availability(false, r.now);
    ok("display service gone", incidents().find("INCIDENT target map lost: display service gone, ") == 0);
    r.port.up = true;
    r.m.on_availability(true, r.now);
    const bool b2 = back();
    ok("and back", b2 && incidents().find("INCIDENT target map back after ") == 0);

    r.slot(kMapSlot, 0, kMapScene);   /* a door-open warning locks the slot */
    r.m.on_lost(kMapScene, "unmapped", r.now);
    ok("slot locked", incidents().find("INCIDENT target map lost: slot locked, ") == 0);
    r.slot(kMapSlot, 1, 0);
    back();
    incidents();
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
    ok("parked behind other content", incidents().find("INCIDENT target map lost: parked behind other content, ") == 0);
    r.m.on_shown(kMapScene, r.now);
    ok("shown from parked: back, shown again by the display",
       incidents() == "INCIDENT target map back after 0 ms, shown again by the display\n");

    r.m.want(0, false, false);
    r.run(100);
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    r.run(3000);
    ok("lingering (nothing wants it): no incident", incidents().empty());

    Rig n;   /* lost, then no longer wanted before it came back */
    n.m.want(0, true, true);
    n.m.tick(n.now);
    n.m.on_shown(kMapScene, n.now);
    n.run(5000);
    n.slot(kMapSlot, 1, 0);
    n.m.on_lost(kMapScene, "fetch removed", n.now);
    n.run(500);
    n.m.want(0, false, false);
    n.run(5000);
    const std::string nb = incidents();
    ok("lost, then released unwanted: not back, once; no budget without budget_text",
       nb == "INCIDENT target map lost: KOMBI removal, since-shown 5 s\n"
             "INCIDENT target map not back: released after 2000 ms\n");

    Rig v;   /* the table still names our id: the next report decides */
    v.m.want(0, true, true);
    v.m.tick(v.now);
    v.m.on_shown(kMapScene, v.now);
    v.run(1000);
    v.slot(kMapSlot, 2, kMapScene);
    incidents();
    v.m.on_lost(kMapScene, "fetch removed", v.now);
    const bool waits = incidents().empty();
    v.slot(kMapSlot, 2, kHmiMap);
    v.run(10);
    ok("a loss whose holder the next report decides: logged then, with it",
       waits && incidents().find("INCIDENT target map lost: taken by the stock HMI, ") == 0);

    Rig a;   /* the display service gone before that report */
    a.m.want(0, true, true);
    a.m.tick(a.now);
    a.m.on_shown(kMapScene, a.now);
    a.run(1000);
    a.slot(kMapSlot, 2, kMapScene);
    a.m.on_lost(kMapScene, "fetch removed", a.now);
    incidents();
    a.port.up = false;
    a.m.on_availability(false, a.now);
    ok("the display service gone before the report decides: logged then, once",
       incidents() == "INCIDENT target map lost: display service gone, since-shown 1 s\n");
    joined();
}

/* Kept through a lock: the port keeps a scene the lock unmapped fetched. */
struct KeepRig : Rig {
    KeepRig() { port.keeps = true; }
    /* Shown, the HMI's map parked behind ours (slot 0x100 as the car reports it). */
    void show_map()
    {
        m.want(0, true, true);
        m.tick(now);
        rows(kMapSlot, 2, {{kMapScene, 1}, {kHmiMap, 3}});
        m.on_shown(kMapScene, now);
    }
    /* The centre group locked: the report first, then the unmap (car log
     * 2026-11-15 06:14:24, 12 ms apart). */
    void lock_map()
    {
        rows(kMapSlot, 0, {{kMapScene, 1}, {kHmiMap, 3}, {kHmiMap, 0}});
        run(10);
        m.on_lost(kMapScene, "unmapped", now);
    }
    void unlock_map() { rows(kMapSlot, 1, {{kMapScene, 0}, {kHmiMap, 0}}); }
};

static bool has(const std::string &s, const char *x) { return s.find(x) != std::string::npos; }

/* A 2 s red-light flash locking every centre and right slot at once. */
static void keep_group_lock()
{
    KeepRig r;
    r.show_map();
    r.m.want(1, true, false);
    r.m.tick(r.now);
    r.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    r.m.on_shown(kPanelScene, r.now);
    r.run(20000);
    joined();
    incidents();
    const int64_t lock = r.now;
    r.lock_map();
    r.rows(kPanelSlot, 0, {{kPanelScene, 1}});
    r.m.on_lost(kPanelScene, "unmapped", r.now);
    ok("keep: a whole-group lock: map and panel kept, nothing released",
       calls_are("keep map; keep panel") && r.m.kept(0) && r.m.kept(1) && !r.m.requested(0) && !r.m.requested(1) &&
           !r.m.flushing(0) && !r.m.flushing(1) && r.m.status(0).reason == "slot locked");
    ok("keep: the loss logged as a lock", has(incidents(), "INCIDENT target map lost: slot locked, "));
    r.run(2000);
    const std::string during = joined();
    ok("keep: 2 s locked: nothing asked for, released or re-mapped; the table polled",
       !has(during, "request") && !has(during, "release") && !has(during, "remap") && has(during, "slots?"));
    r.unlock_map();
    ok("keep: the first report of the slot not locked re-maps the map at once, no fetch",
       calls_are("remap map") && r.state(0) == TargetState::Acquiring && r.m.requested(0) && !r.m.flushing(0));
    r.rows(kPanelSlot, 1, {{kPanelScene, 0}});
    ok("keep: and the panel with its slot's report", calls_are("remap panel"));
    r.rows(kMapSlot, 2, {{kMapScene, 1}, {kHmiMap, 3}});
    r.m.on_shown(kMapScene, r.now);
    r.m.on_shown(kPanelScene, r.now);
    ok("keep: shown, flushing again, no unfetch, no scene resent",
       r.state(0) == TargetState::Shown && r.m.flushing(0) && r.m.flushing(1) && !r.m.kept(0) &&
           r.scenes.resends == 0 && calls_are(""));
    char want[96];
    std::snprintf(want, sizeof want, "INCIDENT target map back after %lld ms, fast re-map", (long long)(r.now - lock - 10));
    ok("keep: back after the lock, by a fast re-map", has(incidents(), want));
    r.run(40000);
    ok("keep: shown on, nothing more", calls_are("") && r.state(0) == TargetState::Shown);
}

/* Car log 2026-11-15 06:14:24-32: an 8.2 s centre lock (a door open). */
static void keep_door_lock()
{
    KeepRig r;
    r.show_map();
    r.run(30000);
    joined();
    r.lock_map();
    ok("door: kept", calls_are("keep map"));
    r.run(8200);
    const std::string during = joined();
    ok("door: 8.2 s: nothing asked for while locked", !has(during, "request") && !has(during, "remap") &&
                                                        !has(during, "release"));
    r.rows(0x105, 1, {{0x010004f1, 0}});   /* another slot of the group first */
    ok("door: another slot's report does not re-map it", calls_are(""));
    r.unlock_map();
    ok("door: its own slot back: re-mapped in that report", calls_are("remap map"));
    r.rows(kMapSlot, 2, {{kMapScene, 1}, {kHmiMap, 0}});
    r.m.on_shown(kMapScene, r.now);
    r.run(10);
    ok("door: shown ahead of the HMI's map: no take-over, nothing resent",
       r.state(0) == TargetState::Shown && calls_are("") && r.scenes.resends == 0);
}

/* The HMI's map shown first after the unlock: the first take-over at once,
 * later ones on their steps. */
static void keep_take_over_after_lock()
{
    KeepRig r;
    r.m.want(0, true, true);
    r.m.tick(r.now);
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    r.m.on_parked(kMapScene, r.now);
    std::vector<int64_t> at;
    for (int k = 0; k < 2000 && at.size() < 5; k++) {
        r.run(10);
        if (has(joined(), "take over map"))
            at.push_back(r.now);
    }
    r.rows(kMapSlot, 2, {{kMapScene, 1}, {kHmiMap, 3}});
    r.m.on_shown(kMapScene, r.now);   /* the fifth worked; the next would wait 10 s */
    r.run(1000);
    joined();
    r.lock_map();
    r.run(2000);
    logged();
    r.unlock_map();
    ok("take-over: re-mapped", has(joined(), "remap map"));
    r.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});   /* the HMI's map first */
    r.m.on_parked(kMapScene, r.now);
    r.m.tick(r.now);
    const int64_t first = r.now;
    ok("take-over: parked behind the HMI's map after the unlock: taken over at once",
       at.size() == 5 && has(joined(), "take over map 0x1000300") && has(logged(), "the first after a lock, at once"));
    int64_t next = -1;
    for (int k = 0; k < 4000 && next < 0; k++) {
        r.run(10);
        if (has(joined(), "take over map"))
            next = r.now;
    }
    ok("take-over: the next on its step (30 s after the sixth)", next - first == 30000);

    KeepRig s;   /* shown long enough that the count started over */
    s.show_map();
    s.run(20000);
    s.lock_map();
    s.run(2000);
    s.unlock_map();
    s.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    s.m.on_parked(kMapScene, s.now);
    joined();
    s.m.tick(s.now);
    const bool once = has(joined(), "take over map");
    s.run(1490);
    const bool quiet = !has(joined(), "take over");
    s.run(10);
    ok("take-over: at once, then 1.5 s later", once && quiet && has(joined(), "take over map"));

    KeepRig y;   /* a layer that yields: never a take-over */
    y.m.want(0, true, false);
    y.m.tick(y.now);
    y.rows(kMapSlot, 2, {{kMapScene, 1}});
    y.m.on_shown(kMapScene, y.now);
    y.lock_map();
    y.run(2000);
    y.unlock_map();
    y.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    y.m.on_parked(kMapScene, y.now);
    y.run(5000);
    ok("take-over: none without a contending layer", !has(joined(), "take over"));
}

/* A re-map refused or a fetch the display dropped: released, then the full
 * path, spaced. */
static void keep_falls_back()
{
    KeepRig r;
    r.show_map();
    r.run(30000);
    r.lock_map();
    r.run(2000);
    joined();
    r.unlock_map();
    const int64_t remapped = r.now;
    r.m.on_refused(kMapScene, Refusal::Transient, "map refused (code 0x0d)", r.now);
    ok("fallback: the re-map refused: released", calls_are("remap map; release map") &&
                                                    r.state(0) == TargetState::Waiting && !r.m.kept(0));
    int64_t full = -1;
    for (int k = 0; k < 300 && full < 0; k++) {
        r.run(10);
        if (has(joined(), "request map"))
            full = r.now;
    }
    ok("fallback: asked for in full 1 s after the re-map", full - remapped == SlotManager::kMinRequestGapMs);
    r.m.on_shown(kMapScene, r.now);
    ok("fallback: back by a full request", has(incidents(), "back after") && r.state(0) == TargetState::Shown);

    KeepRig d;   /* the fetch gone meanwhile */
    d.show_map();
    d.run(30000);
    d.lock_map();
    d.run(2000);
    d.port.fetched = false;
    joined();
    d.unlock_map();
    ok("fallback: the fetch no longer held: nothing mapped, released", calls_are("remap map (not fetched); release map"));
    d.run(10);
    ok("fallback: asked for in full", calls_are("request map"));
    d.m.on_shown(kMapScene, d.now);
    ok("fallback: back, by a full request", has(incidents(), ", full request"));

    KeepRig b;   /* busy: the existing ladder */
    b.show_map();
    b.run(30000);
    b.lock_map();
    b.run(2000);
    b.unlock_map();
    joined();
    b.m.on_refused(kMapScene, Refusal::Busy, "map E_DCSM_PRIOTOOLOW", b.now);
    ok("fallback: a busy refusal: released, on the ladder", calls_are("release map") &&
                                                               b.m.status(0).retry_ms == b.now + 2000);

    KeepRig n;   /* accepted, not mapped, after a re-map */
    n.show_map();
    n.run(30000);
    n.lock_map();
    n.run(2000);
    n.unlock_map();
    n.port.accepted["map"] = n.now;
    joined();
    n.run(2990);
    const bool waits = !has(joined(), "release");
    n.run(10);
    ok("fallback: a re-map accepted and not mapped for 3 s: released and asked for again",
       waits && has(joined(), "release map"));
}

/* A lock longer than kKeepMs, the heartbeat replies stopping, the display
 * service gone. */
static void keep_limits()
{
    KeepRig r;
    r.show_map();
    r.lock_map();
    joined();
    for (int n = 0; n < 35; n++) {   /* each poll reports the lock again */
        r.run(5000);
        r.rows(kMapSlot, 0, {{kMapScene, 0}, {kHmiMap, 0}});
    }
    r.run(SlotManager::kKeepMs - 35 * 5000 - 20);
    ok("limit: kept just under 3 min, nothing released", !has(joined(), "release") && r.m.kept(0));
    r.run(20);
    ok("limit: 3 min: released (unfetched), still waiting on the lock",
       calls_are("release map") && !r.m.kept(0) && r.state(0) == TargetState::Waiting &&
           r.m.status(0).reason == "slot locked");
    r.run(4000);
    ok("limit: nothing asked for while locked", !has(joined(), "request"));
    r.unlock_map();
    r.run(10);
    ok("limit: the slot back: asked for in full", calls_are("request map"));

    KeepRig h;
    h.show_map();
    h.run(1000);
    h.lock_map();
    joined();
    h.m.drop_kept("heartbeat replies stopped", h.now);
    ok("heartbeat: replies stopped: the kept scene released", calls_are("release map") && !h.m.kept(0));
    h.unlock_map();
    h.run(10);
    ok("heartbeat: asked for in full once the slot is back", calls_are("request map"));

    KeepRig d;
    d.show_map();
    d.lock_map();
    joined();
    d.port.up = false;
    d.m.on_availability(false, d.now);
    d.run(100);
    ok("drop: the display service gone during a lock: nothing kept, nothing sent",
       calls_are("") && !d.m.kept(0) && d.state(0) == TargetState::Unavailable);
    d.port.up = true;
    d.m.on_availability(true, d.now);
    d.unlock_map();
    d.run(1100);
    ok("drop: back: asked for in full", calls_are("request map"));

    KeepRig u;
    u.show_map();
    u.lock_map();
    joined();
    u.m.want(0, false, false);
    u.run(10);
    ok("unwanted: a kept scene nothing wants is released at once", calls_are("release map") &&
                                                                      u.state(0) == TargetState::Idle);
    u.unlock_map();
    u.run(1000);
    ok("unwanted: nothing re-mapped", calls_are(""));
}

/* Locks coming and going faster than the request spacing. */
static void keep_flapping()
{
    KeepRig r;
    r.show_map();
    r.run(30000);
    joined();
    bool locked = false, mapped_while_locked = false;
    std::vector<int64_t> remaps;
    int unlocks = 0;
    for (int k = 0; k < 40; k++) {
        if (!locked) {
            r.rows(kMapSlot, 0, {{kMapScene, r.state(0) == TargetState::Shown ? 1u : 0u}, {kHmiMap, 0}});
            if (r.state(0) == TargetState::Shown)
                r.m.on_lost(kMapScene, "unmapped", r.now);
            else if (r.state(0) == TargetState::Acquiring)
                r.m.on_refused(kMapScene, Refusal::Transient, "map refused", r.now);
        } else {
            unlocks++;
            r.unlock_map();
        }
        locked = !locked;
        const std::string c = joined();
        if (has(c, "remap map")) {
            remaps.push_back(r.now);
            if (locked)
                mapped_while_locked = true;
            r.m.on_shown(kMapScene, r.now);
        }
        for (int t = 0; t < 15; t++) {
            r.run(10);
            const std::string d = joined();
            mapped_while_locked = mapped_while_locked || (locked && (has(d, "remap") || has(d, "request")));
            if (has(d, "remap map")) {
                remaps.push_back(r.now);
                r.m.on_shown(kMapScene, r.now);
            }
        }
    }
    bool spaced = true;
    for (size_t k = 1; k < remaps.size(); k++)
        spaced = spaced && remaps[k] - remaps[k - 1] >= SlotManager::kMinRequestGapMs;
    ok("flapping: 150 ms locks: never mapped while locked, re-maps at least 1 s apart, at most one per unlock",
       !mapped_while_locked && spaced && !remaps.empty() && (int)remaps.size() <= unlocks);
    ok("flapping: never released", r.m.kept(0) || r.m.requested(0));
}

/* The panel and the HUD (one scene id, each in its own group). */
static void keep_panel_and_hud()
{
    KeepRig r;
    r.m.want(2, true, false);
    r.m.tick(r.now);
    r.rows(kHudSlot, 2, {{kPanelScene, 1}});
    r.m.on_shown(kPanelScene, r.now);
    r.run(5000);
    joined();
    r.rows(kHudSlot, 0, {{kPanelScene, 1}});
    r.m.on_lost(kPanelScene, "unmapped", r.now);
    ok("hud: kept through a HUD group lock", calls_are("keep hud") && r.m.kept(2));
    r.m.want(1, true, false);   /* the panel wants the HUD's scene id meanwhile */
    r.run(2000);
    ok("hud: the panel waits for the scene id; the kept scene stays published",
       r.state(1) == TargetState::Waiting && r.m.status(1).reason == "scene id in use by another target" &&
           !has(joined(), "unpublish"));
    r.rows(kHudSlot, 1, {{kPanelScene, 0}});
    ok("hud: re-mapped when the slot is back", has(joined(), "remap hud"));
    r.m.on_shown(kPanelScene, r.now);
    ok("hud: shown, nothing resent", r.state(2) == TargetState::Shown && r.scenes.resends == 0);

    KeepRig p;   /* the panel parked behind other content when the lock comes */
    p.m.want(1, true, false);
    p.m.tick(p.now);
    p.rows(kPanelSlot, 2, {{0x01000401, 1}, {kPanelScene, 3}});
    p.m.on_parked(kPanelScene, p.now);
    p.run(1000);
    joined();
    p.rows(kPanelSlot, 0, {{0x01000401, 0}, {kPanelScene, 3}});
    p.m.on_lost(kPanelScene, "unmapped", p.now);
    ok("panel: parked (it yields), then locked: released, not kept", calls_are("release panel") &&
                                                                                  !p.m.kept(1));

    KeepRig c;   /* the map parked behind the stock map, contending */
    c.m.want(0, true, true);
    c.m.tick(c.now);
    c.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    c.m.on_parked(kMapScene, c.now);
    c.run(1000);
    joined();
    c.rows(kMapSlot, 0, {{kHmiMap, 0}, {kMapScene, 3}});
    c.m.on_lost(kMapScene, "unmapped", c.now);
    ok("map: parked and contending, then locked: kept", calls_are("keep map") && c.m.kept(0));
    c.unlock_map();
    c.m.on_shown(kMapScene, c.now);
    ok("map: re-mapped and shown first", has(joined(), "remap map") && c.state(0) == TargetState::Shown);

    KeepRig q;   /* parked, the lock unmapping it with no map status */
    q.m.want(0, true, true);
    q.m.tick(q.now);
    q.rows(kMapSlot, 2, {{kHmiMap, 1}, {kMapScene, 3}});
    q.m.on_parked(kMapScene, q.now);
    joined();
    q.rows(kMapSlot, 0, {{kHmiMap, 0}, {kMapScene, 0}});
    ok("map: unmapped in its locked slot with no map status: kept at once", calls_are("keep map") && q.m.kept(0));

    KeepRig a;   /* a map refused with the slot locked */
    a.m.want(0, true, true);
    a.m.tick(a.now);
    joined();
    a.rows(kMapSlot, 0, {{kHmiMap, 0}});
    a.m.on_refused(kMapScene, Refusal::Transient, "map refused", a.now);
    ok("acquiring: the map refused with the slot locked: the fetch kept", calls_are("keep map") && a.m.kept(0));
    a.run(500);
    a.unlock_map();
    a.run(490);
    const bool spaced = !has(joined(), "remap");
    a.run(10);
    ok("acquiring: re-mapped once the slot is back, 1 s after the request", spaced && calls_are("remap map"));
}

/* The guide hold kept with the map through the same lock. */
static void keep_guide()
{
    GuideRig r;
    r.port.keeps = true;
    r.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    r.show_map();
    r.pass();
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    r.m.on_shown(kGuideScene, r.now);
    r.pass(1000);
    joined();
    r.rows(kMapSlot, 0, {{kMapScene, 1}});
    r.rows(kGuideSlot, 0, {{kGuideScene, 1}, {kBelt, 0}, {kBox, 0}});
    r.pass();
    r.m.on_lost(kMapScene, "unmapped", r.now);
    r.pass();
    r.m.on_lost(kGuideScene, "unmapped", r.now);
    r.pass(8200);
    const std::string during = joined();
    ok("guide: the map and the hold kept through an 8.2 s lock, nothing else",
       has(during, "keep map") && has(during, "keep guide") && !has(during, "release") && !has(during, "request") &&
           !has(during, "remap") && r.m.kept(GuideRig::kGuide));
    r.rows(kGuideSlot, 1, {{kGuideScene, 0}, {kBelt, 0}, {kBox, 0}});
    ok("guide: its slot back: re-mapped", calls_are("remap guide"));
    r.rows(kMapSlot, 1, {{kMapScene, 0}});
    ok("guide: and the map", calls_are("remap map"));
    r.m.on_shown(kGuideScene, r.now);
    r.m.on_shown(kMapScene, r.now);
    r.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}, {kBelt, 3}});   /* the HMI maps the box again behind ours */
    r.pass(10000);
    ok("guide: held again, not given up, no take-over needed",
       calls_are("") && r.state(GuideRig::kGuide) == TargetState::Shown &&
           logged().find("given up") == std::string::npos);

    GuideRig w;   /* the hold's slot back and shown 300 ms before the map's slot */
    w.port.keeps = true;
    w.rows(kGuideSlot, 2, {{kBox, 1}});
    w.show_map();
    w.pass();
    w.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
    w.m.on_shown(kGuideScene, w.now);
    w.pass(1000);
    w.rows(kMapSlot, 0, {{kMapScene, 1}});
    w.rows(kGuideSlot, 0, {{kGuideScene, 1}, {kBox, 0}});
    w.m.on_lost(kMapScene, "unmapped", w.now);
    w.pass(20);
    w.m.on_lost(kGuideScene, "unmapped", w.now);
    w.pass(2000);
    joined();
    w.rows(kGuideSlot, 1, {{kGuideScene, 0}, {kBox, 0}});
    w.pass(50);
    w.m.on_shown(kGuideScene, w.now);
    w.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
    w.pass(300);
    const bool early = !has(joined(), "release guide") && w.state(GuideRig::kGuide) == TargetState::Shown;
    w.rows(kMapSlot, 1, {{kMapScene, 0}});
    w.m.on_shown(kMapScene, w.now);
    w.pass(5000);
    ok("guide: shown again before the map's slot is back: held through it, and after",
       early && !has(joined(), "release") && w.state(GuideRig::kGuide) == TargetState::Shown);

    /* A second lock of the map's slot alone before the map is shown again:
     * the hold, its own slot free, goes with the map. */
    joined();
    w.rows(kMapSlot, 0, {{kMapScene, 1}});
    w.rows(kGuideSlot, 0, {{kGuideScene, 1}, {kBox, 0}});
    w.m.on_lost(kMapScene, "unmapped", w.now);
    w.pass(20);
    w.m.on_lost(kGuideScene, "unmapped", w.now);
    w.pass(2000);
    w.rows(kGuideSlot, 1, {{kGuideScene, 0}, {kBox, 0}});
    w.rows(kMapSlot, 1, {{kMapScene, 0}});
    w.m.on_shown(kGuideScene, w.now);
    w.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
    w.pass(20);
    w.rows(kMapSlot, 0, {{kMapScene, 0}});
    w.m.on_refused(kMapScene, Refusal::Transient, "map refused", w.now);
    w.pass(20);
    ok("guide: the map's slot locked again alone before it shows: the map kept, the hold released",
       w.m.kept(0) && has(joined(), "release guide") && !w.m.requested(GuideRig::kGuide));

    GuideRig n;   /* the box not mapped again after the unlock */
    n.port.keeps = true;
    n.rows(kGuideSlot, 2, {{kBox, 1}});
    n.show_map();
    n.pass();
    n.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
    n.m.on_shown(kGuideScene, n.now);
    n.pass(1000);
    n.rows(kMapSlot, 0, {{kMapScene, 1}});
    n.rows(kGuideSlot, 0, {{kGuideScene, 1}, {kBox, 0}});
    n.m.on_lost(kMapScene, "unmapped", n.now);
    n.m.on_lost(kGuideScene, "unmapped", n.now);
    n.pass(2000);
    n.rows(kGuideSlot, 1, {{kGuideScene, 0}});
    n.rows(kMapSlot, 1, {{kMapScene, 0}});
    n.m.on_shown(kGuideScene, n.now);
    n.m.on_shown(kMapScene, n.now);
    n.rows(kGuideSlot, 2, {{kGuideScene, 1}});
    joined();
    n.pass(SlotManager::kNotMappedMs - 20);
    const bool held = !has(joined(), "release guide");
    n.pass(40);
    ok("guide: no box after the re-map: held kNotMappedMs, then released", held && has(joined(), "release guide"));

    GuideRig o;   /* the hold's slot outside the locked group (0x103 on one car) */
    o.port.keeps = true;
    o.rows(kGuideSlot, 2, {{kBox, 1}});
    o.show_map();
    o.pass();
    o.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBox, 3}});
    o.m.on_shown(kGuideScene, o.now);
    o.pass(1000);
    joined();
    o.rows(kMapSlot, 0, {{kMapScene, 1}});
    o.m.on_lost(kMapScene, "unmapped", o.now);
    o.pass(20);
    ok("guide: only the map's slot locked: the map kept, the hold released as the map goes",
       has(joined(), "release guide") && o.m.kept(0) && !o.m.kept(GuideRig::kGuide) &&
           !o.m.requested(GuideRig::kGuide));

    GuideRig s;   /* the hold yields to the seat-belt panel shown after the unlock */
    s.port.keeps = true;
    s.rows(kGuideSlot, 2, {{kBox, 1}, {kBelt, 3}});
    s.show_map();
    s.pass();
    s.rows(kGuideSlot, 2, {{kGuideScene, 1}, {kBelt, 3}, {kBox, 3}});
    s.m.on_shown(kGuideScene, s.now);
    s.pass(1000);
    s.rows(kMapSlot, 0, {{kMapScene, 1}});
    s.rows(kGuideSlot, 0, {{kGuideScene, 1}, {kBelt, 0}, {kBox, 0}});
    s.m.on_lost(kMapScene, "unmapped", s.now);
    s.m.on_lost(kGuideScene, "unmapped", s.now);
    s.pass(500);
    joined();
    s.rows(kGuideSlot, 2, {{kBelt, 1}, {kBox, 3}});   /* the belt panel back first, before our report is handled */
    s.pass();
    ok("guide: other content shown in its slot: the kept hold released, not re-mapped",
       has(joined(), "release guide") && !s.m.kept(GuideRig::kGuide));
}

/* Runs until target i is asked for again, at most max_ms. */
static void until_acquiring(Rig &r, int i, int64_t max_ms = 60000)
{
    for (int64_t t = 0; t < max_ms && r.state(i) != TargetState::Acquiring; t += 10)
        r.run(10);
}

/* Every fetch accepted and never completed, subscriptions not observable:
 * the 2nd stall in a row republishes the scene, every 3rd reconnects. */
static void stalled_fetches()
{
    Rig r;
    int stuck = 0;
    r.m.on_renderer_stuck = [&stuck](int64_t) { stuck++; };
    r.port.fetching["map"] = true;
    r.m.want(0, true, true);
    r.m.tick(r.now);
    ok("stall: published and requested", calls_are("publish map; request map"));
    logged();
    r.run(4990);
    ok("stall: nothing before 5 s", calls_are("") && r.state(0) == TargetState::Acquiring);
    r.run(10);
    std::string l = logged();
    ok("1st stall: taken down at 5 s, its scene kept, the ladder's 2 s, no reconnect",
       calls_are("release map") && r.m.published(0) && r.state(0) == TargetState::Waiting &&
           r.m.status(0).retry_ms == r.now + 2000 && stuck == 0 &&
           has(l, "INCIDENT target map stalled: fetch accepted but never completed in 5000 ms, 1 in a row; its scene "
                  "kept; asking again on the ladder"));
    until_acquiring(r, 0);
    ok("asked again with its warm scene", calls_are("request map"));
    r.run(5000);
    l = logged();
    ok("2nd stall in a row: its scene republished, no reconnect",
       calls_are("release map; unpublish map") && !r.m.published(0) && stuck == 0 &&
           has(l, "INCIDENT target map stalled: fetch accepted but never completed in 5000 ms, 2 in a row; "
                  "republishing its scene"));
    until_acquiring(r, 0);
    ok("the next request publishes it fresh", calls_are("publish map; request map"));
    r.run(5000);
    l = logged();
    ok("3rd stall in a row: republished, exactly one reconnect",
       calls_are("release map; unpublish map") && stuck == 1 &&
           has(l, "INCIDENT target map reconnecting the RAMSES framework: 3 stalled fetches in a row"));
    for (int n = 4; n <= 5; n++) {
        until_acquiring(r, 0);
        r.run(5000);
    }
    ok("4th and 5th: no reconnect", stuck == 1);
    until_acquiring(r, 0);
    r.run(5000);
    ok("6th, over 60 s after the reconnect: the next one", stuck == 2);

    /* A showing starts the count over. */
    r.port.fetching["map"] = false;
    until_acquiring(r, 0);
    r.m.on_shown(kMapScene, r.now);
    r.m.on_lost(kMapScene, "fetch removed", r.now);
    r.port.fetching["map"] = true;
    joined();
    until_acquiring(r, 0);
    r.run(5000);
    l = logged();
    ok("after a showing: 1 in a row again, its scene kept",
       calls_are("request map; release map") && r.m.published(0) && stuck == 2 && has(l, "1 in a row; its scene kept"));

    Rig f;
    f.port.fetching["map"] = true;
    f.m.want(0, true, true);
    f.m.tick(f.now);
    f.run(5000);
    until_acquiring(f, 0);
    f.run(5000);
    until_acquiring(f, 0);
    joined();
    f.m.on_fetched(kMapScene, f.now);   /* fetch status 2; the map then unanswered */
    f.port.fetching["map"] = false;
    f.run(5000);
    ok("fetched, then no answer: not a stall, nothing republished", calls_are("release map") && f.m.published(0));
    f.port.fetching["map"] = true;
    until_acquiring(f, 0);
    logged();
    f.run(5000);
    ok("a fetch completed starts the count over: 1 in a row",
       calls_are("request map; release map") && has(logged(), "1 in a row; its scene kept"));

    Rig n;   /* the display answering nothing after a stall: still counted */
    n.port.fetching["map"] = true;
    n.m.want(0, true, true);
    n.m.tick(n.now);
    n.run(5000);
    n.port.fetching["map"] = false;
    until_acquiring(n, 0);
    joined();
    logged();
    n.run(5000);
    ok("no answer after a stall: 2 in a row, republished",
       calls_are("release map; unpublish map") &&
           has(logged(), "INCIDENT target map stalled: no answer after a fetch accepted and never completed in 5000 "
                         "ms, 2 in a row; republishing its scene"));

    n.port.up = false;   /* the display service gone and back: the count starts over */
    n.m.on_availability(false, n.now);
    n.port.up = true;
    n.m.on_availability(true, n.now);
    n.port.fetching["map"] = true;
    until_acquiring(n, 0);
    logged();
    n.run(5000);
    ok("the display service back: 1 in a row", has(logged(), "1 in a row; its scene kept"));

    Rig p;   /* no answers alone are no stall */
    p.m.want(0, true, true);
    p.m.tick(p.now);
    p.run(5000);
    until_acquiring(p, 0);
    p.run(5000);
    ok("no answer twice, no fetch accepted: nothing republished", p.m.published(0) &&
                                                                     !has(logged(), "stalled"));

    Rig w;
    w.port.fetching["map"] = true;
    w.m.want(0, true, true);
    w.m.tick(w.now);
    w.run(5000);
    until_acquiring(w, 0);
    w.run(5000);
    w.m.want(0, false, false);
    w.run(100);
    w.m.want(0, true, true);
    until_acquiring(w, 0);
    logged();
    w.run(5000);
    ok("not wanted for a while starts the count over: 1 in a row", has(logged(), "1 in a row"));

    /* Two targets stalling together: one reconnect, the second refused. */
    Rig b;
    stuck = 0;
    b.m.on_renderer_stuck = [&stuck](int64_t) { stuck++; };
    b.port.fetching["map"] = b.port.fetching["panel"] = true;
    b.m.want(0, true, true);
    b.m.want(1, true, false);
    b.m.tick(b.now);
    logged();
    for (int n = 0; n < SlotManager::kReconnectAfter; n++) {
        until_acquiring(b, 0);
        ok("two targets: requested together", b.state(1) == TargetState::Acquiring);
        b.run(5000);
    }
    ok("two targets stalling three times together: one reconnect",
       stuck == 1 && has(logged(), "target panel: 3 stalled fetches in a row; the RAMSES framework "
                                   "was reconnected 0 s ago: not again before 60 s"));
    calls.clear();
}

/* The first request after the display service comes up waits for the stock
 * HMI's content in the slot table, 10 s at most; at once when it is there. */
static void boot_hold()
{
    Rig r;
    r.port.table = true;
    r.m.on_availability(true, r.now);
    r.m.want(0, true, true);
    r.run(5000);
    r.slot(0x101, 2, kMapScene);   /* our own scene id, left from before a restart: not the HMI's */
    r.run(4990);
    std::string c = joined();
    ok("boot hold: nothing asked for in 10 s without the stock HMI's content, the table polled",
       requested_none(c) && has(c, "slots?"));
    r.run(10);
    ok("boot hold: asked for at 10 s", calls_are("publish map; request map"));

    Rig s;
    s.port.table = true;
    s.m.on_availability(true, s.now);
    s.m.want(0, true, true);
    s.run(3000);
    ok("boot hold: nothing at 3 s", requested_none(joined()));
    s.slot(0x101, 2, kStockMap);
    s.m.tick(s.now);
    ok("boot hold: the stock HMI's content mapped: asked for at once", calls_are("publish map; request map"));

    Rig q;   /* cluster-render restarted while the car runs */
    q.port.table = true;
    const int64_t up = q.now;
    q.m.on_availability(true, q.now);
    q.rows(0x101, 2, {{kStockMap, 1}});
    q.m.want(0, true, true);
    q.run(990);
    ok("restart: the first table has the HMI's content: nothing before the settle time", requested_none(joined()));
    q.run(10);
    ok("restart: asked for at 1 s, as with no hold", calls_are("publish map; request map") && q.now - up == 1000);

    Rig e;   /* a port with no slot table (iDrive 8): no hold */
    e.m.on_availability(true, e.now);
    e.m.want(0, true, true);
    e.run(1000);
    ok("no slot table: asked for at 1 s", calls_are("publish map; request map"));
}

/* Preload: rigs whose port can keep a fetch unmapped. The panel (1) has
 * the HUD's (2) scene id in this rig. */
struct PreloadRig : Rig {
    PreloadRig() { port.preloads_ok = true; }
    /* What the panel's layers want: shown, and a preload layer. */
    void panel(bool wanted, bool preload) { m.want(1, wanted, false, true, true, preload); }
    /* The panel preloaded: fetched, not mapped. */
    void loaded()
    {
        panel(false, true);
        m.tick(now);
        m.on_fetched(kPanelScene, now);
        joined();
    }
};

static void preload_load_and_map()
{
    PreloadRig r;
    r.panel(false, true);
    r.m.tick(r.now);
    ok("preload: the first preload layer publishes the scene and fetches it, no map",
       calls_are("publish panel; load panel") && r.state(1) == TargetState::Loading && !r.m.requested(1) &&
           r.m.loaded(1) && r.m.flushing(1) && !r.m.kept(1));
    r.run(1000);
    ok("preload: loading until the fetch completes, nothing more sent", calls_are("") &&
                                                                         r.state(1) == TargetState::Loading);
    r.m.on_fetched(kPanelScene, r.now);
    ok("preload: loaded once fetched: not requested, staged and flushed",
       r.state(1) == TargetState::Loaded && !r.m.requested(1) && r.m.flushing(1) && calls_are(""));
    ok("preload: a scene published for the load is not charged as a resend", r.scenes.resends == 0);
    r.run(120000);
    ok("preload: kept loaded, no traffic", calls_are("") && r.state(1) == TargetState::Loaded);
    ok("preload: nothing to wake for while loaded and not wanted", r.m.wake_in_ms(r.now) < 0);

    r.panel(true, true);
    r.m.tick(r.now);
    ok("preload: wanted: the loaded scene mapped with no fetch, flushes going on",
       calls_are("remap panel") && r.state(1) == TargetState::Acquiring && r.m.requested(1) && !r.m.loaded(1) &&
           r.m.flushing(1) && !r.m.kept(1));
    r.m.on_shown(kPanelScene, r.now);
    ok("preload: shown", r.state(1) == TargetState::Shown && r.m.flushing(1));
    r.run(5000);
    joined();
    r.panel(false, true);
    r.run(2990);
    ok("preload: not wanted: lingering, still mapped", r.state(1) == TargetState::Lingering && calls_are(""));
    r.run(20);
    ok("preload: the linger over: unmapped, its fetch kept, loaded again, not released",
       calls_are("unmap panel") && r.state(1) == TargetState::Loaded && r.m.loaded(1) && !r.m.requested(1) &&
           r.m.flushing(1));
    r.run(400);
    r.panel(true, true);
    r.m.tick(r.now);
    ok("preload: wanted again: mapped again with no fetch", calls_are("remap panel"));
    r.m.on_shown(kPanelScene, r.now);
    r.panel(false, false);
    r.run(3010);
    ok("preload: the last preload layer gone with it: released after its linger",
       calls_are("release panel") && r.state(1) == TargetState::Idle && !r.m.loaded(1) && r.m.published(1));
    r.run(60000);
    ok("preload: and nothing asked for after", calls_are(""));

    PreloadRig g;   /* gone while loaded */
    g.loaded();
    g.panel(false, false);
    g.m.tick(g.now);
    ok("preload: no preload layer left while loaded: released at once",
       calls_are("release panel") && g.state(1) == TargetState::Idle && !g.m.loaded(1) && !g.m.flushing(1));
    g.panel(false, true);
    g.m.tick(g.now);
    ok("preload: a preload layer again: loaded no sooner than 1 s after the last load", calls_are(""));
    g.run(1000);
    ok("preload: then loaded again", calls_are("load panel") && g.state(1) == TargetState::Loading);
    g.panel(false, false);
    g.m.tick(g.now);
    ok("preload: gone while loading: released", calls_are("release panel") && g.state(1) == TargetState::Idle);
    g.panel(false, true);
    g.run(1000);
    g.m.on_fetched(kPanelScene, g.now);
    ok("preload: its warm scene's whole resend charged at the fetch",
       calls_are("load panel") && g.state(1) == TargetState::Loaded && g.scenes.resends == 1);

    PreloadRig w;   /* wanted while loading: mapped once fetched */
    w.panel(true, true);
    w.m.tick(w.now);
    ok("preload: wanted from the start: a request as with no preload", calls_are("publish panel; request panel"));
    w.m.on_shown(kPanelScene, w.now);
    w.panel(false, true);
    w.run(3010);
    ok("preload: and unmapped, its fetch kept, after its linger", calls_are("unmap panel") &&
                                                                   w.state(1) == TargetState::Loaded);

    PreloadRig p;   /* parked, nothing wanting it */
    p.panel(true, true);
    p.m.tick(p.now);
    p.rows(kPanelSlot, 2, {{0x01000500, 1}, {kPanelScene, 3}});
    p.m.on_parked(kPanelScene, p.now);
    joined();
    p.panel(false, true);
    p.m.tick(p.now);
    ok("preload: parked and not wanted: unmapped, loaded", calls_are("unmap panel") &&
                                                           p.state(1) == TargetState::Loaded);

    PreloadRig d;   /* the unmap finds no fetch */
    d.panel(true, true);
    d.m.tick(d.now);
    d.m.on_shown(kPanelScene, d.now);
    joined();
    d.port.fetched = false;
    d.panel(false, true);
    d.run(3010);
    ok("preload: an unmap the port cannot keep: released", calls_are("unmap panel (not fetched); release panel") &&
                                                          !d.m.loaded(1) && d.state(1) == TargetState::Idle);
    d.run(1000);
    ok("preload: then loaded again", calls_are("load panel"));

    PreloadRig n;   /* the remap finds no fetch */
    n.loaded();
    n.port.fetched = false;
    n.run(2000);
    n.panel(true, true);
    n.m.tick(n.now);
    ok("preload: the display no longer holds the loaded scene: released",
       calls_are("remap panel (not fetched); release panel") && n.state(1) == TargetState::Waiting);
    n.m.tick(n.now);
    ok("preload: and asked for in full at once", calls_are("request panel") && n.state(1) == TargetState::Acquiring);
}

static void preload_untouched()
{
    PreloadRig r;   /* the map, no preload layer, on a port that can keep a fetch */
    r.m.want(0, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kMapScene, r.now);
    r.m.want(0, false, false);
    r.run(2010);
    ok("preload: a target with no preload layer is released after its linger", calls_are("publish map; request map; "
                                                                                            "release map") &&
                                                                                   r.state(0) == TargetState::Idle);

    Rig n;   /* a port that cannot keep a fetch (iDrive 8) */
    n.m.want(1, false, false, true, true, true);
    n.run(5000);
    ok("preload: ignored by a port that cannot keep a fetch", calls_are("") && n.state(1) == TargetState::Idle &&
                                                              !n.m.loaded(1));
    n.m.want(1, true, false, true, true, true);
    n.m.tick(n.now);
    n.m.on_shown(kPanelScene, n.now);
    n.m.want(1, false, false, true, true, true);
    n.run(3010);
    ok("preload: there the target is requested and released as with no preload layer",
       calls_are("publish panel; request panel; release panel") && n.state(1) == TargetState::Idle);
    n.run(60000);
    ok("preload: and not fetched after", calls_are(""));
}

static void preload_dropped()
{
    PreloadRig r;
    r.loaded();
    incidents();
    r.m.on_lost(kPanelScene, "fetch removed", r.now);
    ok("preload: the display drops the loaded fetch: taken down, waiting 2 s",
       calls_are("release panel") && r.state(1) == TargetState::Waiting && !r.m.loaded(1) &&
           r.m.status(1).retry_ms == r.now + 2000);
    ok("preload: a loaded scene is not shown: no incident", incidents().empty());
    r.run(1990);
    ok("preload: nothing before the step", calls_are(""));
    r.run(20);
    ok("preload: loaded again on the ladder", calls_are("load panel") && r.state(1) == TargetState::Loading);
    r.m.on_fetched(kPanelScene, r.now);
    r.m.on_lost(kPanelScene, "fetch removed", r.now);
    ok("preload: dropped again: the next step, 5 s", calls_are("release panel") &&
                                                     r.m.status(1).retry_ms == r.now + 5000);
    r.run(5010);
    ok("preload: loaded at 5 s", calls_are("load panel"));
    r.m.on_refused(kPanelScene, Refusal::Transient, "fetch removed", r.now);
    ok("preload: a refused load waits on the ladder too (10 s)",
       calls_are("release panel") && r.state(1) == TargetState::Waiting && r.m.status(1).retry_ms == r.now + 10000);
    r.run(10010);
    ok("preload: loaded at 10 s", calls_are("load panel"));
    r.m.on_refused(kPanelScene, Refusal::Busy, "fetch E_DCSM_PRIOTOOLOW", r.now);
    ok("preload: a busy refusal of a load waits on the ladder, not for the slot",
       calls_are("release panel") && r.m.status(1).retry_ms == r.now + 20000);
    r.run(20010);
    joined();
    r.m.on_fetched(kPanelScene, r.now);
    r.run(30000);
    ok("preload: loaded 30 s: the ladder starts over", calls_are(""));
    r.m.on_lost(kPanelScene, "fetch removed", r.now);
    ok("preload: dropped after that: 2 s", calls_are("release panel") && r.m.status(1).retry_ms == r.now + 2000);

    PreloadRig s;   /* a load the display never completes */
    s.port.fetching["panel"] = true;
    s.panel(false, true);
    s.m.tick(s.now);
    joined();
    incidents();
    s.run(4990);
    ok("preload: a load not fetched: loading until 5 s", calls_are("") && s.state(1) == TargetState::Loading);
    s.run(20);
    ok("preload: a stalled load: taken down, on the ladder, counted as a stall",
       calls_are("release panel") && s.state(1) == TargetState::Waiting &&
           has(incidents(), "INCIDENT target panel stalled: fetch accepted but never completed in 5000 ms, 1 in a row"));
    s.run(2010);
    s.run(5000);
    ok("preload: the second in a row: its scene published fresh", calls_are("load panel; release panel; unpublish panel") &&
                                                                    has(incidents(), "2 in a row"));

    PreloadRig h;   /* the heartbeat replies stop */
    h.loaded();
    h.m.drop_kept("heartbeat replies stopped", h.now);
    ok("preload: heartbeat replies stopped: the loaded scene released, loaded again on the ladder",
       calls_are("release panel") && h.state(1) == TargetState::Waiting && h.m.status(1).retry_ms == h.now + 2000);

    PreloadRig u;   /* the display service goes and comes back */
    u.loaded();
    u.port.up = false;
    u.m.on_availability(false, u.now);
    u.m.tick(u.now);
    ok("preload: the display service gone: nothing loaded, nothing sent", calls_are("") && !u.m.loaded(1) &&
                                                                           u.state(1) == TargetState::Idle);
    u.run(10000);
    ok("preload: nothing while it is gone", calls_are(""));
    u.port.up = true;
    u.m.on_availability(true, u.now);
    u.run(990);
    ok("preload: back: nothing before the settle time", calls_are(""));
    u.run(20);
    ok("preload: then loaded again, its scene still published", calls_are("load panel") &&
                                                                 u.state(1) == TargetState::Loading);
}

static void preload_shared_scene()
{
    PreloadRig r;
    r.loaded();
    r.m.want(2, true, false);   /* the HUD, on the panel's scene id */
    r.m.tick(r.now);
    ok("preload: a target wanting the loaded scene's id: the loaded one released for it, then the request",
       calls_are("release panel; unpublish panel; publish hud; request hud") && !r.m.loaded(1) &&
           r.state(1) == TargetState::Waiting && r.m.status(1).reason == "scene id in use by another target");
    r.m.on_shown(kPanelScene, r.now);
    r.run(30000);
    ok("preload: no load while the other holds the id", calls_are("") && r.state(1) == TargetState::Waiting);
    r.m.want(2, false, false);
    r.run(2010);
    ok("preload: the other released after its linger", calls_are("release hud"));
    r.run(10);
    ok("preload: then loaded again", calls_are("unpublish hud; publish panel; load panel") &&
                                     r.state(1) == TargetState::Loading);

    PreloadRig w;   /* the other wanted and waiting: no load meanwhile */
    w.m.want(2, true, false);
    w.slot(kHudSlot, 2, 0x01000201);   /* HMI content shown in its slot: it waits */
    w.m.tick(w.now);
    joined();
    w.panel(false, true);
    w.run(5000);
    ok("preload: no load while another target with the id is wanted", !has(joined(), "load") &&
                                                                         !w.m.loaded(1));
}

static void preload_lock()
{
    PreloadRig r;
    r.loaded();
    r.rows(kPanelSlot, 0, {{0x01000500, 0}});   /* a lock of the panel's slot */
    r.run(3000);
    ok("preload: a lock leaves the loaded scene alone", !has(joined(), "release") && r.state(1) == TargetState::Loaded);
    r.panel(true, true);
    r.run(1000);
    const std::string during = joined();
    ok("preload: wanted while locked: not mapped, waiting as slot locked, still loaded",
       !has(during, "remap") && !has(during, "request") && r.state(1) == TargetState::Waiting &&
           r.m.status(1).reason == "slot locked" && r.m.loaded(1) && r.m.flushing(1));
    r.rows(kPanelSlot, 1, {{0x01000500, 0}});
    r.m.tick(r.now);
    ok("preload: the slot back: mapped with no fetch", calls_are("remap panel"));

    PreloadRig k;   /* kept through a lock, then not wanted */
    k.port.keeps = true;
    k.panel(true, true);
    k.m.tick(k.now);
    k.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    k.m.on_shown(kPanelScene, k.now);
    k.run(1000);
    k.rows(kPanelSlot, 0, {{kPanelScene, 1}});
    k.m.on_lost(kPanelScene, "unmapped", k.now);
    ok("preload: a shown target locked: kept", calls_are("publish panel; request panel; keep panel") && k.m.kept(1));
    k.panel(false, true);
    k.m.tick(k.now);
    ok("preload: kept and not wanted: loaded, its fetch kept", calls_are("") && k.state(1) == TargetState::Loaded &&
                                                               k.m.loaded(1) && !k.m.kept(1));
    k.rows(kPanelSlot, 1, {{kPanelScene, 0}});
    k.run(2000);
    ok("preload: the slot back: nothing mapped while nothing wants it", calls_are("") &&
                                                                        k.state(1) == TargetState::Loaded);
    k.panel(true, true);
    k.m.tick(k.now);
    ok("preload: wanted: mapped with no fetch", calls_are("remap panel"));
}

/* A target with no preload layer, nothing wanting it, waiting on the ladder
 * while another target with its scene id is wanted and not requested: at
 * its retry it goes idle, its incident closed. */
static void shared_id_ladder_no_preload()
{
    Rig r;
    r.rows(kHudSlot, 2, {{0x02000001, 1}});   /* the HUD's slot held by another app: the HUD waits */
    r.m.want(1, true, false);
    r.m.tick(r.now);
    r.m.on_shown(kPanelScene, r.now);
    r.run(1000);
    r.m.want(2, true, false);
    r.run(100);
    joined();
    incidents();
    r.m.on_lost(kPanelScene, "fetch removed", r.now);
    r.m.want(1, false, false);
    r.run(100);
    ok("shared id, no preload: the panel waits on the ladder, the HUD wanted and not requested",
       r.state(1) == TargetState::Waiting && r.m.status(1).retry_ms > r.now && !r.m.requested(2) &&
           r.state(2) == TargetState::Waiting);
    r.run(2000);
    ok("shared id, no preload: at its retry the panel goes idle, not back",
       r.state(1) == TargetState::Idle && has(incidents(), "INCIDENT target panel not back: released after"));
}

/* A stock pop-up the target gives way to while its load is out. */
static void preload_popup()
{
    FakePort port;
    port.preloads_ok = true;
    FakeScenes scenes;
    SlotManager m{&port, &scenes};
    TargetSpec hud;
    hud.name = "hud"; hud.slot = kHudSlot; hud.scene_id = kPanelScene; hud.width = 800; hud.height = 480;
    hud.linger_ms = 3000;
    hud.yield_slots = {0x322};
    m.add(hud);
    int64_t now = 100000;
    const auto run = [&](int64_t ms) { for (int64_t x = 0; x < ms; x += 10) { now += 10; m.tick(now); } };
    const auto row = [&](uint64_t slot, uint32_t status, uint64_t content, uint32_t map) {
        SlotInfo si; si.slot = slot; si.status = status; si.content = content; si.map_status = map;
        m.on_slots({si}, now);
    };
    calls.clear();
    m.want(0, false, false, true, true, true);
    m.tick(now);
    ok("preload pop-up: loading", calls_are("publish hud; load hud") && m.status(0).state == TargetState::Loading);
    m.want(0, true, false, true, true, true);
    row(0x322, 2, 0x01000501, 1);
    m.tick(now);
    ok("preload pop-up: a pop-up while loading: the load released, the target giving way",
       calls_are("release hud") && m.status(0).state == TargetState::Waiting && !m.loaded(0));
    m.on_refused(kPanelScene, Refusal::FetchFailed, "E_FETCH_STATUS_FAILED", now);
    m.want(0, false, false, true, true, true);
    run(500);
    ok("preload pop-up: nothing wanting it: not loaded without a fetch", m.status(0).state != TargetState::Loaded &&
                                                                        !m.loaded(0) && calls_are(""));
    run(1000);
    ok("preload pop-up: loaded again", calls_are("load hud") && m.status(0).state == TargetState::Loading);
    m.on_fetched(kPanelScene, now);
    ok("preload pop-up: loaded once fetched", m.status(0).state == TargetState::Loaded);
}

/* The table's view of a target unmapped to Loaded. */
static void preload_unmap_table()
{
    PreloadRig r;
    r.panel(true, true);
    r.m.tick(r.now);
    r.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    r.m.on_shown(kPanelScene, r.now);
    r.panel(false, true);
    r.run(3010);
    ok("unmap table: unmapped, loaded", calls_are("publish panel; request panel; unmap panel") &&
                                        r.state(1) == TargetState::Loaded);
    r.rows(kPanelSlot, 2, {{kPanelScene, 1}});   /* a report from before the unmap */
    r.panel(true, true);
    r.m.tick(r.now);
    ok("unmap table: our own row still mapped is ours, not the stock HMI's: mapped again at once",
       calls_are("remap panel") && r.state(1) == TargetState::Acquiring);

    PreloadRig s;   /* the unmap not done */
    s.panel(true, true);
    s.m.tick(s.now);
    s.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    s.m.on_shown(kPanelScene, s.now);
    s.panel(false, true);
    s.run(3010);
    joined();
    s.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    s.run(2990);
    ok("unmap table: reported mapped after the unmap: loaded until 3 s", calls_are("") &&
                                                                          s.state(1) == TargetState::Loaded);
    s.run(20);
    ok("unmap table: 3 s mapped: released, loaded again on the ladder",
       calls_are("release panel") && s.state(1) == TargetState::Waiting && !s.m.loaded(1));
    s.run(2000);
    ok("unmap table: loaded at the ladder's step", calls_are("load panel"));

    PreloadRig u;   /* the unmap reported, then the id mapped again by other content */
    u.panel(true, true);
    u.m.tick(u.now);
    u.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    u.m.on_shown(kPanelScene, u.now);
    u.panel(false, true);
    u.run(3010);
    joined();
    u.rows(kPanelSlot, 1, {{kPanelScene, 0}});
    u.rows(kPanelSlot, 2, {{kPanelScene, 1}});
    u.run(10000);
    ok("unmap table: once reported unmapped, the row is not watched", calls_are("") &&
                                                                       u.state(1) == TargetState::Loaded);
}

/* Stalled loads nothing wants never reconnect the framework; a wanted
 * target's stalls count from its own. */
static void preload_stalls_no_reconnect()
{
    PreloadRig r;
    int reconnects = 0;
    r.m.on_renderer_stuck = [&reconnects](int64_t) { reconnects++; };
    r.port.fetching["panel"] = true;
    r.panel(false, true);
    incidents();
    r.run(120000);
    const std::string inc = incidents();
    size_t stalls = 0;
    for (size_t at = inc.find("stalled"); at != std::string::npos; at = inc.find("stalled", at + 1))
        stalls++;
    ok("preload stalls: six loads stalled, the scene republished, no reconnect",
       stalls >= 6 && reconnects == 0 && !has(inc, "reconnecting") && has(joined(), "unpublish panel"));
    r.panel(true, true);
    int wanted_stalls = 0;
    for (int k = 0; k < 3; k++) {
        for (int n = 0; n < 12000 && !has(incidents(), "stalled"); n++)
            r.run(10);
        wanted_stalls++;
        if (k < 2)
            ok("preload stalls: wanted, its first stalls reconnect nothing", reconnects == 0);
    }
    ok("preload stalls: the third wanted stall in a row reconnects", wanted_stalls == 3 && reconnects == 1);
}

int main()
{
    incident_lines();
    refcount_and_linger();
    timeout_and_ladder();
    stock_yield();
    stock_contend();
    foreign_always_yields();
    idle_precheck();
    busy_refusal_unknown_holder();
    availability();
    shared_scene_id();
    request_gap();
    lost_while_lingering();
    scene_failure();
    ladder_rechecks_the_table();
    lost_to_our_own_id();
    lock_is_not_evidence();
    slot_comes_back();
    multi_row_holder();
    parked_then_shown();
    take_over();
    lock_then_take_overs();
    brief_shows_back_off();
    take_overs_restart_when_shown();
    not_mapped_map_after_lock();
    not_mapped_panel_and_hud();
    no_request_while_locked();
    fallback_and_lock();
    wake();
    warm_scenes();
    shared_scene_in_use();
    fresh_retry_cleared();
    release_confirmation();
    fresh_fetch_failed();
    removal_retry();
    rendering();
    quiet_console();
    guide_follows_the_map();
    table_in_status();
    guide_queue_order();
    guide_never_verified_out();
    guide_live_route();
    guide_yields();
    guide_not_mapped();
    guide_door_lock();
    guide_take_over_settle();
    guide_gives_up();
    guide_slot_disabled();
    guide_drops();
    guide_gives_up_twice();
    guide_no_flapping();
    guide_auto_slot();
    guide_box_comes_and_goes();
    hud_drops();
    panel_hud_map_together();
    panel_falls_back_on_refusal();
    panel_keeps_its_id_through_drops();
    panel_yields_to_speech_dialog();
    keep_group_lock();
    keep_door_lock();
    keep_take_over_after_lock();
    keep_falls_back();
    keep_limits();
    keep_flapping();
    keep_panel_and_hud();
    keep_guide();
    stalled_fetches();
    boot_hold();
    preload_load_and_map();
    preload_untouched();
    preload_dropped();
    preload_shared_scene();
    preload_lock();
    shared_id_ladder_no_preload();
    preload_popup();
    preload_unmap_table();
    preload_stalls_no_reconnect();
    for (bool compact : {false, true}) {
        /* The HUD's media pop-up (0x322): the HUD map gives way while it shows */
        TargetSpec hud2;
        FakePort port2;
        FakeScenes scenes2;
        SlotManager m2{&port2, &scenes2};
        hud2.name = "hud"; hud2.slot = kHudSlot; hud2.scene_id = kPanelScene; hud2.width = 800; hud2.height = 480;
        const uint64_t slot = compact ? 0x371 : kHudSlot;
        hud2.slot = slot;
        hud2.always_yield = compact;
        hud2.linger_ms = 3000;
        hud2.yield_slots = {0x322};
        hud2.yield_ms = 1500;
        m2.add(hud2);
        int64_t now = 100000;
        const auto run = [&](int64_t ms) { for (int64_t x = 0; x < ms; x += 10) { now += 10; m2.tick(now); } };
        const auto row = [&](uint64_t slot, uint32_t status, uint64_t content, uint32_t map) {
            SlotInfo si; si.slot = slot; si.status = status; si.content = content; si.map_status = map;
            m2.on_slots({si}, now);
        };
        calls.clear();
        m2.want(0, true, true, true, !compact);   /* F44 client asks to stay over the list */
        run(1200);
        m2.on_shown(kPanelScene, now);
        run(20);
        ok("popup: the HUD map asked for and shown", m2.status(0).state == TargetState::Shown);
        calls.clear();
        row(0x322, 2, 0x01000251, 1);          /* the media list opens in the HUD */
        row(slot, 0, kPanelScene, 1);      /* the KOMBI takes the map down for it */
        run(50);
        ok("popup: the map releases its slot and waits",
           m2.status(0).state == TargetState::Waiting && joined().find("release hud") != std::string::npos);
        row(slot, 1, kPanelScene, 0);      /* the HUD slot is free again while the pop-up shows */
        run(3000);
        ok("popup: not asked for while the pop-up shows, though the slot is free",
           m2.status(0).state == TargetState::Waiting && joined().find("request hud") == std::string::npos);
        row(0x322, 1, 0x01000251, 0);          /* the pop-up closes */
        run(1000);
        ok("popup: still waiting within yield_ms after it closed", joined().find("request hud") == std::string::npos);
        run(1500);
        ok("popup: asked for again once yield_ms has passed", joined().find("request hud") != std::string::npos);
    }
    {
        /* The HUD's yield slots as shipped (0x322, the lists): it gives way to a list in 0x322 and comes back
         * yield_ms after, and a call's pop-up in 0x321 leaves it shown; never to route guidance, BMW's
         * (0x01000210, in its own slot or one it gives way to) or the turn box (0x01000310); and not at all while a
         * layer has yield false */
        TargetSpec hud5;
        FakePort port5;
        FakeScenes scenes5;
        SlotManager m5{&port5, &scenes5};
        hud5.name = "hud"; hud5.slot = kHudSlot; hud5.scene_id = kPanelScene; hud5.width = 800; hud5.height = 480;
        hud5.linger_ms = 3000;
        hud5.yield_slots = {0x322};
        hud5.yield_ms = 1500;
        m5.add(hud5);
        int64_t now = 400000;
        bool yield = true;
        const auto run = [&](int64_t ms) {
            for (int64_t x = 0; x < ms; x += 10) { now += 10; m5.want(0, true, true, true, yield); m5.tick(now); }
        };
        const auto row = [&](uint64_t slot, uint32_t status, uint64_t content, uint32_t map) {
            SlotInfo si; si.slot = slot; si.status = status; si.content = content; si.map_status = map;
            m5.on_slots({si}, now);
        };
        const auto shown_again = [&]() {
            run(1200);
            m5.on_shown(kPanelScene, now);
            row(kHudSlot, 2, kPanelScene, 1);
            run(20);
            return m5.status(0).state == TargetState::Shown;
        };
        calls.clear();
        ok("yield: the HUD map asked for and shown", shown_again());
        calls.clear();
        row(0x321, 2, 0x01000600, 1);          /* an active call's pop-up */
        run(3000);
        ok("yield: a call's pop-up in 0x321 (not shipped) leaves the HUD map shown",
           m5.status(0).state == TargetState::Shown && joined().find("release hud") == std::string::npos);
        row(0x321, 1, 0x01000600, 0);
        row(0x322, 2, 0x01000251, 1);          /* the media source list */
        run(50);
        ok("yield: a list in 0x322 releases the HUD map",
           m5.status(0).state == TargetState::Waiting && joined().find("release hud") != std::string::npos);
        row(kHudSlot, 1, 0, 0);
        row(0x322, 1, 0x01000251, 0);          /* the list closes */
        calls.clear();
        run(1400);
        ok("yield: still waiting within yield_ms after the list", joined().find("request hud") == std::string::npos);
        ok("yield: asked for again once yield_ms has passed", shown_again() && joined().find("request hud") != std::string::npos);

        calls.clear();
        row(0x330, 2, 0x01000210, 1);          /* a route: BMW's HUD guidance in its own slot (a G05's) */
        row(0x300, 2, 0x01000210, 1);          /* or an X3's */
        row(0x105, 2, 0x01000310, 1);          /* the turn box on the cluster */
        run(3000);
        ok("never: BMW's guidance and the turn box leave the HUD map shown",
           m5.status(0).state == TargetState::Shown && joined().find("release hud") == std::string::npos);
        row(0x322, 2, 0x01000211, 1);          /* guidance in a slot it gives way to */
        run(3000);
        ok("never: guidance in a yield slot does not count either",
           m5.status(0).state == TargetState::Shown && joined().find("release hud") == std::string::npos);
        row(0x322, 1, 0x01000211, 0);

        yield = false;                          /* a layer keeps it shown */
        run(20);
        row(0x322, 2, 0x01000251, 1);
        run(3000);
        ok("keep shown: a list leaves the HUD map shown",
           m5.status(0).state == TargetState::Shown && joined().find("release hud") == std::string::npos);
        yield = true;
        run(50);
        ok("keep shown off: the list showing releases it", m5.status(0).state == TargetState::Waiting &&
                                                                 joined().find("release hud") != std::string::npos);
        row(kHudSlot, 1, 0, 0);
        calls.clear();
        yield = false;
        run(50);
        ok("keep shown on while it waits: asked for again at once, the list still showing",
           joined().find("request hud") != std::string::npos);
    }
    {
        /* hud_yield_slots = 0x321,0x322 in the conf: a call's pop-up in 0x321 is given way to too */
        TargetSpec hud6;
        FakePort port6;
        FakeScenes scenes6;
        SlotManager m6{&port6, &scenes6};
        hud6.name = "hud"; hud6.slot = kHudSlot; hud6.scene_id = kPanelScene; hud6.width = 800; hud6.height = 480;
        hud6.linger_ms = 3000;
        hud6.yield_slots = {0x321, 0x322};
        hud6.yield_ms = 1500;
        m6.add(hud6);
        int64_t now = 500000;
        const auto run = [&](int64_t ms) { for (int64_t x = 0; x < ms; x += 10) { now += 10; m6.tick(now); } };
        const auto row = [&](uint64_t slot, uint32_t status, uint64_t content, uint32_t map) {
            SlotInfo si; si.slot = slot; si.status = status; si.content = content; si.map_status = map;
            m6.on_slots({si}, now);
        };
        m6.want(0, true, true);
        run(1200);
        m6.on_shown(kPanelScene, now);
        row(kHudSlot, 2, kPanelScene, 1);
        run(20);
        calls.clear();
        row(0x321, 2, 0x01000600, 1);          /* an incoming call's pop-up */
        run(50);
        ok("0x321 configured: a call's pop-up releases the HUD map",
           m6.status(0).state == TargetState::Waiting && joined().find("release hud") != std::string::npos);
        row(kHudSlot, 1, 0, 0);
        row(0x321, 1, 0x01000600, 0);
        calls.clear();
        run(1600);
        ok("0x321 configured: asked for again once yield_ms has passed", joined().find("request hud") != std::string::npos);
    }
    {
        /* Lost while the table names our id, the media pop-up showing before
         * the next report: the pop-up's wait settles that loss, so a later
         * wait (a request unanswered) is not taken for it */
        TargetSpec hud4;
        FakePort port4;
        FakeScenes scenes4;
        SlotManager m4{&port4, &scenes4};
        hud4.name = "hud"; hud4.slot = kHudSlot; hud4.scene_id = kPanelScene; hud4.width = 800; hud4.height = 480;
        hud4.linger_ms = 3000;
        hud4.yield_slots = {0x322};
        hud4.yield_ms = 1500;
        m4.add(hud4);
        std::vector<std::string> ev;
        m4.on_evidence = [&](Evidence e, const std::string &, int64_t) { ev.push_back(evidence_name(e)); };
        int64_t now = 300000;
        const auto run = [&](int64_t ms) { for (int64_t x = 0; x < ms; x += 10) { now += 10; m4.tick(now); } };
        const auto row = [&](uint64_t slot, uint32_t status, uint64_t content, uint32_t map) {
            SlotInfo si; si.slot = slot; si.status = status; si.content = content; si.map_status = map;
            m4.on_slots({si}, now);
        };
        m4.want(0, true, true);
        run(1200);
        m4.on_shown(kPanelScene, now);
        row(kHudSlot, 2, kPanelScene, 1);
        run(20);
        m4.on_lost(kPanelScene, "fetch removed", now);
        row(0x322, 2, 0x01000251, 1);
        row(kHudSlot, 1, 0, 0);
        run(50);
        row(0x322, 1, 0x01000251, 0);
        calls.clear();
        run(2000);
        const bool asked = joined().find("request hud") != std::string::npos;
        run(SlotManager::kStartTimeoutMs + 20);
        ok("popup over an undecided loss: asked for again after it, an unanswered request waits as that, no evidence",
           asked && m4.status(0).reason == "no answer from the display" && ev.empty());
    }
    for (int contending = 0; contending < 2; contending++) {
        /* Stock content parked behind ours in the HUD slot (Google Maps' turn cards while only an overlay holds
         * the HUD): a target that doesn't contend gives way and waits until the slot is free; one that contends
         * (the Waze map) keeps it */
        TargetSpec hud3;
        FakePort port3;
        FakeScenes scenes3;
        SlotManager m3{&port3, &scenes3};
        hud3.name = "hud"; hud3.slot = kHudSlot; hud3.scene_id = kPanelScene; hud3.width = 800; hud3.height = 480;
        hud3.linger_ms = 3000;
        hud3.yield_slots = {0x322};
        hud3.yield_ms = 1500;
        m3.add(hud3);
        int64_t now = 200000;
        const auto run = [&](int64_t ms) { for (int64_t x = 0; x < ms; x += 10) { now += 10; m3.tick(now); } };
        const auto rows = [&](std::vector<SlotInfo> v) { m3.on_slots(v, now); };
        const auto row = [&](uint64_t slot, uint32_t status, uint64_t content, uint32_t map) {
            SlotInfo si; si.slot = slot; si.status = status; si.content = content; si.map_status = map; return si;
        };
        calls.clear();
        m3.want(0, true, contending == 1);
        run(1200);
        m3.on_shown(kPanelScene, now);
        run(20);
        calls.clear();
        rows({row(kHudSlot, 2, kPanelScene, 1), row(kHudSlot, 2, 0x01000361, 3)});   /* cards mapped, parked behind ours */
        run(50);
        if (!contending) {
            ok("parked behind: an overlay-only HUD gives way to the stock content",
               m3.status(0).state == TargetState::Waiting && joined().find("release hud") != std::string::npos);
            rows({row(kHudSlot, 2, 0x01000361, 1)});                                /* the cards show */
            run(3000);
            ok("parked behind: not asked for while the stock content shows", joined().find("request hud") == std::string::npos);
            rows({row(kHudSlot, 1, 0x01000361, 0)});                                /* they go */
            run(3000);
            ok("parked behind: asked for again once the slot is free", joined().find("request hud") != std::string::npos);
        } else {
            ok("parked behind: a contending target (the Waze map) keeps its slot",
               m3.status(0).state == TargetState::Shown && joined().find("release hud") == std::string::npos);
        }
    }

    std::printf(failures ? "%d FAILED\n" : "all ok\n", failures);
    return failures ? 1 : 0;
}
