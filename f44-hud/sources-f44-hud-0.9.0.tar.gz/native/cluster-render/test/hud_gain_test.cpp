/* GPL-3.0-or-later: targeted regression of the experimental HUD effect. */
#define main compositor_suite_main
#include "compositor_test.cpp"
#undef main
#include <fstream>

static bool has_gain(Rig &r, const char *target)
{
    FakeGraph *g = r.g(target);
    if (!g) return false;
    for (const auto &q : g->shown.quads) {
        auto e = r.gpu.effects.find(q.second.effect);
        if (e != r.gpu.effects.end() && e->second.find("vec3(0.065)") != std::string::npos) return true;
    }
    return false;
}

int main()
{
    Rig r;
    std::string err;
    VideoParams vp; vp.w = 64; vp.h = 32; vp.pan_blocks = false;
    const auto m = r.comp->add_video(1, r.map, params(Klass::Content, R(0, 0, 64, 32), true), vp, r.now, &err);
    const auto h = r.comp->add_video(2, r.hud, params(Klass::Content, R(0, 0, 64, 32), true), vp, r.now, &err);
    std::vector<uint8_t> data(64 * 48, 128);
    static_cast<VideoLayer *>(r.comp->layer(1, m))->offer(data.data(), r.now);
    static_cast<VideoLayer *>(r.comp->layer(2, h))->offer(data.data(), r.now);
    r.step(10);
    ok("HUD video receives the brightened shader", has_gain(r, "hud"));
    ok("cluster video keeps its original shader", r.g("map") && !has_gain(r, "map"));
    {
        CompositorLimits limits; limits.videos = 1;
        Rig composite(0, limits);
        const auto a = composite.comp->add_video(4, composite.hud,
            params(Klass::Content, R(0, 0, 64, 32), true), vp, composite.now, &err);
        const auto b = composite.comp->add_video(5, composite.hud,
            params(Klass::Content, R(64, 0, 64, 32), true), vp, composite.now, &err);
        if (a && b) {
            static_cast<VideoLayer *>(composite.comp->layer(4, a))->offer(data.data(), composite.now);
            static_cast<VideoLayer *>(composite.comp->layer(5, b))->offer(data.data(), composite.now);
            composite.step(10);
        }
        ok("two HUD videos receive a brightened composite", composite.comp->composite(composite.hud) &&
            has_gain(composite, "hud"));
        unsigned written = 0;
        for (const auto &effect : composite.gpu.effects) {
            if (effect.second.find("vec3(0.065)") == std::string::npos) continue;
            const bool atlas = effect.second.find("vec3 rgb =") != std::string::npos;
            const bool view = effect.second.find("uniform vec4 u_view") != std::string::npos;
            const std::string name = std::string("/tmp/f44-") + (view ? "view-" : "direct-") +
                                     (atlas ? "atlas" : "block") + ".frag";
            std::ofstream out(name); out << effect.second; written++;
        }
        ok("all four HUD shader variants are available for GLSL validation", written == 4);
    }
    {
        Rig rejected;
        rejected.gpu.reject = "vec3(0.065)";
        std::string why;
        const auto id = rejected.comp->add_video(3, rejected.hud,
            params(Klass::Content, R(0, 0, 64, 32), true), vp, rejected.now, &why);
        ok("refused HUD effect keeps the video with its original shader", id != 0);
    }
    std::printf(failures ? "%d FAILED\n" : "all ok\n", failures);
    return failures ? 1 : 0;
}
