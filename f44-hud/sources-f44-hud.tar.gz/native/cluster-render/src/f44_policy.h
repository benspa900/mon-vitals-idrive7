/* F44 experimental profile: avoid temporal switches between compressed and
 * atlas colour representations for the Waze map on the instrument cluster.
 * The HUD and other clients/targets retain their negotiated settings. */
#ifndef F44_POLICY_H
#define F44_POLICY_H
#include <algorithm>
#include <string>
#include "video_layer.h"
namespace crs {
inline void f44_stabilize_map(const std::string &app, const std::string &target, VideoParams *p)
{
    if (app != "waze-on-cluster" || target != "map") return;
    p->pan_blocks = false;
    p->fps = p->fps ? std::min(p->fps, 8u) : 8u;
}
}
#endif
