#define main compositor_suite_main
#include "compositor_test.cpp"
#undef main
#include "f44_policy.h"
int main() {
    Rig r(5500 * 1024, CompositorLimits(), true);
    std::string err;
    VideoParams mp; f44_stabilize_map("waze-on-cluster", "map", &mp);
    const auto mid=r.comp->add_video(1,r.map,params(Klass::Content,R(0,0,W,H),true),mp,r.now,&err);
    VideoParams hp; hp.w=424; hp.h=188; hp.fps=10; hp.pan_blocks=false;
    const auto hid=r.comp->add_video(2,r.hud,params(Klass::Content,R(0,0,424,188),true),hp,r.now,&err);
    if (!mid || !hid) { std::fprintf(stderr,"layer creation failed: %s\n",err.c_str()); return 1; }
    auto *mv=static_cast<VideoLayer *>(r.comp->layer(1,mid));
    auto *hv=static_cast<VideoLayer *>(r.comp->layer(2,hid));
    std::vector<uint8_t> hf((size_t)424*282);
    for(int k=0;k<180;k++) {
        auto f=frame(k); mv->offer(f.data(),r.now);
        for(size_t i=0;i<hf.size();i++) hf[i]=(uint8_t)(i/7+k*5);
        hv->offer(hf.data(),r.now);
        for(int t=0;t<33;t+=11) {r.step(11); if(k==0&&t==0){r.slots.on_shown(0x010004f0,r.now);r.slots.on_shown(0x01000400,r.now);}}
    }
    const auto ms=mv->stats(), hs=hv->stats();
    std::printf("map %s\nhud %s\n",ms.c_str(),hs.c_str());
    ok("Waze map writes without packed frames",ms.find(", 0 packed,")!=std::string::npos && r.comp->write_stats(r.map).frames >= 12);
    ok("HUD continues updating",r.comp->write_stats(r.hud).frames >= 12);
    std::printf(failures ? "%d FAILED\n" : "all ok\n",failures);
    return failures?1:0;
}
