/* F44: the mitigation is restricted to the Waze map and respects a lower
 * requested rate; the packed-video switch is left intact everywhere else. */
#include "f44_policy.h"
#include <cassert>
#include <cstdio>
using namespace crs;
int main() {
    VideoParams map; f44_stabilize_map("waze-on-cluster", "map", &map);
    assert(!map.pan_blocks && map.fps == 8);
    VideoParams slow; slow.fps=4; f44_stabilize_map("waze-on-cluster", "map", &slow);
    assert(!slow.pan_blocks && slow.fps == 4);
    VideoParams unlimited; unlimited.fps=0; f44_stabilize_map("waze-on-cluster", "map", &unlimited);
    assert(!unlimited.pan_blocks && unlimited.fps == 8);
    VideoParams hud; f44_stabilize_map("waze-on-cluster", "hud", &hud);
    assert(hud.pan_blocks && hud.fps == 30);
    VideoParams other; f44_stabilize_map("another-app", "map", &other);
    assert(other.pan_blocks && other.fps == 30);
    VideoParams panel; f44_stabilize_map("waze-on-cluster", "panel", &panel);
    assert(panel.pan_blocks && panel.fps == 30);
    std::puts("F44 policy: map packing disabled; unrelated layers unchanged");
}
